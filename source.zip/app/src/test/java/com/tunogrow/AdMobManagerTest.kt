package com.tunogrow

import com.tunogrow.ads.AdMobManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AdMobManagerTest {

  @Test
  fun testAdMobConfiguration() {
    assertEquals("ca-app-pub-4979667457711305~4707491569", AdMobManager.ADMOB_APP_ID)
    assertEquals("ca-app-pub-4979667457711305/9955948819", AdMobManager.PRODUCTION_REWARDED_AD_UNIT_ID)
    assertEquals("ca-app-pub-3940256099942544/5224354917", AdMobManager.TEST_REWARDED_AD_UNIT_ID)
    assertEquals(25L, AdMobManager.DEFAULT_REWARD_COINS)
  }

  @Test
  fun testAdUnitIdSwitching() {
    // By default, original production ad unit is active
    assertFalse(AdMobManager.isTestMode.value)
    assertEquals(AdMobManager.PRODUCTION_REWARDED_AD_UNIT_ID, AdMobManager.currentAdUnitId)

    // When test mode is enabled, test ad unit is returned
    AdMobManager.setTestMode(true)
    assertTrue(AdMobManager.isTestMode.value)
    assertEquals(AdMobManager.TEST_REWARDED_AD_UNIT_ID, AdMobManager.currentAdUnitId)

    // Reset back to production mode
    AdMobManager.setTestMode(false)
    assertFalse(AdMobManager.isTestMode.value)
    assertEquals(AdMobManager.PRODUCTION_REWARDED_AD_UNIT_ID, AdMobManager.currentAdUnitId)
  }
}
