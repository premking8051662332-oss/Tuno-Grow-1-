package com.tunogrow

import com.tunogrow.model.OrderModel
import com.tunogrow.model.TunoNotification
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OrderAndNotificationWorkflowTest {

    @Test
    fun testOrderModelAllFiveStatuses() {
        val pendingOrder = OrderModel(orderId = "ord_1", status = "pending")
        assertEquals("Pending", pendingOrder.displayStatus)

        val activeOrder = OrderModel(orderId = "ord_2", status = "active")
        assertEquals("Active", activeOrder.displayStatus)

        val completedOrder = OrderModel(orderId = "ord_3", status = "completed")
        assertEquals("Completed", completedOrder.displayStatus)

        val cancelledOrder = OrderModel(orderId = "ord_4", status = "cancelled")
        assertEquals("Cancelled", cancelledOrder.displayStatus)

        val failedOrder = OrderModel(orderId = "ord_5", status = "verification_failed")
        assertEquals("Verification Failed", failedOrder.displayStatus)
    }

    @Test
    fun testOnlyThreeOrderTypesSupported() {
        val subOrder = OrderModel(orderId = "ord_1", orderType = "subscribe")
        assertEquals("Subscribe", subOrder.displayOrderType)

        val likeOrder = OrderModel(orderId = "ord_2", orderType = "like")
        assertEquals("Like", likeOrder.displayOrderType)

        val viewsOrder = OrderModel(orderId = "ord_3", orderType = "views")
        assertEquals("Views", viewsOrder.displayOrderType)
    }

    @Test
    fun testOrderModelMapSerialization() {
        val order = OrderModel(
            orderId = "ORD_12345",
            createdByUserId = "user_A",
            targetUserId = "user_B",
            channelId = "UC1234567890",
            channelName = "TechChannel",
            videoId = "vid_abc123",
            videoTitle = "Android Compose Tutorial",
            orderType = "views",
            requestedCount = 50,
            completedCount = 10,
            remainingCount = 40,
            status = "active",
            createdAt = 1700000000000L,
            updatedAt = 1700000500000L
        )

        val map = order.toMap()
        assertEquals("ORD_12345", map["orderId"])
        assertEquals("user_A", map["createdByUserId"])
        assertEquals("user_B", map["targetUserId"])
        assertEquals("UC1234567890", map["channelId"])
        assertEquals("TechChannel", map["channelName"])
        assertEquals("vid_abc123", map["videoId"])
        assertEquals("Android Compose Tutorial", map["videoTitle"])
        assertEquals("views", map["orderType"])
        assertEquals(50, map["requestedCount"])
        assertEquals(10, map["completedCount"])
        assertEquals(40, map["remainingCount"])
        assertEquals("active", map["status"])
        assertEquals(1700000000000L, map["createdAt"])
        assertEquals(1700000500000L, map["updatedAt"])
    }

    @Test
    fun testOrderEligibilityConditions() {
        val eligibleOrder = OrderModel(status = "active", remainingCount = 10)
        assertTrue(eligibleOrder.status == "active" && eligibleOrder.remainingCount > 0)

        val completedOrder = OrderModel(status = "completed", remainingCount = 0)
        assertFalse(completedOrder.status == "active" && completedOrder.remainingCount > 0)

        val inactiveOrder = OrderModel(status = "pending", remainingCount = 5)
        assertFalse(inactiveOrder.status == "active" && inactiveOrder.remainingCount > 0)
    }

    @Test
    fun testTunoNotificationModelSerialization() {
        val notif = TunoNotification(
            id = "notif_123",
            title = "Order Created",
            message = "Your order was created successfully.",
            type = "order",
            userId = "user_A",
            orderId = "ORD_12345",
            timestamp = 1700000000000L,
            isRead = false
        )

        val map = notif.toMap()
        assertEquals("notif_123", map["id"])
        assertEquals("Order Created", map["title"])
        assertEquals("Your order was created successfully.", map["message"])
        assertEquals("order", map["type"])
        assertEquals("user_A", map["userId"])
        assertEquals("ORD_12345", map["orderId"])
        assertEquals(1700000000000L, map["timestamp"])
        assertEquals(false, map["isRead"])
    }
}
