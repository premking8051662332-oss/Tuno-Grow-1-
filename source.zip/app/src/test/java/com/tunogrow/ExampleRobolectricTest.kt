package com.tunogrow

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.tunogrow.config.AppConfig
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Tuno Grow", appName)
  }

  @Test
  fun `verify updated support email website and telegram config`() {
    assertEquals("officialtunosupport.@gmail.com", AppConfig.SUPPORT_EMAIL)
    assertEquals("https://tunoofficial1.blogspot.com", AppConfig.OFFICIAL_WEBSITE_URL)
    assertEquals("https://tunoofficial1.blogspot.com", AppConfig.OUR_WEBSITE_URL)
    assertEquals("https://t.me/Tuno_Grow", AppConfig.TELEGRAM_CHANNEL_URL)
    assertEquals("http://t.me/TunoGrow_Bot", AppConfig.TELEGRAM_GROUP_URL)
  }
}
