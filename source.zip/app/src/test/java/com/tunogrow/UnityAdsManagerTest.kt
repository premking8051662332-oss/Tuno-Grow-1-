package com.tunogrow

import androidx.test.core.app.ApplicationProvider
import android.content.Context
import com.tunogrow.ads.UnityAdsManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class UnityAdsManagerTest {

  @Test
  fun testUnityAdsConfigurationAndPlacements() {
    // Game ID verification
    assertEquals("800405803", UnityAdsManager.GAME_ID)

    // Interstitial Placements
    assertEquals("BP_Interstitial_Android", UnityAdsManager.PLACEMENT_INTERSTITIAL_PRIMARY)
    assertEquals("Interstitial_Android", UnityAdsManager.PLACEMENT_INTERSTITIAL_FALLBACK)

    // Rewarded Placements
    assertEquals("BP_Rewarded_Android", UnityAdsManager.PLACEMENT_REWARDED_PRIMARY)
    assertEquals("Rewarded_Android", UnityAdsManager.PLACEMENT_REWARDED_FALLBACK)

    // Banner Placements
    assertEquals("BP_Banner_Android", UnityAdsManager.PLACEMENT_BANNER_PRIMARY)
    assertEquals("Banner_Android", UnityAdsManager.PLACEMENT_BANNER_FALLBACK)
  }

  @Test
  fun testInitialState() {
    // Interstitial is initially not ready before load
    assertFalse(UnityAdsManager.isInterstitialReady())
  }

  @Test
  fun testTestModeToggleWithContext() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    // Default mode is live (testMode = false)
    assertFalse(UnityAdsManager.isTestMode(context))

    UnityAdsManager.setTestMode(context, true)
    assertTrue(UnityAdsManager.isTestMode(context))

    UnityAdsManager.setTestMode(context, false)
    assertFalse(UnityAdsManager.isTestMode(context))
  }
}
