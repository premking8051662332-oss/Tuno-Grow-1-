package com.tunogrow

import com.tunogrow.auth.GoogleAuthHelper
import com.tunogrow.network.YouTubeApiService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class YouTubeApiServiceTest {

    @Test
    fun testYouTubeReadOnlyScope() {
        assertEquals(
            "https://www.googleapis.com/auth/youtube.readonly",
            YouTubeApiService.REQUIRED_SCOPE
        )
    }

    @Test
    fun testYouTubeUploadScope() {
        assertEquals(
            "https://www.googleapis.com/auth/youtube.upload",
            YouTubeApiService.UPLOAD_SCOPE
        )
        assertEquals(
            "https://www.googleapis.com/auth/youtube.upload",
            GoogleAuthHelper.YOUTUBE_UPLOAD_SCOPE_STRING
        )
    }

    @Test
    fun testCombinedScopesContainsUploadAndReadOnly() {
        assertTrue(GoogleAuthHelper.COMBINED_SCOPES.contains("https://www.googleapis.com/auth/youtube.upload"))
        assertTrue(GoogleAuthHelper.COMBINED_SCOPES.contains("https://www.googleapis.com/auth/youtube.readonly"))
    }

    @Test
    fun testTargetProjectIs584614426055() {
        assertEquals("584614426055", YouTubeApiService.TARGET_PROJECT_NUMBER)
    }

    @Test
    fun testYouTubeApiKeyBelongsToProject584614426055() {
        val apiKey = YouTubeApiService.configuredApiKey

        // Must use the API key belonging to Google Cloud project 584614426055
        assertEquals("AIzaSyBcZPF6DCopmh4AuBAtWg2J3D9Xfik7hks", apiKey)
        assertFalse("API key must not be the restricted Firebase key", apiKey == "AIzaSyAQFjPnFb8qSRd-wiERJ3nik5_-UJ3u_QI")
    }

    @Test
    fun testNoYouTubeRequestUsesProject527632091487() {
        val apiKey = YouTubeApiService.configuredApiKey
        assertFalse(apiKey.contains("527632091487"))
        assertEquals("584614426055", YouTubeApiService.TARGET_PROJECT_NUMBER)
    }

    @Test
    fun testFirebaseProjectIntact() {
        // Keep existing Firebase authentication working
        val firebaseClientId = GoogleAuthHelper.WEB_CLIENT_ID
        assertTrue(firebaseClientId.startsWith("527632091487"))
    }
}
