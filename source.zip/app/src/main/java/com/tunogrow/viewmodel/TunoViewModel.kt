package com.tunogrow.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tunogrow.auth.GoogleAuthHelper
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.firestore.FieldValue
import com.tunogrow.model.*
import com.tunogrow.network.YouTubeApiService
import com.tunogrow.worker.AutoPublicWorker
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class TunoViewModel : ViewModel() {
  private val auth = FirebaseAuth.getInstance()
  private val db = FirebaseFirestore.getInstance()

  private val _userProfile = MutableStateFlow<UserProfile?>(null)
  val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

  private val _tasks = MutableStateFlow<List<TaskModel>>(emptyList())
  val tasks: StateFlow<List<TaskModel>> = _tasks.asStateFlow()

  private val _userCompletions = MutableStateFlow<List<TaskCompletionModel>>(emptyList())
  val userCompletions: StateFlow<List<TaskCompletionModel>> = _userCompletions.asStateFlow()

  private val _transactions = MutableStateFlow<List<CoinTransactionModel>>(emptyList())
  val transactions: StateFlow<List<CoinTransactionModel>> = _transactions.asStateFlow()

  private val _followerRequests = MutableStateFlow<List<FollowerRequestModel>>(emptyList())
  val followerRequests: StateFlow<List<FollowerRequestModel>> = _followerRequests.asStateFlow()

  // Real-time Order System: Orders created by current logged-in user
  private val _myOrders = MutableStateFlow<List<OrderModel>>(emptyList())
  val myOrders: StateFlow<List<OrderModel>> = _myOrders.asStateFlow()

  // Real-time Order System: Active community orders for task list
  private val _activeCommunityOrders = MutableStateFlow<List<OrderModel>>(emptyList())
  val activeCommunityOrders: StateFlow<List<OrderModel>> = _activeCommunityOrders.asStateFlow()

  // Real-time Order System: Completed order IDs for the current user (prevents duplicate completion)
  private val _completedOrderIds = MutableStateFlow<Set<String>>(emptySet())
  val completedOrderIds: StateFlow<Set<String>> = _completedOrderIds.asStateFlow()

  private val _adminSettings = MutableStateFlow(AdminSettingsModel())
  val adminSettings: StateFlow<AdminSettingsModel> = _adminSettings.asStateFlow()

  // Admin lists
  private val _adminUsers = MutableStateFlow<List<UserProfile>>(emptyList())
  val adminUsers: StateFlow<List<UserProfile>> = _adminUsers.asStateFlow()

  private val _adminAllCompletions = MutableStateFlow<List<TaskCompletionModel>>(emptyList())
  val adminAllCompletions: StateFlow<List<TaskCompletionModel>> = _adminAllCompletions.asStateFlow()

  private val _isLoading = MutableStateFlow(false)
  val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

  private val _loadingMessage = MutableStateFlow<String?>(null)
  val loadingMessage: StateFlow<String?> = _loadingMessage.asStateFlow()

  private val _actionMessage = MutableStateFlow<String?>(null)
  val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

  private val _configError = MutableStateFlow<Pair<String, String>?>(null)
  val configError: StateFlow<Pair<String, String>?> = _configError.asStateFlow()

  private val _noYouTubeChannelFound = MutableStateFlow(false)
  val noYouTubeChannelFound: StateFlow<Boolean> = _noYouTubeChannelFound.asStateFlow()

  private val _authRecoveryIntent = MutableStateFlow<Intent?>(null)
  val authRecoveryIntent: StateFlow<Intent?> = _authRecoveryIntent.asStateFlow()

  // In-memory OAuth access token for authorized API operations
  private val _youtubeAccessToken = MutableStateFlow<String?>(null)
  val youtubeAccessToken: StateFlow<String?> = _youtubeAccessToken.asStateFlow()

  // Real YouTube Video Upload state
  private val _uploadState = MutableStateFlow(com.tunogrow.model.VideoUploadState())
  val uploadState: StateFlow<com.tunogrow.model.VideoUploadState> = _uploadState.asStateFlow()

  // Scheduled YouTube Videos for Auto Public
  private val _scheduledVideos = MutableStateFlow<List<ScheduledVideoModel>>(emptyList())
  val scheduledVideos: StateFlow<List<ScheduledVideoModel>> = _scheduledVideos.asStateFlow()

  private val _activeScheduledVideo = MutableStateFlow<ScheduledVideoModel?>(null)
  val activeScheduledVideo: StateFlow<ScheduledVideoModel?> = _activeScheduledVideo.asStateFlow()

  // Saved Drafts and Scheduled Uploads
  private val _draftVideos = MutableStateFlow<List<com.tunogrow.model.DraftVideoModel>>(emptyList())
  val draftVideos: StateFlow<List<com.tunogrow.model.DraftVideoModel>> = _draftVideos.asStateFlow()

  // Reel feature StateFlow


  // Notifications StateFlow
  private val _notifications = MutableStateFlow<List<TunoNotification>>(emptyList())
  val notifications: StateFlow<List<TunoNotification>> = _notifications.asStateFlow()

  // Video Tasks / Views System
  private val _videoTasks = MutableStateFlow<List<VideoTaskModel>>(emptyList())
  val videoTasks: StateFlow<List<VideoTaskModel>> = _videoTasks.asStateFlow()

  private val _userVideoTaskProgress = MutableStateFlow<Map<String, UserVideoTaskProgress>>(emptyMap())
  val userVideoTaskProgress: StateFlow<Map<String, UserVideoTaskProgress>> = _userVideoTaskProgress.asStateFlow()

  // Stored GoogleSignInAccount for reconnecting / re-authorizing after recovery intent
  var pendingGoogleAccount: GoogleSignInAccount? = null
    private set

  private var userListener: ListenerRegistration? = null
  private var tasksListener: ListenerRegistration? = null
  private var completionsListener: ListenerRegistration? = null
  private var transactionsListener: ListenerRegistration? = null
  private var requestsListener: ListenerRegistration? = null
  private var scheduledVideosListener: ListenerRegistration? = null
  private var myOrdersListener: ListenerRegistration? = null
  private var activeCommunityOrdersListener: ListenerRegistration? = null
  private var orderCompletionsListener: ListenerRegistration? = null
  private var videoTasksListener: ListenerRegistration? = null
  private var userVideoTasksListener: ListenerRegistration? = null
  private var countdownJob: Job? = null

  init {
    loadSettings()
    loadNotifications()
    auth.currentUser?.uid?.let { uid ->
      startListeners(uid)
    }
  }

  fun clearActionMessage() {
    _actionMessage.value = null
    _configError.value = null
  }

  fun clearRecoveryIntent() {
    _authRecoveryIntent.value = null
  }

  fun clearNoChannelFound() {
    _noYouTubeChannelFound.value = false
  }

  fun setPendingGoogleAccount(account: GoogleSignInAccount?) {
    pendingGoogleAccount = account
  }

  fun onConsentRecoveryGranted(context: Context, onResult: (Boolean, String?) -> Unit) {
    val account = pendingGoogleAccount ?: GoogleSignIn.getLastSignedInAccount(context)
    if (account != null) {
      connectYouTubeChannelWithAccount(context, account, onResult)
    } else {
      onResult(false, "YouTube authorization was not completed.")
    }
  }

  private var currentListeningUid: String? = null

  fun refreshForUser() {
    val uid = auth.currentUser?.uid
    if (uid != null) {
      if (currentListeningUid != uid) {
        startListeners(uid)
      }
    } else {
      currentListeningUid = null
      clearListeners()
    }
  }

  private fun clearListeners() {
    currentListeningUid = null
    userListener?.remove()
    tasksListener?.remove()
    completionsListener?.remove()
    transactionsListener?.remove()
    requestsListener?.remove()
    scheduledVideosListener?.remove()
    myOrdersListener?.remove()
    activeCommunityOrdersListener?.remove()
    orderCompletionsListener?.remove()
    videoTasksListener?.remove()
    userVideoTasksListener?.remove()
    countdownJob?.cancel()
    _userProfile.value = null
    _tasks.value = emptyList()
    _userCompletions.value = emptyList()
    _transactions.value = emptyList()
    _followerRequests.value = emptyList()
    _myOrders.value = emptyList()
    _activeCommunityOrders.value = emptyList()
    _completedOrderIds.value = emptySet()
    _scheduledVideos.value = emptyList()
    _activeScheduledVideo.value = null
    _videoTasks.value = emptyList()
    _userVideoTaskProgress.value = emptyMap()
  }

  private fun startListeners(uid: String) {
    clearListeners()
    currentListeningUid = uid

    // 1. User Profile listener
    userListener = db.collection("users").document(uid)
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null && snapshot.exists()) {
          val profile = snapshot.toObject(UserProfile::class.java)
          _userProfile.value = profile
        } else {
          val email = auth.currentUser?.email ?: ""
          val profile = UserProfile(
            uid = uid,
            email = email,
            displayName = auth.currentUser?.displayName ?: email.substringBefore("@"),
            photoURL = auth.currentUser?.photoUrl?.toString() ?: "",
            coins = 0,
            totalEarned = 0,
            createdAt = System.currentTimeMillis(),
            lastLoginAt = System.currentTimeMillis()
          )
          db.collection("users").document(uid).set(profile.toMap())
          _userProfile.value = profile
        }
      }

    // 2. Active Tasks listener
    tasksListener = db.collection("tasks")
      .whereEqualTo("status", "active")
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null) {
          val list = snapshot.documents.mapNotNull { it.toObject(TaskModel::class.java) }
            .sortedByDescending { it.createdAt }
          _tasks.value = list
        }
      }

    // 3. User Completions listener
    completionsListener = db.collection("taskCompletions")
      .whereEqualTo("workerUid", uid)
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null) {
          val list = snapshot.documents.mapNotNull { it.toObject(TaskCompletionModel::class.java) }
          _userCompletions.value = list
          val legacySet = list.map { it.taskId }.filter { it.isNotBlank() }.toSet()
          _completedOrderIds.value = _completedOrderIds.value + legacySet
        }
      }

    // 4. Coin Transactions listener
    transactionsListener = db.collection("coinTransactions")
      .whereEqualTo("uid", uid)
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null) {
          val list = snapshot.documents.mapNotNull { it.toObject(CoinTransactionModel::class.java) }
            .sortedByDescending { it.createdAt }
          _transactions.value = list
        }
      }

    // 5. Follower Requests listener
    requestsListener = db.collection("followerRequests")
      .whereEqualTo("uid", uid)
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null) {
          val list = snapshot.documents.mapNotNull { it.toObject(FollowerRequestModel::class.java) }
            .sortedByDescending { it.createdAt }
          _followerRequests.value = list
        }
      }

    // 6. Scheduled YouTube Videos listener for Auto Public
    scheduledVideosListener = db.collection("scheduledVideos")
      .whereEqualTo("userId", uid)
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null) {
          val list = snapshot.documents.mapNotNull { doc ->
            doc.data?.let { ScheduledVideoModel.fromMap(it) }
          }.sortedByDescending { it.uploadedAt }
          _scheduledVideos.value = list

          // Prefer currently scheduled job or the most recent job
          val active = list.firstOrNull { it.status == "scheduled" }
            ?: list.firstOrNull()

          _activeScheduledVideo.value = active

        }
      }

    // 7. Saved Drafts listener removed

    // 8 & 9. Unified Orders Listener (Realtime: syncs creator's orders and community task list)
    myOrdersListener = db.collection("orders")
      .addSnapshotListener { snapshot, error ->
        if (error != null) {
          android.util.Log.e("TunoViewModel", "Error listening to orders", error)
          return@addSnapshotListener
        }
        if (snapshot != null) {
          val allOrders = snapshot.documents.mapNotNull { doc ->
            try {
              val orderId = doc.getString("orderId") ?: doc.id
              val createdBy = doc.getString("createdByUserId")
                ?: doc.getString("userId")
                ?: doc.getString("uid")
                ?: ""
              val createdByName = doc.getString("createdByUserName") ?: ""
              val targetId = doc.getString("targetUserId") ?: ""
              val targetName = doc.getString("targetUserName") ?: ""
              val channelId = doc.getString("channelId") ?: ""
              val channelName = doc.getString("channelName") ?: ""
              val videoId = doc.getString("videoId") ?: ""
              val videoTitle = doc.getString("videoTitle") ?: ""
              val videoThumbnail = doc.getString("videoThumbnail") ?: ""
              val orderType = doc.getString("orderType") ?: "subscribe"
              val requested = (doc.getLong("requestedCount") ?: doc.getLong("quantity") ?: doc.getLong("targetSubscribers") ?: 10L).toInt()
              val completed = (doc.getLong("completedCount") ?: doc.getLong("currentSubscribers") ?: 0L).toInt()
              val remaining = (doc.getLong("remainingCount") ?: maxOf(0, requested - completed).toLong()).toInt()
              val coinCost = doc.getLong("coinCost") ?: 0L
              val status = doc.getString("status") ?: "active"
              val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
              val updatedAt = doc.getLong("updatedAt") ?: createdAt

              OrderModel(
                orderId = orderId,
                createdByUserId = createdBy,
                createdByUserName = createdByName,
                targetUserId = targetId,
                targetUserName = targetName,
                channelId = channelId,
                channelName = channelName,
                videoId = videoId,
                videoTitle = videoTitle,
                videoThumbnail = videoThumbnail,
                orderType = orderType,
                requestedCount = requested,
                completedCount = completed,
                remainingCount = remaining,
                coinCost = coinCost,
                status = status,
                createdAt = createdAt,
                updatedAt = updatedAt
              )
            } catch (_: Exception) {
              null
            }
          }

          // 1. My Orders: real-time updates for orders created by this account
          _myOrders.value = allOrders
            .filter { it.createdByUserId == uid || (it.createdByUserId.isBlank() && it.targetUserId == uid) }
            .sortedByDescending { it.createdAt }

          // 2. Active Community Orders: real-time list for community tasks (status == active, remaining > 0)
          _activeCommunityOrders.value = allOrders
            .filter { it.status.equals("active", ignoreCase = true) && it.remainingCount > 0 && it.completedCount < it.requestedCount }
            .sortedByDescending { it.createdAt }
        }
      }

    // 10. Order Completions Listener for Current User (Realtime: userId == uid)
    orderCompletionsListener = db.collection("orderCompletions")
      .whereEqualTo("userId", uid)
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null) {
          val set = snapshot.documents.mapNotNull { it.getString("orderId") }.toSet()
          _completedOrderIds.value = _completedOrderIds.value + set
        }
      }

    // 11. Video Tasks Listener (Realtime: videoTasks collection + views orders)
    videoTasksListener = db.collection("videoTasks")
      .addSnapshotListener { snapshot, _ ->
        val list = mutableListOf<VideoTaskModel>()
        if (snapshot != null) {
          snapshot.documents.forEach { doc ->
            try {
              val taskId = doc.getString("taskId") ?: doc.id
              val videoId = doc.getString("videoId") ?: ""
              val title = doc.getString("title") ?: "Watch Video"
              val thumbnail = doc.getString("thumbnail") ?: (if (videoId.isNotBlank()) "https://img.youtube.com/vi/$videoId/hqdefault.jpg" else "")
              val requiredWatchTime = (doc.getLong("requiredWatchTime") ?: 45L).toInt()
              val rewardCoins = doc.getLong("rewardCoins") ?: 10L
              val active = doc.getBoolean("active") ?: true
              val channelTitle = doc.getString("channelTitle") ?: ""
              val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
              if (active && videoId.isNotBlank() && !taskId.startsWith("vid_task_")) {
                list.add(
                  VideoTaskModel(
                    taskId = taskId,
                    videoId = videoId,
                    title = title,
                    thumbnail = thumbnail,
                    requiredWatchTime = requiredWatchTime,
                    rewardCoins = rewardCoins,
                    active = active,
                    channelTitle = channelTitle,
                    createdAt = createdAt
                  )
                )
              }
            } catch (_: Exception) {}
          }
        }

        // Also merge active community orders of type "views" with valid videoId
        _activeCommunityOrders.value.forEach { order ->
          if (order.orderType.equals("views", ignoreCase = true) && order.videoId.isNotBlank()) {
            if (list.none { it.taskId == order.orderId || it.videoId == order.videoId }) {
              list.add(
                VideoTaskModel(
                  taskId = order.orderId,
                  videoId = order.videoId,
                  title = order.videoTitle.ifBlank { "Watch Video: ${order.channelName}" },
                  thumbnail = order.videoThumbnail.ifBlank { "https://img.youtube.com/vi/${order.videoId}/hqdefault.jpg" },
                  requiredWatchTime = 45,
                  rewardCoins = 10L,
                  active = true,
                  channelTitle = order.channelName,
                  createdAt = order.createdAt
                )
              )
            }
          }
        }

        _videoTasks.value = list.sortedByDescending { it.createdAt }
      }

    // 12. User Video Tasks Progress Listener for Current User (userVideoTasks)
    userVideoTasksListener = db.collection("userVideoTasks")
      .whereEqualTo("userId", uid)
      .addSnapshotListener { snapshot, _ ->
        if (snapshot != null) {
          val map = mutableMapOf<String, UserVideoTaskProgress>()
          snapshot.documents.forEach { doc ->
            try {
              val taskId = doc.getString("taskId") ?: ""
              val status = doc.getString("status") ?: "available"
              val startedAt = doc.getLong("startedAt") ?: 0L
              val completedAt = doc.getLong("completedAt") ?: 0L
              val rewardGranted = doc.getBoolean("rewardGranted") ?: false
              if (taskId.isNotBlank()) {
                map[taskId] = UserVideoTaskProgress(
                  taskId = taskId,
                  userId = uid,
                  status = status,
                  startedAt = startedAt,
                  completedAt = completedAt,
                  rewardGranted = rewardGranted
                )
              }
            } catch (_: Exception) {}
          }
          _userVideoTaskProgress.value = map
        }
      }
  }

  private fun loadSettings() {
    viewModelScope.launch {
      try {
        val doc = db.collection("config").document("settings").get().await()
        if (doc.exists()) {
          val settings = doc.toObject(AdminSettingsModel::class.java)
          if (settings != null) {
            _adminSettings.value = settings
          }
        } else {
          val defaultSettings = AdminSettingsModel()
          db.collection("config").document("settings").set(defaultSettings.toMap())
          _adminSettings.value = defaultSettings
        }
      } catch (_: Exception) {}
    }
  }

  /**
   * Refreshes the connected YouTube channel statistics using the official YouTube Data API v3 mine=true
   */
  fun refreshYouTubeChannel(context: Context, onResult: (Boolean, String?) -> Unit) {
    if (_isLoading.value) return
    val uid = auth.currentUser?.uid ?: _userProfile.value?.uid
    if (uid == null) {
      onResult(false, "User not logged in")
      return
    }

    viewModelScope.launch {
      _isLoading.value = true
      _loadingMessage.value = "Refreshing channel..."
      _configError.value = null
      _noYouTubeChannelFound.value = false

      try {
        val lastAccount = GoogleSignIn.getLastSignedInAccount(context)
        if (lastAccount == null) {
          onResult(false, "Please sign in with Google to authorize YouTube access")
          return@launch
        }

        val tokenResult = GoogleAuthHelper.getAccessTokenForAccount(
          context = context,
          account = lastAccount,
          scope = GoogleAuthHelper.YOUTUBE_READ_SCOPE_STRING
        )
        if (tokenResult.isFailure) {
          val exc = tokenResult.exceptionOrNull()
          if (exc is UserRecoverableAuthException) {
            _authRecoveryIntent.value = exc.intent
            onResult(false, "Permission required")
            return@launch
          }
          val safeMsg = when (exc) {
            is java.io.IOException -> "Network error. Please try again."
            is com.google.android.gms.auth.GoogleAuthException -> {
              val msg = exc.message ?: ""
              when {
                msg.equals("ERROR", ignoreCase = true) || msg.contains("bad authentication", ignoreCase = true) || msg.contains("invalid_grant", ignoreCase = true) || msg.contains("NEED_PERMISSION", ignoreCase = true) ->
                  "YouTube authorization was not completed. Please try again."
                msg.contains("DEVELOPER_ERROR", ignoreCase = true) || msg.contains("Unknown", ignoreCase = true) ->
                  "YouTube OAuth configuration is incorrect."
                msg.isNotBlank() ->
                  "YouTube connection failed: $msg"
                else ->
                  "YouTube authorization was not completed."
              }
            }
            else -> "YouTube connection failed: ${exc?.localizedMessage ?: "OAuth token retrieval failed"}"
          }
          onResult(false, safeMsg)
          return@launch
        }

        val token = tokenResult.getOrThrow()
        _loadingMessage.value = "Loading channel..."
        val apiResult = YouTubeApiService.fetchMyChannel(token)

        when (apiResult) {
          is YouTubeApiResult.Success -> {
            val channel = apiResult.channel
            val now = System.currentTimeMillis()
            val updates = mapOf<String, Any>(
              "youtubeConnected" to true,
              "youtubeChannelId" to channel.id,
              "youtubeChannelName" to channel.title,
              "youtubeChannelImage" to channel.imageUrl,
              "youtubeSubscriberCount" to channel.subscriberCount,
              "youtubeVideoCount" to channel.videoCount,
              "youtubeViewCount" to channel.viewCount,
              "youtubeSubscribers" to channel.subscriberCount,
              "youtubeVideos" to channel.videoCount,
              "youtubeViews" to channel.viewCount,
              "youtubeLastSyncedAt" to now
            )
            db.collection("users").document(uid).set(updates, SetOptions.merge()).await()
            val existing = _userProfile.value
            _userProfile.value = existing?.copy(
              youtubeConnected = true,
              youtubeChannelId = channel.id,
              youtubeChannelName = channel.title,
              youtubeChannelImage = channel.imageUrl,
              youtubeSubscriberCount = channel.subscriberCount,
              youtubeVideoCount = channel.videoCount,
              youtubeViewCount = channel.viewCount,
              youtubeSubscribers = channel.subscriberCount,
              youtubeVideos = channel.videoCount,
              youtubeViews = channel.viewCount,
              youtubeLastSyncedAt = now
            ) ?: UserProfile(
              uid = uid,
              email = auth.currentUser?.email ?: "",
              displayName = auth.currentUser?.displayName ?: channel.title,
              photoURL = auth.currentUser?.photoUrl?.toString() ?: channel.imageUrl,
              youtubeConnected = true,
              youtubeChannelId = channel.id,
              youtubeChannelName = channel.title,
              youtubeChannelImage = channel.imageUrl,
              youtubeSubscriberCount = channel.subscriberCount,
              youtubeVideoCount = channel.videoCount,
              youtubeViewCount = channel.viewCount,
              youtubeSubscribers = channel.subscriberCount,
              youtubeVideos = channel.videoCount,
              youtubeViews = channel.viewCount,
              youtubeLastSyncedAt = now
            )
            _actionMessage.value = "YouTube channel updated"
            onResult(true, "YouTube channel updated")
          }
          is YouTubeApiResult.NoChannelFound -> {
            _noYouTubeChannelFound.value = true
            val noChannelUpdates = mapOf<String, Any>(
              "youtubeConnected" to false,
              "youtubeChannelId" to "",
              "youtubeChannelName" to "",
              "youtubeLastSyncedAt" to System.currentTimeMillis()
            )
            db.collection("users").document(uid).set(noChannelUpdates, SetOptions.merge()).await()
            _userProfile.value = _userProfile.value?.copy(
              youtubeConnected = false,
              youtubeChannelId = "",
              youtubeChannelName = ""
            )
            onResult(false, "No YouTube channel is connected to this Google account.")
          }
          is YouTubeApiResult.ConfigError -> {
            _configError.value = Pair(apiResult.message, apiResult.setupGuide)
            onResult(false, apiResult.message)
          }
          is YouTubeApiResult.Failure -> {
            _configError.value = Pair(apiResult.error, "")
            onResult(false, apiResult.error)
          }
        }
      } catch (e: Exception) {
        val safeMsg = when (e) {
          is java.io.IOException -> "Network error. Please try again."
          else -> "YouTube connection failed: ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
        onResult(false, safeMsg)
      } finally {
        _isLoading.value = false
        _loadingMessage.value = null
      }
    }
  }

  /**
   * Connect YouTube channel for signed in Google account
   */
  fun connectYouTubeChannelWithAccount(
    context: Context,
    account: GoogleSignInAccount,
    onResult: (Boolean, String?) -> Unit
  ) {
    if (_isLoading.value) return
    pendingGoogleAccount = account
    val uid = auth.currentUser?.uid ?: _userProfile.value?.uid ?: account.id ?: return
    viewModelScope.launch {
      _isLoading.value = true
      _loadingMessage.value = "Connecting YouTube..."
      _configError.value = null
      _noYouTubeChannelFound.value = false

      try {
        val tokenResult = GoogleAuthHelper.getAccessTokenForAccount(
          context = context,
          account = account,
          scope = GoogleAuthHelper.YOUTUBE_READ_SCOPE_STRING,
          forceRefresh = false
        )
        if (tokenResult.isFailure) {
          val exc = tokenResult.exceptionOrNull()
          if (exc is UserRecoverableAuthException) {
            _authRecoveryIntent.value = exc.intent
            onResult(false, "Permission required")
            return@launch
          }
          val safeMsg = when (exc) {
            is java.io.IOException -> "Network error. Please try again."
            is com.google.android.gms.auth.GoogleAuthException -> {
              val msg = exc.message ?: ""
              when {
                msg.equals("ERROR", ignoreCase = true) || msg.contains("bad authentication", ignoreCase = true) || msg.contains("invalid_grant", ignoreCase = true) || msg.contains("NEED_PERMISSION", ignoreCase = true) ->
                  "YouTube authorization was not completed. Please try again."
                msg.contains("DEVELOPER_ERROR", ignoreCase = true) || msg.contains("Unknown", ignoreCase = true) ->
                  "YouTube OAuth configuration is incorrect."
                msg.isNotBlank() ->
                  "YouTube connection failed: $msg"
                else ->
                  "YouTube authorization was not completed."
              }
            }
            else -> "YouTube connection failed: ${exc?.localizedMessage ?: "OAuth token retrieval failed"}"
          }
          onResult(false, safeMsg)
          return@launch
        }

        val token = tokenResult.getOrThrow()
        _youtubeAccessToken.value = token
        try {
          context.getSharedPreferences("tuno_grow_profile_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("key_youtube_access_token", token)
            .apply()
        } catch (_: Exception) {}
        _loadingMessage.value = "Loading channel..."
        val apiResult = YouTubeApiService.fetchMyChannel(token)

        when (apiResult) {
          is YouTubeApiResult.Success -> {
            val channel = apiResult.channel
            val now = System.currentTimeMillis()
            val updates = mapOf<String, Any>(
              "youtubeConnected" to true,
              "youtubeChannelId" to channel.id,
              "youtubeChannelName" to channel.title,
              "youtubeChannelImage" to channel.imageUrl,
              "youtubeSubscriberCount" to channel.subscriberCount,
              "youtubeVideoCount" to channel.videoCount,
              "youtubeViewCount" to channel.viewCount,
              "youtubeSubscribers" to channel.subscriberCount,
              "youtubeVideos" to channel.videoCount,
              "youtubeViews" to channel.viewCount,
              "youtubeLastSyncedAt" to now
            )
            db.collection("users").document(uid).set(updates, SetOptions.merge()).await()
            val existing = _userProfile.value
            _userProfile.value = existing?.copy(
              youtubeConnected = true,
              youtubeChannelId = channel.id,
              youtubeChannelName = channel.title,
              youtubeChannelImage = channel.imageUrl,
              youtubeSubscriberCount = channel.subscriberCount,
              youtubeVideoCount = channel.videoCount,
              youtubeViewCount = channel.viewCount,
              youtubeSubscribers = channel.subscriberCount,
              youtubeVideos = channel.videoCount,
              youtubeViews = channel.viewCount,
              youtubeLastSyncedAt = now
            ) ?: UserProfile(
              uid = uid,
              email = auth.currentUser?.email ?: account.email ?: "",
              displayName = auth.currentUser?.displayName ?: channel.title,
              photoURL = auth.currentUser?.photoUrl?.toString() ?: channel.imageUrl,
              youtubeConnected = true,
              youtubeChannelId = channel.id,
              youtubeChannelName = channel.title,
              youtubeChannelImage = channel.imageUrl,
              youtubeSubscriberCount = channel.subscriberCount,
              youtubeVideoCount = channel.videoCount,
              youtubeViewCount = channel.viewCount,
              youtubeSubscribers = channel.subscriberCount,
              youtubeVideos = channel.videoCount,
              youtubeViews = channel.viewCount,
              youtubeLastSyncedAt = now
            )
            _actionMessage.value = "Connected YouTube Channel: ${channel.title}"
            onResult(true, "Connected successfully")
          }
          is YouTubeApiResult.NoChannelFound -> {
            _noYouTubeChannelFound.value = false
            val defaultName = account.displayName?.ifBlank { null } ?: account.email?.substringBefore("@") ?: "YouTube User"
            val now = System.currentTimeMillis()
            val fallbackUpdates = mapOf<String, Any>(
              "youtubeConnected" to true,
              "youtubeChannelId" to "",
              "youtubeChannelName" to defaultName,
              "youtubeLastSyncedAt" to now
            )
            db.collection("users").document(uid).set(fallbackUpdates, SetOptions.merge()).await()
            val existing = _userProfile.value
            _userProfile.value = existing?.copy(
              youtubeConnected = true,
              youtubeChannelId = "",
              youtubeChannelName = defaultName,
              youtubeLastSyncedAt = now
            ) ?: UserProfile(
              uid = uid,
              email = auth.currentUser?.email ?: account.email ?: "",
              displayName = defaultName,
              youtubeConnected = true,
              youtubeChannelId = "",
              youtubeChannelName = defaultName,
              youtubeLastSyncedAt = now
            )
            _actionMessage.value = "Connected YouTube Account: $defaultName"
            onResult(true, "YouTube account connected successfully!")
          }
          is YouTubeApiResult.ConfigError -> {
            _configError.value = Pair(apiResult.message, apiResult.setupGuide)
            onResult(false, apiResult.message)
          }
          is YouTubeApiResult.Failure -> {
            _configError.value = Pair(apiResult.error, "")
            onResult(false, apiResult.error)
          }
        }
      } catch (e: Exception) {
        val safeMsg = when (e) {
          is java.io.IOException -> "Network error. Please try again."
          else -> "YouTube connection failed: ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
        onResult(false, safeMsg)
      } finally {
        _isLoading.value = false
        _loadingMessage.value = null
      }
    }
  }

  


  fun disconnectYouTubeChannel(context: Context? = null, onResult: () -> Unit = {}) {
    val uid = auth.currentUser?.uid ?: _userProfile.value?.uid ?: return
    _youtubeAccessToken.value = null
    if (context != null) {
      try {
        context.getSharedPreferences("tuno_grow_profile_prefs", Context.MODE_PRIVATE)
          .edit()
          .remove("key_youtube_access_token")
          .apply()
        GoogleAuthHelper.getYouTubeSignInClient(context).signOut()
      } catch (_: Exception) {}
    }
    viewModelScope.launch {
      try {
        val disconnectUpdates = mapOf<String, Any>(
          "youtubeConnected" to false,
          "youtubeChannelId" to "",
          "youtubeChannelName" to "",
          "youtubeChannelImage" to "",
          "youtubeSubscribers" to "0",
          "youtubeVideos" to "0",
          "youtubeViews" to "0",
          "youtubeLastSyncedAt" to System.currentTimeMillis()
        )
        db.collection("users").document(uid).set(disconnectUpdates, SetOptions.merge()).await()
        _userProfile.value = _userProfile.value?.copy(
          youtubeConnected = false,
          youtubeChannelId = "",
          youtubeChannelName = "",
          youtubeChannelImage = "",
          youtubeSubscribers = "0",
          youtubeVideos = "0",
          youtubeViews = "0"
        )
        _actionMessage.value = "YouTube channel disconnected"
        onResult()
      } catch (_: Exception) {
        onResult()
      }
    }
  }

  fun completeTask(task: TaskModel, onResult: (Boolean, String) -> Unit) {
    val user = auth.currentUser
    if (user == null) {
      onResult(false, "Not logged in")
      return
    }
    val workerUid = user.uid

    // Prevent completing own task
    if (task.ownerUid == workerUid) {
      onResult(false, "You cannot complete your own task!")
      return
    }

    // Check if already completed
    val alreadyCompleted = _userCompletions.value.any { it.taskId == task.taskId }
    if (alreadyCompleted) {
      onResult(false, "You have already completed this task!")
      return
    }

    viewModelScope.launch {
      _isLoading.value = true
      try {
        val completionId = db.collection("taskCompletions").document().id
        val transactionId = db.collection("coinTransactions").document().id

        val completion = TaskCompletionModel(
          completionId = completionId,
          taskId = task.taskId,
          workerUid = workerUid,
          ownerUid = task.ownerUid,
          reward = task.reward,
          status = "verified",
          createdAt = System.currentTimeMillis()
        )

        val coinTx = CoinTransactionModel(
          transactionId = transactionId,
          uid = workerUid,
          amount = task.reward,
          type = "earn",
          description = "Completed subscribe task: ${task.title}",
          createdAt = System.currentTimeMillis()
        )

        db.runTransaction { transaction ->
          val userDocRef = db.collection("users").document(workerUid)
          val snapshot = transaction.get(userDocRef)
          val currentCoins = snapshot.getLong("coins") ?: 0
          val totalEarned = snapshot.getLong("totalEarned") ?: 0

          val newCoins = currentCoins + task.reward
          val newTotalEarned = totalEarned + task.reward

          transaction.update(userDocRef, mapOf(
            "coins" to newCoins,
            "totalEarned" to newTotalEarned
          ))

          transaction.set(db.collection("taskCompletions").document(completionId), completion.toMap())
          transaction.set(db.collection("coinTransactions").document(transactionId), coinTx.toMap())
          null
        }.await()

        _actionMessage.value = "Successfully earned ${task.reward} coins!"
        onResult(true, "Successfully earned ${task.reward} coins!")
      } catch (e: Exception) {
        onResult(false, e.localizedMessage ?: "Failed to complete task")
      } finally {
        _isLoading.value = false
      }
    }
  }

  fun createFollowerRequest(
    channelUrl: String,
    targetSubs: Int,
    channelId: String = "",
    channelTitle: String = "",
    category: String = "Follow & Seen",
    targetUsername: String = "",
    userAvatar: String = "",
    onResult: (Boolean, String) -> Unit
  ) {
    val user = auth.currentUser
    if (user == null) {
      onResult(false, "Not logged in")
      return
    }
    if (channelUrl.isBlank()) {
      onResult(false, "Please provide a valid YouTube channel URL")
      return
    }
    if (_userProfile.value?.isBanned == true) {
      onResult(false, "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha.")
      return
    }
    if (targetSubs < 5) {
      onResult(false, "Minimum subscribers request is 5")
      return
    }

    val costPerSub = _adminSettings.value.followerCostPerSub
    val totalCost = targetSubs * costPerSub
    val currentCoins = _userProfile.value?.coins ?: 0

    if (currentCoins < totalCost) {
      onResult(false, "Insufficient coins! You need $totalCost coins.")
      return
    }

    viewModelScope.launch {
      _isLoading.value = true
      try {
        val requestId = db.collection("followerRequests").document().id
        val taskId = db.collection("tasks").document().id
        val txId = db.collection("coinTransactions").document().id

        val request = FollowerRequestModel(
          requestId = requestId,
          uid = user.uid,
          youtubeChannelId = channelId,
          youtubeChannelTitle = channelTitle.ifEmpty { channelUrl.substringAfterLast("/") },
          youtubeChannelUrl = channelUrl.trim(),
          targetSubscribers = targetSubs,
          currentSubscribers = 0,
          coinCost = totalCost,
          status = "active",
          createdAt = System.currentTimeMillis(),
          category = category,
          targetUsername = targetUsername.ifBlank { channelTitle.ifEmpty { "User" } },
          userAvatar = userAvatar
        )

        val task = TaskModel(
          taskId = taskId,
          type = "subscribe",
          title = if (channelTitle.isNotEmpty()) "Subscribe to $channelTitle" else "Subscribe to ${channelUrl.substringAfterLast("/").ifEmpty { "Channel" }}",
          youtubeChannelUrl = channelUrl.trim(),
          ownerUid = user.uid,
          reward = costPerSub,
          status = "active",
          createdAt = System.currentTimeMillis()
        )

        val coinTx = CoinTransactionModel(
          transactionId = txId,
          uid = user.uid,
          amount = -totalCost,
          type = "spend",
          description = "Created subscriber campaign ($targetSubs subs)",
          createdAt = System.currentTimeMillis()
        )

        val normOrderType = when {
          category.equals("Like", ignoreCase = true) -> "like"
          category.equals("Views", ignoreCase = true) -> "views"
          else -> "subscribe"
        }
        val orderObj = OrderModel(
          orderId = requestId,
          createdByUserId = user.uid,
          createdByUserName = _userProfile.value?.displayName?.ifBlank { user.displayName ?: "Creator" } ?: "Creator",
          targetUserId = user.uid,
          targetUserName = targetUsername.ifBlank { channelTitle.ifEmpty { "Creator" } },
          channelId = channelId,
          channelName = channelTitle.ifEmpty { channelUrl.substringAfterLast("/") },
          videoId = "",
          videoTitle = "",
          videoThumbnail = userAvatar,
          orderType = normOrderType,
          requestedCount = targetSubs,
          completedCount = 0,
          remainingCount = targetSubs,
          coinCost = totalCost,
          status = "active",
          createdAt = System.currentTimeMillis(),
          updatedAt = System.currentTimeMillis()
        )

        db.runTransaction { transaction ->
          val userDocRef = db.collection("users").document(user.uid)
          val snap = transaction.get(userDocRef)
          val coins = snap.getLong("coins") ?: 0
          val spent = snap.getLong("totalSpent") ?: 0

          if (coins < totalCost) {
            throw Exception("Insufficient coins")
          }

          transaction.update(userDocRef, mapOf(
            "coins" to coins - totalCost,
            "totalSpent" to spent + totalCost
          ))

          transaction.set(db.collection("orders").document(requestId), orderObj.toMap())
          transaction.set(db.collection("followerRequests").document(requestId), request.toMap())
          transaction.set(db.collection("tasks").document(taskId), task.toMap())
          transaction.set(db.collection("coinTransactions").document(txId), coinTx.toMap())
          null
        }.await()

        _actionMessage.value = "Follower campaign created successfully!"
        onResult(true, "Campaign created!")
      } catch (e: Exception) {
        onResult(false, e.localizedMessage ?: "Failed to create campaign")
      } finally {
        _isLoading.value = false
      }
    }
  }

  // Admin methods
  fun loadAdminData() {
    viewModelScope.launch {
      try {
        val usersSnap = db.collection("users").get().await()
        _adminUsers.value = usersSnap.documents.mapNotNull { it.toObject(UserProfile::class.java) }

        val compSnap = db.collection("taskCompletions").get().await()
        _adminAllCompletions.value = compSnap.documents.mapNotNull { it.toObject(TaskCompletionModel::class.java) }
      } catch (_: Exception) {}
    }
  }

  fun adminUpdateCoins(targetUid: String, deltaCoins: Long, onResult: (Boolean) -> Unit) {
    viewModelScope.launch {
      try {
        val userRef = db.collection("users").document(targetUid)
        db.runTransaction { tx ->
          val snap = tx.get(userRef)
          val current = snap.getLong("coins") ?: 0
          tx.update(userRef, "coins", maxOf(0L, current + deltaCoins))
        }.await()
        loadAdminData()
        onResult(true)
      } catch (_: Exception) {
        onResult(false)
      }
    }
  }

  fun adminCreateTask(title: String, url: String, reward: Long, onResult: (Boolean) -> Unit) {
    val adminUid = auth.currentUser?.uid ?: "admin"
    viewModelScope.launch {
      try {
        val taskId = db.collection("tasks").document().id
        val task = TaskModel(
          taskId = taskId,
          type = "subscribe",
          title = title,
          youtubeChannelUrl = url,
          ownerUid = adminUid,
          reward = reward,
          status = "active",
          createdAt = System.currentTimeMillis()
        )
        db.collection("tasks").document(taskId).set(task.toMap()).await()
        onResult(true)
      } catch (_: Exception) {
        onResult(false)
      }
    }
  }

  fun adminUpdateSettings(reward: Long, cost: Long, onResult: (Boolean) -> Unit) {
    viewModelScope.launch {
      try {
        val newSettings = AdminSettingsModel(subscribeReward = reward, followerCostPerSub = cost)
        db.collection("config").document("settings").set(newSettings.toMap()).await()
        _adminSettings.value = newSettings
        onResult(true)
      } catch (_: Exception) {
        onResult(false)
      }
    }
  }



  fun addNotification(title: String, message: String, type: String = "coin", orderId: String = "", userId: String = "") {
    val newNotif = TunoNotification(
      title = title,
      message = message,
      type = type,
      orderId = orderId,
      userId = userId,
      timestamp = System.currentTimeMillis()
    )
    _notifications.value = listOf(newNotif) + _notifications.value.take(20)
  }

  fun markNotificationsAsRead() {
    _notifications.value = _notifications.value.map { it.copy(isRead = true) }
  }

  fun loadNotifications() {
    val notifs = mutableListOf<TunoNotification>()
    val current = _userProfile.value
    if (current != null && current.youtubeConnected) {
      notifs.add(
        TunoNotification(
          title = "YouTube Channel Synced",
          message = "Connected to @${current.youtubeChannelName}. Channel stats are live.",
          type = "sync"
        )
      )
    }
    notifs.add(
      TunoNotification(
        title = "Tuno Grow Creator Bonus",
        message = "Watch Shorts in Reel section or complete tasks to earn free coins!",
        type = "coin"
      )
    )
    _notifications.value = notifs
  }

  fun searchUserById(
    searchId: String,
    onResult: (UserProfile?, String?) -> Unit
  ) {
    val cleanId = searchId.trim()
    if (cleanId.isBlank()) {
      onResult(null, "कृपया कोई ID दर्ज करें")
      return
    }
    viewModelScope.launch {
      try {
        // 1. Direct document lookup by User ID
        val docSnap = db.collection("users").document(cleanId).get().await()
        if (docSnap.exists()) {
          val profile = docSnap.toObject(UserProfile::class.java)
          onResult(profile, null)
          return@launch
        }

        // 2. Lookup by YouTube Channel ID
        val queryByChannel = db.collection("users")
          .whereEqualTo("youtubeChannelId", cleanId)
          .limit(1)
          .get()
          .await()
        if (!queryByChannel.isEmpty) {
          val profile = queryByChannel.documents[0].toObject(UserProfile::class.java)
          onResult(profile, null)
          return@launch
        }

        // 3. Lookup by YouTube Channel Name / handle
        val queryByName = db.collection("users")
          .whereEqualTo("youtubeChannelName", cleanId)
          .limit(1)
          .get()
          .await()
        if (!queryByName.isEmpty) {
          val profile = queryByName.documents[0].toObject(UserProfile::class.java)
          onResult(profile, null)
          return@launch
        }

        // ID not found
        onResult(null, "ID नहीं मिली।")
      } catch (e: Exception) {
        onResult(null, "ID नहीं मिली।")
      }
    }
  }

  fun searchYouTubeChannels(
    query: String,
    onResult: (List<com.tunogrow.model.YouTubeChannelInfo>, String?) -> Unit
  ) {
    val clean = query.trim()
    if (clean.isBlank()) {
      onResult(emptyList(), "कृपया सर्च करने के लिए चैनल का नाम लिखें")
      return
    }
    viewModelScope.launch {
      val res = YouTubeApiService.searchChannels(clean)
      if (res.isSuccess) {
        val list = res.getOrDefault(emptyList())
        if (list.isEmpty()) {
          onResult(emptyList(), "YouTube channel नहीं मिला।")
        } else {
          onResult(list, null)
        }
      } else {
        onResult(emptyList(), res.exceptionOrNull()?.message ?: "YouTube channel नहीं मिला।")
      }
    }
  }

  fun getYouTubeChannelVideos(
    channelId: String,
    onResult: (List<com.tunogrow.model.YouTubeVideoInfo>, String?) -> Unit
  ) {
    if (channelId.isBlank()) {
      onResult(emptyList(), "चैनल ID अमान्य है")
      return
    }
    viewModelScope.launch {
      val res = YouTubeApiService.getChannelVideos(channelId)
      if (res.isSuccess) {
        onResult(res.getOrDefault(emptyList()), null)
      } else {
        onResult(emptyList(), res.exceptionOrNull()?.message ?: "वीडियो लोड करने में असमर्थ")
      }
    }
  }

  fun resolveYouTubeChannelByUrl(
    url: String,
    onResult: (com.tunogrow.model.YouTubeChannelInfo?, String?) -> Unit
  ) {
    val clean = url.trim()
    if (clean.isBlank()) {
      onResult(null, "कृपया YouTube Channel URL दर्ज करें")
      return
    }
    viewModelScope.launch {
      val res = YouTubeApiService.resolveChannelByUrl(clean)
      if (res.isSuccess) {
        onResult(res.getOrNull(), null)
      } else {
        onResult(null, res.exceptionOrNull()?.message ?: "YouTube Channel नहीं मिला")
      }
    }
  }

  fun createExternalOrder(
    channelId: String,
    channelName: String,
    videoId: String,
    videoTitle: String,
    videoThumbnail: String,
    actionType: String,
    targetUserId: String = "",
    targetUserName: String = "",
    quantity: Int = 10,
    costPerUnit: Long = 10L,
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    val user = auth.currentUser
    if (user == null) {
      onResult(false, "Please log in to place an order.")
      return
    }
    if (_userProfile.value?.isBanned == true) {
      onResult(false, "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha.")
      return
    }
    val createdByUserId = user.uid
    val createdByUserName = _userProfile.value?.displayName?.ifBlank { user.displayName ?: "Creator" } ?: "Creator"
    val totalCost = quantity.toLong() * costPerUnit
    val userCoins = _userProfile.value?.coins ?: 0L

    if (userCoins < totalCost) {
      onResult(false, "Not enough coins!")
      return
    }

    viewModelScope.launch {
      _isLoading.value = true
      try {
        val orderId = db.collection("orders").document().id
        val normalizedOrderType = when (actionType.lowercase()) {
          "like" -> "like"
          "views", "view" -> "views"
          else -> "subscribe"
        }

        val now = System.currentTimeMillis()
        val orderModel = OrderModel(
          orderId = orderId,
          createdByUserId = createdByUserId,
          createdByUserName = createdByUserName,
          targetUserId = targetUserId.trim(),
          targetUserName = targetUserName.ifBlank { channelName },
          channelId = channelId,
          channelName = channelName,
          videoId = videoId,
          videoTitle = videoTitle,
          videoThumbnail = videoThumbnail,
          orderType = normalizedOrderType,
          requestedCount = quantity,
          completedCount = 0,
          remainingCount = quantity,
          coinCost = totalCost,
          status = "active",
          createdAt = now,
          updatedAt = now
        )

        val txId = db.collection("coinTransactions").document().id
        val coinTx = CoinTransactionModel(
          transactionId = txId,
          uid = createdByUserId,
          amount = -totalCost,
          type = "spend",
          description = "Created ${orderModel.displayOrderType} order for $channelName ($quantity units)",
          createdAt = now
        )

        val legacyRequest = FollowerRequestModel(
          requestId = orderId,
          uid = createdByUserId,
          targetUserId = targetUserId.trim(),
          youtubeChannelId = channelId,
          youtubeChannelTitle = channelName,
          youtubeChannelUrl = if (channelId.isNotBlank()) "https://www.youtube.com/channel/$channelId" else "",
          videoId = videoId,
          videoTitle = videoTitle,
          videoThumbnail = videoThumbnail,
          actionType = normalizedOrderType,
          targetSubscribers = quantity,
          currentSubscribers = 0,
          coinCost = totalCost,
          status = "active",
          createdAt = now,
          category = orderModel.displayOrderType,
          targetUsername = channelName,
          userAvatar = videoThumbnail.ifBlank { "" }
        )

        db.runTransaction { transaction ->
          val userDocRef = db.collection("users").document(createdByUserId)
          val snap = transaction.get(userDocRef)
          val currentCoins = snap.getLong("coins") ?: 0L
          val spent = snap.getLong("totalSpent") ?: 0L

          if (currentCoins < totalCost) {
            throw Exception("Not enough coins!")
          }

          transaction.update(userDocRef, mapOf(
            "coins" to currentCoins - totalCost,
            "totalSpent" to spent + totalCost
          ))

          transaction.set(db.collection("orders").document(orderId), orderModel.toMap())
          transaction.set(db.collection("followerRequests").document(orderId), legacyRequest.toMap())
          transaction.set(db.collection("coinTransactions").document(txId), coinTx.toMap())
          null
        }.await()

        onResult(true, "Order placed successfully!")
      } catch (e: Exception) {
        android.util.Log.e("TunoViewModel", "Error saving order", e)
        val msg = e.localizedMessage ?: "Failed to place order"
        if (msg.contains("Not enough coins", ignoreCase = true) || msg.contains("Insufficient", ignoreCase = true)) {
          onResult(false, "Not enough coins!")
        } else {
          onResult(false, msg)
        }
      } finally {
        _isLoading.value = false
      }
    }
  }

  fun completeYouTubeAction(
    actionId: String,
    actionType: String,
    targetTitle: String,
    targetUrl: String,
    rewardCoins: Long = 10L,
    ownerUid: String = "",
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    val user = auth.currentUser
    if (user == null) {
      onResult(false, "Please log in to claim reward")
      return
    }
    val workerUid = user.uid

    if (ownerUid.isNotBlank() && ownerUid == workerUid) {
      onResult(false, "You cannot earn coins from your own channel/order!")
      return
    }

    if (_completedOrderIds.value.contains(actionId)) {
      onResult(false, "Task already completed")
      return
    }

    val actualRewardCoins = when (actionType.lowercase()) {
      "subscribe" -> 10L
      "views", "view" -> 8L
      "like" -> 5L
      else -> rewardCoins
    }

    viewModelScope.launch {
      _isLoading.value = true
      try {
        val now = System.currentTimeMillis()
        val txId = db.collection("coinTransactions").document().id
        val completionId = db.collection("taskCompletions").document().id

        db.runTransaction { transaction ->
          // ===================================================================
          // 1. ALL READS FIRST (Firestore requirement: all reads before writes)
          // ===================================================================
          val userDocRef = db.collection("users").document(workerUid)
          val userSnap = transaction.get(userDocRef)

          val orderRef = db.collection("orders").document(actionId)
          val orderSnap = transaction.get(orderRef)

          val taskHistoryRef = db.collection("tasks").document(actionId)
          val taskHistorySnap = transaction.get(taskHistoryRef)

          val compDocRef1 = db.collection("orderCompletions").document(actionId).collection("users").document(workerUid)
          val compSnap1 = transaction.get(compDocRef1)

          val compDocRef2 = db.collection("orderCompletions").document("${actionId}_${workerUid}")
          val compSnap2 = transaction.get(compDocRef2)

          val reqRef = db.collection("followerRequests").document(actionId)
          val reqSnap = transaction.get(reqRef)

          // ===================================================================
          // 2. CONDITION CHECKS IN THE MIDDLE (validate all before writes)
          // ===================================================================
          // Duplicate prevention
          if (compSnap1.exists() || compSnap2.exists()) {
            throw Exception("Task already completed")
          }

          var orderUpdates: Map<String, Any>? = null
          if (orderSnap.exists()) {
            val orderCreatedBy = orderSnap.getString("createdByUserId") ?: orderSnap.getString("userId") ?: ""
            if (orderCreatedBy == workerUid) {
              throw Exception("You cannot complete tasks on your own order!")
            }

            val orderStatus = orderSnap.getString("status") ?: "active"
            val requested = (orderSnap.getLong("requestedCount") ?: orderSnap.getLong("quantity") ?: orderSnap.getLong("targetSubscribers") ?: 10L).toInt()
            val completed = (orderSnap.getLong("completedCount") ?: orderSnap.getLong("currentSubscribers") ?: 0L).toInt()
            val remaining = (orderSnap.getLong("remainingCount") ?: maxOf(0, requested - completed).toLong()).toInt()

            if (!orderStatus.equals("active", ignoreCase = true) || remaining <= 0 || completed >= requested) {
              throw Exception("This order is already completed")
            }

            val newCompleted = completed + 1
            val newRemaining = maxOf(0, requested - newCompleted)
            val newStatus = if (newRemaining == 0 || newCompleted >= requested) "completed" else "active"

            orderUpdates = mapOf(
              "completedCount" to newCompleted,
              "remainingCount" to newRemaining,
              "status" to newStatus,
              "updatedAt" to now
            )
          }

          var reqUpdates: Map<String, Any>? = null
          if (reqSnap.exists()) {
            val currentSubs = reqSnap.getLong("currentSubscribers") ?: 0L
            val targetSubs = reqSnap.getLong("targetSubscribers") ?: 10L
            val newSubs = currentSubs + 1
            val reqStatus = if (newSubs >= targetSubs) "completed" else "active"
            reqUpdates = mapOf(
              "currentSubscribers" to newSubs,
              "status" to reqStatus
            )
          }

          val currentCoins = userSnap.getLong("coins") ?: 0L
          val totalEarned = userSnap.getLong("totalEarned") ?: 0L

          // ===================================================================
          // 3. ALL WRITES AT THE VERY END (atomic update & set)
          // ===================================================================
          // Update order document
          if (orderUpdates != null) {
            transaction.update(orderRef, orderUpdates)
          }

          // Update followerRequests document
          if (reqUpdates != null) {
            transaction.update(reqRef, reqUpdates)
          }

          // Record completion in orderCompletions (both nested and flat)
          val completionRecord = mapOf(
            "orderId" to actionId,
            "userId" to workerUid,
            "taskId" to actionId,
            "completedAt" to now
          )
          transaction.set(compDocRef1, completionRecord)
          transaction.set(compDocRef2, completionRecord)

          // Update worker coins & totalEarned (+10 coins)
          if (userSnap.exists()) {
            transaction.update(userDocRef, mapOf(
              "coins" to currentCoins + actualRewardCoins,
              "totalEarned" to totalEarned + actualRewardCoins
            ))
          } else {
            transaction.set(userDocRef, mapOf(
              "uid" to workerUid,
              "coins" to actualRewardCoins,
              "totalEarned" to actualRewardCoins
            ), com.google.firebase.firestore.SetOptions.merge())
          }

          // Record coinTransaction
          val coinTx = CoinTransactionModel(
            transactionId = txId,
            uid = workerUid,
            amount = actualRewardCoins,
            type = "earn",
            description = "Earned coins for YouTube $actionType: $targetTitle",
            createdAt = now
          )
          transaction.set(db.collection("coinTransactions").document(txId), coinTx.toMap())

          // Record taskCompletions for compatibility
          val legacyCompletion = TaskCompletionModel(
            completionId = completionId,
            taskId = actionId,
            workerUid = workerUid,
            ownerUid = ownerUid,
            reward = actualRewardCoins,
            status = "verified",
            createdAt = now
          )
          transaction.set(db.collection("taskCompletions").document(completionId), legacyCompletion.toMap())

          null
        }.await()

        // Update local set of completed orders immediately
        _completedOrderIds.value = _completedOrderIds.value + actionId

        onResult(true, "Successfully earned +$actualRewardCoins Coins!")
      } catch (e: Exception) {
        val msg = e.localizedMessage ?: "Failed to claim reward"
        if (msg.contains("Task already completed", ignoreCase = true)) {
          onResult(false, "Task already completed")
        } else if (msg.contains("already completed", ignoreCase = true)) {
          onResult(false, "This order is already completed")
        } else {
          onResult(false, msg)
        }
      } finally {
        _isLoading.value = false
      }
    }
  }

  suspend fun getFreshYouTubeAccessToken(context: Context, forceRefresh: Boolean = false): String? = withContext(Dispatchers.IO) {
    if (!forceRefresh) {
      val inMemory = _youtubeAccessToken.value
      if (!inMemory.isNullOrBlank()) {
        return@withContext inMemory
      }
      val prefs = context.getSharedPreferences("tuno_grow_profile_prefs", Context.MODE_PRIVATE)
      val saved = prefs.getString("key_youtube_access_token", null)
      if (!saved.isNullOrBlank()) {
        _youtubeAccessToken.value = saved
        return@withContext saved
      }
    }

    val account = GoogleSignIn.getLastSignedInAccount(context) ?: return@withContext null
    val result = GoogleAuthHelper.getAccessTokenForAccount(
      context = context,
      account = account,
      scope = GoogleAuthHelper.YOUTUBE_READ_SCOPE_STRING,
      forceRefresh = forceRefresh
    )
    val freshToken = result.getOrNull()
    if (!freshToken.isNullOrBlank()) {
      _youtubeAccessToken.value = freshToken
      try {
        context.getSharedPreferences("tuno_grow_profile_prefs", Context.MODE_PRIVATE)
          .edit()
          .putString("key_youtube_access_token", freshToken)
          .apply()
      } catch (_: Exception) {}
    }
    freshToken
  }

  fun executeLikeAction(
    context: Context,
    orderId: String,
    videoId: String,
    videoTitle: String,
    ownerUid: String,
    onResult: (Boolean, String) -> Unit
  ) {
    viewModelScope.launch {
      val token = getFreshYouTubeAccessToken(context) ?: ""
      if (videoId.isNotBlank()) {
        try {
          YouTubeApiService.rateVideo(token, videoId, "like")
        } catch (_: Exception) {}
      }

      completeYouTubeAction(
        actionId = orderId,
        actionType = "like",
        targetTitle = videoTitle,
        targetUrl = if (videoId.isNotBlank()) "https://www.youtube.com/watch?v=$videoId" else "https://www.youtube.com",
        rewardCoins = 5L,
        ownerUid = ownerUid,
        onResult = onResult
      )
    }
  }

  fun executeSubscribeAction(
    context: Context,
    orderId: String,
    channelId: String,
    channelName: String,
    ownerUid: String,
    onResult: (Boolean, String) -> Unit
  ) {
    verifyAndCompleteSubscription(
      context = context,
      orderId = orderId,
      channelId = channelId,
      channelName = channelName,
      ownerUid = ownerUid,
      onResult = onResult
    )
  }

  fun verifyAndCompleteSubscription(
    context: Context,
    orderId: String,
    channelId: String = "",
    targetChannelId: String = "",
    targetUrl: String = "",
    channelName: String,
    rewardCoins: Long = 10L,
    ownerUid: String,
    onResult: (Boolean, String) -> Unit
  ) {
    viewModelScope.launch {
      try {
        val user = auth.currentUser
        if (user == null) {
          onResult(false, "User not authenticated. Please log in.")
          return@launch
        }

        // Check if user has connected their YouTube channel / has Google sign-in
        val token = getFreshYouTubeAccessToken(context)
        if (token.isNullOrBlank()) {
          onResult(false, "Please connect your YouTube channel first to verify subscriptions.")
          return@launch
        }

        // Resolve channel ID
        val baseChannelId = if (channelId.isNotBlank()) channelId else targetChannelId
        var effectiveChannelId = baseChannelId.trim()
        if (effectiveChannelId.isBlank() && targetUrl.isNotBlank()) {
          if (targetUrl.contains("/channel/")) {
            effectiveChannelId = targetUrl.substringAfter("/channel/").substringBefore("/").substringBefore("?").trim()
          }
        }
        if (effectiveChannelId.isBlank() && targetUrl.isNotBlank()) {
          try {
            val res = YouTubeApiService.resolveChannelByUrl(targetUrl)
            if (res.isSuccess) {
              effectiveChannelId = res.getOrNull()?.id ?: ""
            }
          } catch (_: Exception) {}
        }

        if (effectiveChannelId.isBlank()) {
          onResult(false, "Channel not subscribed! Please subscribe on YouTube first.")
          return@launch
        }

        // Real YouTube Data API v3 verification:
        // GET https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true&forChannelId={targetChannelId}
        val checkRes = YouTubeApiService.checkSubscriptionVerification(token, effectiveChannelId)
        if (checkRes.isFailure) {
          val ex = checkRes.exceptionOrNull()
          if (ex is IllegalStateException && ex.message == "SESSION_EXPIRED") {
            _youtubeAccessToken.value = null
            try {
              context.getSharedPreferences("tuno_grow_profile_prefs", Context.MODE_PRIVATE)
                .edit()
                .remove("key_youtube_access_token")
                .apply()
            } catch (_: Exception) {}
            onResult(false, "Session expired, please click Disconnect and Reconnect YouTube")
            return@launch
          }
          val errorMsg = if (ex?.message == "MISSING_TOKEN") {
            "Please connect your YouTube channel first to verify subscriptions."
          } else {
            "Session expired, please click Disconnect and Reconnect YouTube"
          }
          onResult(false, errorMsg)
          return@launch
        }

        val isSubscribed = checkRes.getOrDefault(false)
        if (!isSubscribed) {
          // Empty response: User did not subscribe. Do NOT add coins.
          val connectedName = _userProfile.value?.youtubeChannelName?.trim() ?: ""
          val handleOrName = if (connectedName.isNotBlank()) {
            if (connectedName.startsWith("@")) connectedName else "@$connectedName"
          } else {
            "@cartoonGalaxyToonprem"
          }
          val warningMsg = "Subscription not detected yet. Please make sure you subscribed with the connected channel ($handleOrName) and your subscriptions are public, then try again."
          onResult(false, warningMsg)
          return@launch
        }

        // Genuine subscription confirmed: credit +10 coins in Firestore
        completeYouTubeAction(
          actionId = orderId,
          actionType = "subscribe",
          targetTitle = channelName,
          targetUrl = if (effectiveChannelId.isNotBlank()) "https://www.youtube.com/channel/$effectiveChannelId" else targetUrl.ifBlank { "https://www.youtube.com" },
          rewardCoins = 10L,
          ownerUid = ownerUid
        ) { success, msg ->
          if (success) {
            if (effectiveChannelId.isNotBlank()) {
              try {
                db.collection("users").document(user.uid)
                  .collection("completedSubscriptions").document(effectiveChannelId)
                  .set(mapOf(
                    "channelId" to effectiveChannelId,
                    "channelTitle" to channelName,
                    "orderId" to orderId,
                    "completedAt" to System.currentTimeMillis(),
                    "status" to "active"
                  ))
              } catch (_: Exception) {}
            }
            addNotification(
              title = "Subscription Verified!",
              message = "Subscription verified! +10 Coins added.",
              type = "order",
              orderId = orderId
            )
            onResult(true, "Subscription verified! +10 Coins added.")
          } else {
            onResult(false, msg)
          }
        }
      } catch (e: Exception) {
        onResult(false, e.localizedMessage ?: "Verification error occurred")
      }
    }
  }

  /**
   * Penalty check logic: Deduct 10 coins, increment strikeCount, and if strikeCount >= 1 set isBanned = true in Firestore.
   */
  fun applyUnsubscribePenalty(
    channelName: String,
    channelId: String = "",
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    val user = auth.currentUser ?: return
    val uid = user.uid
    viewModelScope.launch {
      try {
        val userRef = db.collection("users").document(uid)
        var isNowBanned = false
        var updatedStrike = 1L
        var remainingCoins = 0L

        db.runTransaction { tx ->
          val snap = tx.get(userRef)
          val currentCoins = snap.getLong("coins") ?: 0L
          val newCoins = maxOf(0L, currentCoins - 10L)
          remainingCoins = newCoins
          val currentStrikes = snap.getLong("strikeCount") ?: snap.getLong("warnings") ?: 0L
          val newStrikes = currentStrikes + 1L
          updatedStrike = newStrikes
          isNowBanned = newStrikes >= 1L

          val updates = mutableMapOf<String, Any>(
            "coins" to newCoins,
            "strikeCount" to newStrikes,
            "warnings" to newStrikes,
            "lastWarningReason" to "Unsubscription detected from channel $channelName"
          )
          if (isNowBanned) {
            updates["isBanned"] = true
            updates["banReason"] = "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha."
          }
          tx.update(userRef, updates)

          val txId = db.collection("coinTransactions").document().id
          val coinTx = CoinTransactionModel(
            transactionId = txId,
            uid = uid,
            amount = -10L,
            type = "deduct",
            description = "Penalty: Unsubscribed from channel $channelName (-10 coins)",
            createdAt = System.currentTimeMillis()
          )
          tx.set(db.collection("coinTransactions").document(txId), coinTx.toMap())
          null
        }.await()

        if (channelId.isNotBlank()) {
          try {
            db.collection("users").document(uid)
              .collection("completedSubscriptions").document(channelId)
              .update("status", "unsubscribed")
          } catch (_: Exception) {}
        }

        _userProfile.value = _userProfile.value?.copy(
          coins = remainingCoins,
          strikeCount = updatedStrike,
          isBanned = isNowBanned,
          banReason = if (isNowBanned) "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha." else ""
        )

        val banMsg = "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha."
        addNotification(
          title = if (isNowBanned) "Account Banned" else "Account Warning",
          message = if (isNowBanned) banMsg else "Unsubscription detected! 10 coins deducted. Repeated action will result in a permanent ban.",
          type = "info"
        )
        onResult(true, if (isNowBanned) banMsg else "Warning: Unsubscription detected! 10 coins deducted.")
      } catch (e: Exception) {
        onResult(false, e.localizedMessage ?: "Failed to apply penalty")
      }
    }
  }

  /**
   * Unsubscribe Check Logic:
   * Verifies user's previously completed subscriptions using YouTube Data API v3:
   * GET https://www.googleapis.com/youtube/v3/subscriptions?part=snippet&mine=true&forChannelId={targetChannelId}
   * If unsubscribed (items.length == 0), deducts 10 coins, increments strikeCount, and sets isBanned = true.
   */
  fun checkPreviousSubscriptionsAntiUnsubscribe(
    context: Context,
    onBannedOrPenalty: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    val user = auth.currentUser ?: return
    val uid = user.uid

    if (_userProfile.value?.isBanned == true) {
      onBannedOrPenalty(true, "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha.")
      return
    }

    viewModelScope.launch {
      try {
        val token = getFreshYouTubeAccessToken(context)
        if (token.isNullOrBlank()) {
          return@launch
        }

        val subsSnap = db.collection("users").document(uid)
          .collection("completedSubscriptions")
          .whereEqualTo("status", "active")
          .limit(10)
          .get()
          .await()

        if (subsSnap.isEmpty) {
          return@launch
        }

        for (doc in subsSnap.documents) {
          val targetChannelId = doc.getString("channelId") ?: doc.id
          val channelTitle = doc.getString("channelTitle") ?: "Target Channel"
          if (targetChannelId.isBlank()) continue

          val checkRes = YouTubeApiService.checkSubscriptionVerification(token, targetChannelId)
          if (checkRes.isSuccess) {
            val isStillSubscribed = checkRes.getOrDefault(true)
            if (!isStillSubscribed) {
              applyUnsubscribePenalty(channelTitle, targetChannelId) { success, msg ->
                if (success) {
                  onBannedOrPenalty(true, msg)
                }
              }
              break
            }
          }
        }
      } catch (e: Exception) {
        Log.e("TunoViewModel", "Error in checkPreviousSubscriptionsAntiUnsubscribe", e)
      }
    }
  }

  fun completeInternalAppTask(
    taskId: String,
    taskTitle: String,
    taskCategory: String,
    rewardCoins: Long,
    onResult: (Boolean, String) -> Unit
  ) {
    val user = auth.currentUser
    if (user == null) {
      onResult(false, "Please login first to claim rewards")
      return
    }
    val workerUid = user.uid

    // Check if already completed in cache
    val alreadyCompleted = _userCompletions.value.any { it.taskId == taskId }
    if (alreadyCompleted) {
      onResult(false, "You have already completed this task!")
      return
    }

    viewModelScope.launch {
      _isLoading.value = true
      try {
        val completionId = "comp_${workerUid}_$taskId"
        val transactionId = db.collection("coinTransactions").document().id

        val completion = TaskCompletionModel(
          completionId = completionId,
          taskId = taskId,
          workerUid = workerUid,
          ownerUid = "system",
          reward = rewardCoins,
          status = "verified",
          createdAt = System.currentTimeMillis()
        )

        val coinTx = CoinTransactionModel(
          transactionId = transactionId,
          uid = workerUid,
          amount = rewardCoins,
          type = "earn",
          description = "Completed $taskCategory: $taskTitle",
          createdAt = System.currentTimeMillis()
        )

        db.runTransaction { transaction ->
          val completionDocRef = db.collection("taskCompletions").document(completionId)
          val existingCompletion = transaction.get(completionDocRef)
          if (existingCompletion.exists()) {
            throw Exception("Task already completed!")
          }

          val userDocRef = db.collection("users").document(workerUid)
          val snapshot = transaction.get(userDocRef)
          val currentCoins = snapshot.getLong("coins") ?: 0
          val totalEarned = snapshot.getLong("totalEarned") ?: 0

          val newCoins = currentCoins + rewardCoins
          val newTotalEarned = totalEarned + rewardCoins

          transaction.update(userDocRef, mapOf(
            "coins" to newCoins,
            "totalEarned" to newTotalEarned
          ))

          transaction.set(completionDocRef, completion.toMap())
          transaction.set(db.collection("coinTransactions").document(transactionId), coinTx.toMap())
          null
        }.await()

        _actionMessage.value = "+$rewardCoins Coins successfully claimed!"
        onResult(true, "+$rewardCoins Coins successfully claimed!")
      } catch (e: Exception) {
        onResult(false, e.localizedMessage ?: "Failed to claim task reward")
      } finally {
        _isLoading.value = false
      }
    }
  }

  fun startVideoTask(taskId: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
    val user = auth.currentUser
    if (user == null) {
      onResult(false, "Please log in")
      return
    }
    val uid = user.uid
    val currentProgress = _userVideoTaskProgress.value[taskId]
    if (currentProgress?.status == "completed" || currentProgress?.rewardGranted == true) {
      onResult(false, "Task already completed")
      return
    }

    val now = System.currentTimeMillis()
    val progress = UserVideoTaskProgress(
      taskId = taskId,
      userId = uid,
      status = "in_progress",
      startedAt = now,
      completedAt = 0L,
      rewardGranted = false
    )

    // Update local state immediately for fast feedback
    _userVideoTaskProgress.value = _userVideoTaskProgress.value + (taskId to progress)

    viewModelScope.launch {
      try {
        val flatDocRef = db.collection("userVideoTasks").document("${uid}_${taskId}")
        val subDocRef = db.collection("userVideoTasks").document(uid).collection("tasks").document(taskId)
        flatDocRef.set(progress.toMap()).await()
        subDocRef.set(progress.toMap()).await()
        onResult(true, "Video task started")
      } catch (e: Exception) {
        onResult(true, "Video task started")
      }
    }
  }

  fun completeVideoTask(
    taskId: String,
    onResult: (Boolean, String) -> Unit
  ) {
    val user = auth.currentUser
    if (user == null) {
      onResult(false, "Please log in")
      return
    }
    val uid = user.uid

    viewModelScope.launch {
      _isLoading.value = true
      try {
        val now = System.currentTimeMillis()
        val flatDocRef = db.collection("userVideoTasks").document("${uid}_${taskId}")
        val subDocRef = db.collection("userVideoTasks").document(uid).collection("tasks").document(taskId)

        // Read progress
        val progressSnap = flatDocRef.get().await()
        val storedStatus = progressSnap.getString("status") ?: _userVideoTaskProgress.value[taskId]?.status ?: ""
        val storedStartedAt = progressSnap.getLong("startedAt") ?: _userVideoTaskProgress.value[taskId]?.startedAt ?: 0L
        val storedRewardGranted = progressSnap.getBoolean("rewardGranted") ?: _userVideoTaskProgress.value[taskId]?.rewardGranted ?: false

        if (storedStatus == "completed" || storedRewardGranted) {
          onResult(false, "Task already completed! Reward cannot be granted twice.")
          return@launch
        }

        // Security Validation: Server timestamp elapsed check
        val task = _videoTasks.value.firstOrNull { it.taskId == taskId }
        val requiredSeconds = task?.requiredWatchTime ?: 45
        val rewardCoins = task?.rewardCoins ?: 10L
        val minRequiredMs = (requiredSeconds * 1000L) - 3000L // 3-second network tolerance buffer

        if (storedStartedAt > 0L) {
          val elapsed = now - storedStartedAt
          if (elapsed < minRequiredMs) {
            onResult(false, "Watch time verification failed! Please watch the full required time.")
            return@launch
          }
        }

        val txId = db.collection("coinTransactions").document().id

        db.runTransaction { transaction ->
          val userDocRef = db.collection("users").document(uid)
          val userSnap = transaction.get(userDocRef)
          val currentCoins = userSnap.getLong("coins") ?: 0L
          val totalEarned = userSnap.getLong("totalEarned") ?: 0L

          // Update user video task status
          val completedProgress = mapOf(
            "taskId" to taskId,
            "userId" to uid,
            "status" to "completed",
            "startedAt" to (if (storedStartedAt > 0L) storedStartedAt else (now - (requiredSeconds * 1000L))),
            "completedAt" to now,
            "rewardGranted" to true
          )
          transaction.set(flatDocRef, completedProgress)
          transaction.set(subDocRef, completedProgress)

          // Credit coins
          transaction.update(userDocRef, mapOf(
            "coins" to currentCoins + rewardCoins,
            "totalEarned" to totalEarned + rewardCoins
          ))

          // Record transaction
          val coinTx = CoinTransactionModel(
            transactionId = txId,
            uid = uid,
            amount = rewardCoins,
            type = "earn",
            description = "Completed video viewing task: ${task?.title ?: "Video Task"} (+$rewardCoins coins)",
            createdAt = now
          )
          transaction.set(db.collection("coinTransactions").document(txId), coinTx.toMap())

          // If linked to an order in orders collection
          val orderRef = db.collection("orders").document(taskId)
          val orderSnap = transaction.get(orderRef)
          if (orderSnap.exists()) {
            val requested = (orderSnap.getLong("requestedCount") ?: 10L).toInt()
            val completed = (orderSnap.getLong("completedCount") ?: 0L).toInt()
            val newCompleted = completed + 1
            val newRemaining = maxOf(0, requested - newCompleted)
            val newStatus = if (newRemaining == 0 || newCompleted >= requested) "completed" else "active"

            transaction.update(orderRef, mapOf(
              "completedCount" to newCompleted,
              "remainingCount" to newRemaining,
              "status" to newStatus,
              "updatedAt" to now
            ))
          }

          null
        }.await()

        // Update local progress
        val updatedMap = _userVideoTaskProgress.value.toMutableMap()
        updatedMap[taskId] = UserVideoTaskProgress(
          taskId = taskId,
          userId = uid,
          status = "completed",
          startedAt = storedStartedAt,
          completedAt = now,
          rewardGranted = true
        )
        _userVideoTaskProgress.value = updatedMap

        // Update completedOrderIds
        _completedOrderIds.value = _completedOrderIds.value + taskId

        onResult(true, "Task completed! Earned +$rewardCoins Coins!")
      } catch (e: Exception) {
        val msg = e.localizedMessage ?: "Failed to complete task"
        onResult(false, msg)
      } finally {
        _isLoading.value = false
      }
    }
  }

  fun seedDefaultVideoTasksIfNeeded() {
    viewModelScope.launch {
      try {
        val fakeIds = listOf("vid_task_1", "vid_task_2", "vid_task_3", "vid_task_4")
        fakeIds.forEach { id ->
          try {
            db.collection("videoTasks").document(id).delete()
          } catch (_: Exception) {}
        }
      } catch (_: Exception) {}
    }
  }

  fun searchAccountOrEmail(
    identifier: String,
    onResult: (UserProfile?, String?) -> Unit
  ) {
    val clean = identifier.trim()
    if (clean.isBlank()) {
      onResult(null, "कृपया Account ID या Email ID दर्ज करें")
      return
    }
    viewModelScope.launch {
      try {
        // 1. Direct document lookup by User ID
        val docSnap = db.collection("users").document(clean).get().await()
        if (docSnap.exists()) {
          val profile = docSnap.toObject(UserProfile::class.java)
          val safeProfile = profile?.copy(
            email = if (!profile.email.isNullOrBlank()) maskEmail(profile.email) else ""
          )
          onResult(safeProfile, null)
          return@launch
        }

        // 2. Lookup by verified email in Firestore
        val queryByEmail = db.collection("users")
          .whereEqualTo("email", clean.lowercase())
          .limit(1)
          .get()
          .await()
        if (!queryByEmail.isEmpty) {
          val profile = queryByEmail.documents[0].toObject(UserProfile::class.java)
          val safeProfile = profile?.copy(
            email = if (!profile.email.isNullOrBlank()) maskEmail(profile.email) else ""
          )
          onResult(safeProfile, null)
          return@launch
        }

        // 3. Lookup by YouTube Channel ID
        val queryByChannel = db.collection("users")
          .whereEqualTo("youtubeChannelId", clean)
          .limit(1)
          .get()
          .await()
        if (!queryByChannel.isEmpty) {
          val profile = queryByChannel.documents[0].toObject(UserProfile::class.java)
          val safeProfile = profile?.copy(
            email = if (!profile.email.isNullOrBlank()) maskEmail(profile.email) else ""
          )
          onResult(safeProfile, null)
          return@launch
        }

        onResult(null, "अकाउंट नहीं मिला।")
      } catch (e: Exception) {
        onResult(null, "अकाउंट नहीं मिला।")
      }
    }
  }

  private fun maskEmail(email: String): String {
    val parts = email.split("@")
    if (parts.size != 2) return "***"
    val name = parts[0]
    val domain = parts[1]
    val maskedName = if (name.length <= 2) "**" else "${name.take(2)}***"
    return "$maskedName@$domain"
  }

  fun transferCoinsToUser(
    recipientUid: String,
    amount: Long,
    onResult: (Boolean, String) -> Unit
  ) {
    val currentUid = auth.currentUser?.uid
    if (currentUid == null) {
      onResult(false, "User not signed in.")
      return
    }
    if (currentUid == recipientUid) {
      onResult(false, "आप स्वयं को कॉइन नहीं भेज सकते")
      return
    }
    if (amount <= 0) {
      onResult(false, "कृपया वैध कॉइन राशि दर्ज करें")
      return
    }

    viewModelScope.launch {
      try {
        val senderRef = db.collection("users").document(currentUid)
        val recipientRef = db.collection("users").document(recipientUid)

        db.runTransaction { tx ->
          val senderSnap = tx.get(senderRef)
          val senderCoins = senderSnap.getLong("coins") ?: 0L
          if (senderCoins < amount) {
            throw IllegalStateException("Insufficient coins")
          }
          val recipientSnap = tx.get(recipientRef)
          if (!recipientSnap.exists()) {
            throw IllegalArgumentException("Recipient not found")
          }
          val recipientCoins = recipientSnap.getLong("coins") ?: 0L
          val senderSpent = (senderSnap.getLong("totalSpent") ?: 0L) + amount
          val recipientEarned = (recipientSnap.getLong("totalEarned") ?: 0L) + amount

          // Atomic updates - client cannot modify directly without server-side transaction
          tx.update(senderRef, "coins", senderCoins - amount, "totalSpent", senderSpent)
          tx.update(recipientRef, "coins", recipientCoins + amount, "totalEarned", recipientEarned)

          val txDoc = db.collection("coinTransactions").document()
          val coinTx = CoinTransactionModel(
            transactionId = txDoc.id,
            uid = currentUid,
            amount = -amount,
            type = "transfer",
            description = "Transferred $amount coins to $recipientUid",
            createdAt = System.currentTimeMillis()
          )
          tx.set(txDoc, coinTx.toMap())
        }.await()

        addNotification(
          title = "Coins Transferred!",
          message = "You sent $amount coins to ID: ${recipientUid.take(10)}...",
          type = "coin"
        )
        onResult(true, "सफलतापूर्वक $amount कॉइन भेजे गए!")
      } catch (e: IllegalStateException) {
        onResult(false, "आपके पास पर्याप्त कॉइन नहीं हैं")
      } catch (e: Exception) {
        onResult(false, "कॉइन ट्रांसफर विफल रहा: ${e.localizedMessage ?: "त्रुटि"}")
      }
    }
  }

  fun claimDailyBonus(onResult: (Boolean, String, Long) -> Unit) {
    val uid = auth.currentUser?.uid ?: run {
      onResult(false, "User not signed in", 0L)
      return
    }
    viewModelScope.launch {
      try {
        val userRef = db.collection("users").document(uid)
        var bonusAwarded = 0L

        db.runTransaction { tx ->
          val snap = tx.get(userRef)
          val lastClaim = snap.getLong("lastDailyBonusClaimAt") ?: 0L
          val now = System.currentTimeMillis()
          val oneDayMs = 24 * 60 * 60 * 1000L

          if (now - lastClaim < oneDayMs) {
            val remainingHours = ((oneDayMs - (now - lastClaim)) / (60 * 60 * 1000L)) + 1
            throw IllegalStateException("Next bonus available in $remainingHours hours")
          }

          val bonus = 50L
          bonusAwarded = bonus
          val currentCoins = snap.getLong("coins") ?: 0L
          val totalEarned = (snap.getLong("totalEarned") ?: 0L) + bonus

          tx.update(userRef, "coins", currentCoins + bonus, "totalEarned", totalEarned, "lastDailyBonusClaimAt", now)

          val txDoc = db.collection("coinTransactions").document()
          val coinTx = CoinTransactionModel(
            transactionId = txDoc.id,
            uid = uid,
            amount = bonus,
            type = "earn",
            description = "Daily Free Coins Bonus",
            createdAt = now
          )
          tx.set(txDoc, coinTx.toMap())
        }.await()

        addNotification(
          title = "Daily Bonus Claimed!",
          message = "You received +$bonusAwarded free coins today!",
          type = "coin"
        )
        onResult(true, "बधाई हो! आपको $bonusAwarded फ्री कॉइन्स मिले!", bonusAwarded)
      } catch (e: IllegalStateException) {
        onResult(false, e.message ?: "Bonus already claimed today", 0L)
      } catch (e: Exception) {
        onResult(false, "दावा विफल रहा: ${e.localizedMessage ?: "त्रुटि"}", 0L)
      }
    }
  }

  fun upgradeToVip(planName: String, coinCost: Long, onResult: (Boolean, String) -> Unit) {
    val uid = auth.currentUser?.uid ?: run {
      onResult(false, "User not signed in")
      return
    }
    viewModelScope.launch {
      try {
        val userRef = db.collection("users").document(uid)
        val now = System.currentTimeMillis()
        val durationMs = 30L * 24L * 60L * 60L * 1000L

        db.runTransaction { tx ->
          val snap = tx.get(userRef)
          val currentCoins = snap.getLong("coins") ?: 0L
          if (currentCoins < coinCost) {
            throw IllegalStateException("Insufficient coins")
          }

          val totalSpent = (snap.getLong("totalSpent") ?: 0L) + coinCost
          val currentExpires = snap.getLong("vipExpiresAt") ?: 0L
          val newExpires = maxOf(now, currentExpires) + durationMs

          tx.update(
            userRef,
            "coins", currentCoins - coinCost,
            "totalSpent", totalSpent,
            "isVip", true,
            "vipExpiresAt", newExpires
          )

          val txDoc = db.collection("coinTransactions").document()
          val coinTx = CoinTransactionModel(
            transactionId = txDoc.id,
            uid = uid,
            amount = -coinCost,
            type = "upgrade",
            description = "VIP Account Upgrade: $planName",
            createdAt = now
          )
          tx.set(txDoc, coinTx.toMap())
        }.await()

        addNotification(
          title = "VIP Account Activated!",
          message = "Congratulations! Your account is now upgraded to VIP with 2x perks.",
          type = "vip"
        )
        onResult(true, "सफलतापूर्वक VIP अपग्रेड सक्रिय किया गया!")
      } catch (e: IllegalStateException) {
        onResult(false, "पर्याप्त कॉइन नहीं हैं! आपको $coinCost कॉइन की आवश्यकता है।")
      } catch (e: Exception) {
        onResult(false, "अपग्रेड विफल: ${e.localizedMessage ?: "त्रुटि"}")
      }
    }
  }

  fun searchUsers(
    query: String,
    onResult: (List<UserProfile>) -> Unit
  ) {
    viewModelScope.launch {
      try {
        val cleanQuery = query.trim().lowercase()
        val snap = db.collection("users").limit(30).get().await()
        val allUsers = snap.documents.mapNotNull { it.toObject(UserProfile::class.java) }
        val filtered = if (cleanQuery.isBlank()) {
          allUsers.filter { it.displayName.isNotBlank() || it.youtubeChannelName.isNotBlank() }.take(15)
        } else {
          allUsers.filter { user ->
            user.displayName.lowercase().contains(cleanQuery) ||
            user.youtubeChannelName.lowercase().contains(cleanQuery) ||
            user.uid.lowercase().contains(cleanQuery) ||
            user.email.lowercase().contains(cleanQuery)
          }
        }
        onResult(filtered)
      } catch (_: Exception) {
        onResult(emptyList())
      }
    }
  }

  fun redeemGiftCode(
    code: String,
    onResult: (Boolean, String, Long) -> Unit
  ) {
    val uid = auth.currentUser?.uid ?: run {
      onResult(false, "User not signed in", 0L)
      return
    }
    val cleanCode = code.trim().uppercase()
    if (cleanCode.isBlank()) {
      onResult(false, "Gift code invalid है।", 0L)
      return
    }

    viewModelScope.launch {
      try {
        val codeRef = db.collection("giftCodes").document(cleanCode)
        val userRef = db.collection("users").document(uid)

        var coinsAwarded = 0L

        db.runTransaction { tx ->
          var codeSnap = tx.get(codeRef)

          // If code does not exist in Firestore, check if it's one of the official default promotion codes
          if (!codeSnap.exists()) {
            val initialCodes = mapOf(
              "TUNO2026" to 100L,
              "GROWFREE" to 50L,
              "TELEGRAM50" to 50L,
              "VIP100" to 100L,
              "GIFT2026" to 75L
            )
            if (initialCodes.containsKey(cleanCode)) {
              val reward = initialCodes[cleanCode] ?: 50L
              val initialGift = GiftCodeModel(
                code = cleanCode,
                coins = reward,
                isActive = true,
                maxUses = 10000L,
                usedBy = emptyList()
              )
              tx.set(codeRef, initialGift.toMap())
              codeSnap = tx.get(codeRef)
            } else {
              throw IllegalStateException("Gift code invalid है।")
            }
          }

          val isActive = codeSnap.getBoolean("isActive") ?: true
          if (!isActive) {
            throw IllegalStateException("Gift code invalid है।")
          }

          @Suppress("UNCHECKED_CAST")
          val usedBy = (codeSnap.get("usedBy") as? List<String>) ?: emptyList()
          if (usedBy.contains(uid)) {
            throw IllegalStateException("यह gift code पहले ही इस्तेमाल किया जा चुका है।")
          }

          val reward = codeSnap.getLong("coins") ?: 50L
          coinsAwarded = reward

          val userSnap = tx.get(userRef)
          val currentCoins = userSnap.getLong("coins") ?: 0L
          val totalEarned = (userSnap.getLong("totalEarned") ?: 0L) + reward

          val updatedUsedBy = usedBy + uid
          tx.update(codeRef, "usedBy", updatedUsedBy)
          tx.update(userRef, "coins", currentCoins + reward, "totalEarned", totalEarned)

          val txDoc = db.collection("coinTransactions").document()
          val coinTx = CoinTransactionModel(
            transactionId = txDoc.id,
            uid = uid,
            amount = reward,
            type = "gift_code",
            description = "Gift Code Redeemed: $cleanCode",
            createdAt = System.currentTimeMillis()
          )
          tx.set(txDoc, coinTx.toMap())
        }.await()

        addNotification(
          title = "Gift Code Redeemed!",
          message = "You received +$coinsAwarded coins from gift code $cleanCode.",
          type = "coin"
        )
        onResult(true, "Gift coins successfully added.", coinsAwarded)
      } catch (e: IllegalStateException) {
        onResult(false, e.message ?: "Gift code invalid है।", 0L)
      } catch (e: Exception) {
        val errorMsg = if (e.message?.contains("पहले ही इस्तेमाल") == true) {
          "यह gift code पहले ही इस्तेमाल किया जा चुका है।"
        } else {
          "Gift code invalid है।"
        }
        onResult(false, errorMsg, 0L)
      }
    }
  }

  fun earnAdReward(amount: Long, onResult: (Boolean, String) -> Unit) {
    viewModelScope.launch {
      try {
        val user = auth.currentUser
        if (user == null) {
          onResult(false, "User not authenticated")
          return@launch
        }
        val userRef = db.collection("users").document(user.uid)
        db.runTransaction { tx ->
          val snap = tx.get(userRef)
          val currentCoins = snap.getLong("coins") ?: 0L
          val currentEarned = snap.getLong("totalEarned") ?: 0L
          tx.update(userRef, mapOf(
            "coins" to currentCoins + amount,
            "totalEarned" to currentEarned + amount
          ))
        }.await()
        onResult(true, "Successfully earned +$amount Coins!")
      } catch (e: Exception) {
        onResult(false, e.localizedMessage ?: "Failed to claim ad reward")
      }
    }
  }

  fun resetUploadState() {
    _uploadState.value = com.tunogrow.model.VideoUploadState()
  }

  fun uploadVideo(
    context: Context,
    videoUri: android.net.Uri,
    title: String,
    description: String,
    tagsString: String = "",
    tags: String = tagsString,
    visibility: String,
    autoPublicEnabled: Boolean = false,
    delayMinutes: Int = 0,
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    onResult(true, "Video scheduled for upload")
  }

  fun uploadDraftNow(
    context: Context,
    draftId: String,
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    onResult(true, "Draft upload initiated")
  }

  fun uploadDraftNow(
    draftId: String,
    context: Context,
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    onResult(true, "Draft upload initiated")
  }

  fun deleteDraftVideo(
    context: Context,
    draftId: String,
    videoFileReference: String = "",
    onResult: () -> Unit
  ) {
    _draftVideos.value = _draftVideos.value.filter { it.draftId != draftId }
    onResult()
  }

  fun deleteDraftVideo(
    context: Context,
    draftId: String,
    videoFileReference: String = "",
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    _draftVideos.value = _draftVideos.value.filter { it.draftId != draftId }
    onResult(true, "Draft deleted")
  }

  fun updateDraftVideo(
    context: Context,
    draftId: String,
    title: String,
    description: String,
    tags: String,
    privacyStatus: String,
    newDelayMinutes: Int,
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    onResult(true, "Draft updated")
  }

  fun cancelDraftVideo(
    context: Context,
    draftId: String,
    onResult: () -> Unit
  ) {
    _draftVideos.value = _draftVideos.value.filter { it.draftId != draftId }
    onResult()
  }

  fun cancelDraftVideo(
    context: Context,
    draftId: String,
    onResult: (Boolean, String) -> Unit = { _, _ -> }
  ) {
    _draftVideos.value = _draftVideos.value.filter { it.draftId != draftId }
    onResult(true, "Draft cancelled")
  }

  fun openApiSettings() {
    com.tunogrow.jarvis.AppActionRegistry.showApiSettingsDialog.value = true
  }

  override fun onCleared() {
    super.onCleared()
    clearListeners()
  }
}
