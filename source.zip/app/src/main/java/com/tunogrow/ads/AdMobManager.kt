package com.tunogrow.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.tunogrow.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class AdStatus {
  object Idle : AdStatus()
  object Loading : AdStatus()
  object Ready : AdStatus()
  object Showing : AdStatus()
  data class Error(val message: String, val code: Int? = null) : AdStatus()
}

/**
 * AdMobManager manages Google Mobile Ads Rewarded Ads lifecycle,
 * User Messaging Platform (UMP) consent, test vs production unit IDs,
 * safe error handling, and strict adherence to AdMob rewarded policies.
 */
object AdMobManager {
  private const val TAG = "AdMobManager"

  // User AdMob credentials
  const val ADMOB_APP_ID = "ca-app-pub-4979667457711305~4707491569"
  const val PRODUCTION_REWARDED_AD_UNIT_ID = "ca-app-pub-4979667457711305/9955948819"

  // Google Official Rewarded Ad Test Unit ID for Android
  const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

  // Reward coins amount per watched ad
  const val DEFAULT_REWARD_COINS = 25L

  // Controls whether Google official test ads or production (original) ads are requested.
  // Defaults to false so original production AdMob ads are used.
  private val _isTestMode = MutableStateFlow(false)
  val isTestMode: StateFlow<Boolean> = _isTestMode.asStateFlow()

  private val _adStatus = MutableStateFlow<AdStatus>(AdStatus.Idle)
  val adStatus: StateFlow<AdStatus> = _adStatus.asStateFlow()

  private val _adsWatchedCount = MutableStateFlow(0)
  val adsWatchedCount: StateFlow<Int> = _adsWatchedCount.asStateFlow()

  private var rewardedAd: RewardedAd? = null
  private var isInitializing = false
  private var isInitialized = false
  private val retryHandler by lazy { Handler(Looper.getMainLooper()) }
  private var retryRunnable: Runnable? = null
  private var retryAttempts = 0

  val currentAdUnitId: String
    get() = if (_isTestMode.value) TEST_REWARDED_AD_UNIT_ID else PRODUCTION_REWARDED_AD_UNIT_ID

  fun setTestMode(enabled: Boolean, context: Context? = null) {
    if (_isTestMode.value != enabled) {
      _isTestMode.value = enabled
      rewardedAd = null
      _adStatus.value = AdStatus.Idle
      context?.let { loadRewardedAd(it, force = true) }
    }
  }

  /**
   * Initialize User Messaging Platform (UMP) consent flow and Google Mobile Ads SDK.
   */
  fun initialize(activity: Activity) {
    if (isInitialized || isInitializing) return
    isInitializing = true

    try {
      val params = ConsentRequestParameters.Builder()
        .setTagForUnderAgeOfConsent(false)
        .build()

      val consentInformation = UserMessagingPlatform.getConsentInformation(activity)
      consentInformation.requestConsentInfoUpdate(
        activity,
        params,
        {
          UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
            if (formError != null) {
              Log.w(TAG, "UMP consent form error: ${formError.errorCode} - ${formError.message}")
            }
            if (consentInformation.canRequestAds()) {
              initMobileAdsSdk(activity)
            } else {
              initMobileAdsSdk(activity)
            }
          }
        },
        { requestConsentError ->
          Log.w(TAG, "UMP consent request failed: ${requestConsentError.errorCode} - ${requestConsentError.message}")
          initMobileAdsSdk(activity)
        }
      )
    } catch (e: Exception) {
      Log.e(TAG, "Error during UMP initialization: ${e.message}", e)
      initMobileAdsSdk(activity)
    }
  }

  private fun initMobileAdsSdk(context: Context) {
    MobileAds.initialize(context) { initStatus ->
      Log.i(TAG, "Google Mobile Ads initialized successfully: $initStatus")
      isInitialized = true
      isInitializing = false
      loadRewardedAd(context)
    }
  }

  /**
   * Preload a Rewarded Ad safely.
   */
  fun loadRewardedAd(
    context: Context,
    force: Boolean = false,
    onLoaded: (() -> Unit)? = null,
    onError: ((String) -> Unit)? = null
  ) {
    if (!force && rewardedAd != null) {
      _adStatus.value = AdStatus.Ready
      onLoaded?.invoke()
      return
    }

    if (!force && _adStatus.value is AdStatus.Loading) {
      Log.d(TAG, "Ad is already loading. Skipping duplicate request.")
      return
    }

    _adStatus.value = AdStatus.Loading
    val adUnit = currentAdUnitId
    Log.d(TAG, "Loading rewarded ad with unit ID: $adUnit (testMode: ${_isTestMode.value})")

    val adRequest = AdRequest.Builder().build()
    RewardedAd.load(
      context.applicationContext,
      adUnit,
      adRequest,
      object : RewardedAdLoadCallback() {
        override fun onAdLoaded(ad: RewardedAd) {
          Log.d(TAG, "Rewarded ad loaded successfully.")
          rewardedAd = ad
          _adStatus.value = AdStatus.Ready
          retryAttempts = 0
          retryRunnable?.let { retryHandler.removeCallbacks(it) }
          onLoaded?.invoke()
        }

        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
          val errorMsg = loadAdError.message
          val errorCode = loadAdError.code
          Log.e(TAG, "Failed to load rewarded ad: $errorMsg (code: $errorCode)")
          rewardedAd = null
          _adStatus.value = AdStatus.Error(errorMsg, errorCode)
          onError?.invoke(errorMsg)

          // Schedule automatic backoff retry (up to 30 seconds max)
          retryAttempts++
          val delayMillis = (retryAttempts.coerceAtMost(3) * 10000L).coerceIn(10000L, 30000L)
          retryRunnable?.let { retryHandler.removeCallbacks(it) }
          retryRunnable = Runnable {
            Log.d(TAG, "Executing auto retry for rewarded ad load (attempt $retryAttempts)")
            loadRewardedAd(context)
          }
          retryHandler.postDelayed(retryRunnable!!, delayMillis)
        }
      }
    )
  }

  /**
   * Display the Rewarded Ad to the user.
   * Rewards are strictly granted ONLY within the SDK's onUserEarnedReward callback.
   */
  fun showRewardedAd(
    activity: Activity,
    onRewardEarned: (coins: Long, rewardType: String) -> Unit,
    onAdDismissed: () -> Unit = {},
    onError: (String) -> Unit = {}
  ) {
    val ad = rewardedAd
    if (ad == null) {
      val msg = "Ad is not ready yet. Loading now, please try again in a few seconds."
      onError(msg)
      loadRewardedAd(activity)
      return
    }

    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
      override fun onAdShowedFullScreenContent() {
        Log.d(TAG, "Rewarded ad showed full screen content.")
        _adStatus.value = AdStatus.Showing
      }

      override fun onAdDismissedFullScreenContent() {
        Log.d(TAG, "Rewarded ad dismissed.")
        rewardedAd = null
        _adStatus.value = AdStatus.Idle
        onAdDismissed()
        loadRewardedAd(activity)
      }

      override fun onAdFailedToShowFullScreenContent(adError: AdError) {
        Log.e(TAG, "Failed to show rewarded ad: ${adError.message} (code: ${adError.code})")
        rewardedAd = null
        _adStatus.value = AdStatus.Error(adError.message, adError.code)
        onError(adError.message)
        loadRewardedAd(activity)
      }

      override fun onAdClicked() {
        Log.d(TAG, "Ad clicked. As per AdMob Policy, clicks are never rewarded.")
      }

      override fun onAdImpression() {
        Log.d(TAG, "Rewarded ad impression logged.")
      }
    }

    ad.show(activity) { rewardItem ->
      val coinsEarned = if (rewardItem.amount > 0) rewardItem.amount.toLong() else DEFAULT_REWARD_COINS
      val type = if (rewardItem.type.isNotBlank()) rewardItem.type else "Coins"
      Log.i(TAG, "SDK confirmed user earned reward: $coinsEarned $type")
      _adsWatchedCount.value += 1
      onRewardEarned(coinsEarned, type)
    }
  }

  /**
   * Plays Google AdMob ad when "Verify Subscription" is clicked.
   * If the ad is already preloaded, shows it immediately; otherwise loads and shows it,
   * then invokes [onAdFinished] so subscription verification proceeds.
   */
  fun showAdForVerification(
    activity: Activity,
    onAdFinished: () -> Unit
  ) {
    var finishedCalled = false
    val safeFinish = {
      if (!finishedCalled) {
        finishedCalled = true
        onAdFinished()
      }
    }

    if (rewardedAd != null) {
      showRewardedAd(
        activity = activity,
        onRewardEarned = { _, _ -> },
        onAdDismissed = { safeFinish() },
        onError = { safeFinish() }
      )
    } else {
      loadRewardedAd(
        context = activity,
        force = true,
        onLoaded = {
          if (rewardedAd != null) {
            showRewardedAd(
              activity = activity,
              onRewardEarned = { _, _ -> },
              onAdDismissed = { safeFinish() },
              onError = { safeFinish() }
            )
          } else {
            safeFinish()
          }
        },
        onError = {
          safeFinish()
        }
      )
    }
  }

  fun isAdReady(): Boolean {
    return rewardedAd != null && _adStatus.value is AdStatus.Ready
  }
}
