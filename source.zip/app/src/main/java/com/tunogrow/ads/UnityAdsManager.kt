package com.tunogrow.ads

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsLoadOptions
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.metadata.MetaData
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * UnityAdsManager - Singleton responsible for initializing and serving Unity Ads
 *
 * Game ID: 800405803
 * Placements:
 * - Interstitial: BP_Interstitial_Android (Fallback: Interstitial_Android)
 * - Rewarded: BP_Rewarded_Android (Fallback: Rewarded_Android)
 * - Banner: BP_Banner_Android (Fallback: Banner_Android)
 */
object UnityAdsManager {
  private const val TAG = "UnityAdsManager"

  const val GAME_ID = "800405803"

  // Placement IDs
  const val PLACEMENT_INTERSTITIAL_PRIMARY = "BP_Interstitial_Android"
  const val PLACEMENT_INTERSTITIAL_FALLBACK = "Interstitial_Android"

  const val PLACEMENT_REWARDED_PRIMARY = "BP_Rewarded_Android"
  const val PLACEMENT_REWARDED_FALLBACK = "Rewarded_Android"

  const val PLACEMENT_BANNER_PRIMARY = "BP_Banner_Android"
  const val PLACEMENT_BANNER_FALLBACK = "Banner_Android"
  const val PLACEMENT_BANNER_BP = "BP_Banner_Android" // Alias for components

  // SharedPreferences keys
  private const val PREFS_NAME = "unity_ads_prefs"
  private const val KEY_TEST_MODE = "pref_unity_ads_test_mode"
  private const val KEY_GDPR_CONSENT = "pref_unity_ads_gdpr_consent"
  private const val KEY_CCPA_CONSENT = "pref_unity_ads_ccpa_consent"

  // Reactive StateFlows for UI diagnostics and observation
  private val _isInitialized = MutableStateFlow(false)
  val isInitialized = _isInitialized.asStateFlow()

  private val _testMode = MutableStateFlow(false)
  val testMode = _testMode.asStateFlow()

  private val _interstitialReady = MutableStateFlow(false)
  val interstitialReady = _interstitialReady.asStateFlow()

  private val _rewardedReady = MutableStateFlow(false)
  val rewardedReady = _rewardedReady.asStateFlow()

  private val _diagnosticLogs = MutableStateFlow<List<String>>(emptyList())
  val diagnosticLogs = _diagnosticLogs.asStateFlow()

  private val mainHandler = Handler(Looper.getMainLooper())
  private val isInitializing = AtomicBoolean(false)
  private var appContext: Context? = null

  // Interstitial State
  private var loadedInterstitialPlacement: String? = null
  private var isInterstitialLoading = false
  private var interstitialRetryCount = 0
  private const val MAX_RETRIES = 5

  // Rewarded State
  private var loadedRewardedPlacement: String? = null
  private var isRewardedLoading = false
  private var rewardedRetryCount = 0

  fun addLog(msg: String) {
    Log.d(TAG, msg)
    val current = _diagnosticLogs.value.toMutableList()
    current.add(0, "[${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}] $msg")
    if (current.size > 50) current.removeAt(current.size - 1)
    _diagnosticLogs.value = current
  }

  private fun getPrefs(context: Context): SharedPreferences {
    return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  }

  /** Production configuration: always initialize Unity Ads with testMode=false. */
  fun isTestModeEnabled(context: Context): Boolean = false

  /** Test mode is intentionally locked off for this app configuration. */
  fun setTestMode(enabled: Boolean) {
    appContext?.let { ctx -> setTestModeEnabled(ctx, enabled) }
      ?: run { _testMode.value = false }
  }

  fun setTestModeEnabled(context: Context, enabled: Boolean) {
    // Clear any old saved test-mode preference so previous installs cannot force test ads.
    getPrefs(context).edit().remove(KEY_TEST_MODE).apply()
    _testMode.value = false
    addLog("Production mode enforced: test ads disabled (requested=$enabled)")
  }

  /**
   * GDPR & CCPA Consent Management
   */
  fun isGdprConsented(context: Context): Boolean {
    return getPrefs(context).getBoolean(KEY_GDPR_CONSENT, true)
  }

  fun setGdprConsent(context: Context, consented: Boolean) {
    getPrefs(context).edit().putBoolean(KEY_GDPR_CONSENT, consented).apply()
    applyGdprConsent(context.applicationContext, consented)
  }

  private fun applyGdprConsent(context: Context, consented: Boolean) {
    try {
      val gdprMetaData = MetaData(context)
      gdprMetaData.set("gdpr.consent", consented)
      gdprMetaData.commit()
      addLog("GDPR consent committed: $consented")
    } catch (e: Exception) {
      Log.e(TAG, "Failed to apply GDPR consent: ${e.message}")
    }
  }

  fun isCcpaConsented(context: Context): Boolean {
    return getPrefs(context).getBoolean(KEY_CCPA_CONSENT, true)
  }

  fun setCcpaConsent(context: Context, consented: Boolean) {
    getPrefs(context).edit().putBoolean(KEY_CCPA_CONSENT, consented).apply()
    applyCcpaConsent(context.applicationContext, consented)
  }

  private fun applyCcpaConsent(context: Context, consented: Boolean) {
    try {
      val privacyMetaData = MetaData(context)
      privacyMetaData.set("privacy.consent", consented)
      privacyMetaData.commit()
      addLog("CCPA consent committed: $consented")
    } catch (e: Exception) {
      Log.e(TAG, "Failed to apply CCPA consent: ${e.message}")
    }
  }

  /**
   * Initialize Unity Ads once at app launch
   */
  fun init(context: Context) {
    val ctx = context.applicationContext
    appContext = ctx

    if (UnityAds.isInitialized) {
      _isInitialized.value = true
      return
    }

    if (!isInitializing.compareAndSet(false, true)) {
      return
    }

    // Apply GDPR & CCPA privacy metadata before initializing
    applyGdprConsent(ctx, isGdprConsented(ctx))
    applyCcpaConsent(ctx, isCcpaConsented(ctx))

    // Always use Unity Ads LIVE/PRODUCTION mode; never enable test ads.
    val testModeFlag = false
    _testMode.value = false
    addLog("Initializing Unity Ads LIVE (Game ID: $GAME_ID, testMode = false)")

    UnityAds.initialize(ctx, GAME_ID, false, object : IUnityAdsInitializationListener {
      override fun onInitializationComplete() {
        addLog("Unity Ads Initialization Complete.")
        _isInitialized.value = true
        isInitializing.set(false)

        // Preload placements immediately
        loadInterstitial(ctx)
        loadRewarded(ctx)
      }

      override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError, message: String) {
        addLog("Unity Ads Initialization Failed: $error - $message")
        _isInitialized.value = false
        isInitializing.set(false)

        // Retry initialization after 10 seconds
        mainHandler.postDelayed({
          init(ctx)
        }, 10000L)
      }
    })
  }

  // =========================================================================
  // INTERSTITIAL ADS
  // =========================================================================

  /**
   * Load interstitial ad with fallback and auto-retry on NO_FILL or load error
   */
  fun loadInterstitial(context: Context, useFallback: Boolean = false, onLoaded: (() -> Unit)? = null) {
    val ctx = context.applicationContext
    if (!UnityAds.isInitialized) {
      init(ctx)
      return
    }

    if (isInterstitialLoading && !useFallback) {
      return
    }

    val placementId = if (useFallback) PLACEMENT_INTERSTITIAL_FALLBACK else PLACEMENT_INTERSTITIAL_PRIMARY
    isInterstitialLoading = true
    addLog("Loading Interstitial Ad: $placementId (useFallback = $useFallback)")

    UnityAds.load(placementId, UnityAdsLoadOptions(), object : IUnityAdsLoadListener {
      override fun onUnityAdsAdLoaded(placement: String) {
        addLog("Interstitial ad loaded successfully: $placement")
        loadedInterstitialPlacement = placement
        isInterstitialLoading = false
        interstitialRetryCount = 0
        _interstitialReady.value = true
        onLoaded?.invoke()
      }

      override fun onUnityAdsFailedToLoad(
        placement: String,
        error: UnityAds.UnityAdsLoadError,
        message: String
      ) {
        addLog("Interstitial failed [$placement]: $error - $message")
        isInterstitialLoading = false

        if (!useFallback && placement == PLACEMENT_INTERSTITIAL_PRIMARY) {
          // Immediately try fallback placement
          addLog("Trying Interstitial fallback placement: $PLACEMENT_INTERSTITIAL_FALLBACK")
          loadInterstitial(ctx, useFallback = true, onLoaded = onLoaded)
        } else {
          _interstitialReady.value = false
          if (interstitialRetryCount < MAX_RETRIES) {
            interstitialRetryCount++
            val delayMs = (5000L * interstitialRetryCount).coerceAtMost(30000L)
            addLog("Scheduling interstitial reload in ${delayMs / 1000}s (Retry #$interstitialRetryCount)")
            mainHandler.postDelayed({
              loadInterstitial(ctx, useFallback = false)
            }, delayMs)
          }
        }
      }
    })
  }

  fun isInterstitialLoaded(): Boolean {
    return loadedInterstitialPlacement != null
  }

  /**
   * Show Interstitial Ad.
   *
   * If an ad is ready, displays it immediately.
   * If not yet cached, attempts a fast on-demand load (waiting up to 2.5s).
   * If the ad fails or times out, onComplete is invoked cleanly so user flow is never blocked.
   */
  fun showInterstitial(
    activity: Activity,
    onComplete: () -> Unit
  ) {
    showInterstitial(
      activity = activity,
      onAdShown = onComplete,
      onAdFailed = { _ -> onComplete() }
    )
  }

  /**
   * Overloaded showInterstitial with adShown and adFailed callbacks
   */
  fun showInterstitial(
    activity: Activity,
    onAdShown: () -> Unit,
    onAdFailed: (String) -> Unit
  ) {
    val placement = loadedInterstitialPlacement

    val callbackInvoked = AtomicBoolean(false)
    fun safeInvoke(shown: Boolean, errorMsg: String = "") {
      if (callbackInvoked.compareAndSet(false, true)) {
        mainHandler.post {
          if (shown) {
            onAdShown()
          } else {
            onAdFailed(errorMsg)
          }
        }
      }
    }

    // Case 1: An ad is already loaded and ready to show
    if (UnityAds.isInitialized && placement != null) {
      loadedInterstitialPlacement = null
      _interstitialReady.value = false

      try {
        addLog("Displaying Interstitial ad: $placement")
        UnityAds.show(
          activity,
          placement,
          UnityAdsShowOptions(),
          object : IUnityAdsShowListener {
            override fun onUnityAdsShowStart(placementId: String) {
              addLog("Interstitial ad started: $placementId")
            }

            override fun onUnityAdsShowClick(placementId: String) {
              addLog("Interstitial ad clicked: $placementId")
            }

            override fun onUnityAdsShowComplete(
              placementId: String,
              state: UnityAds.UnityAdsShowCompletionState
            ) {
              addLog("Interstitial ad finished: $placementId (state: $state)")
              loadInterstitial(activity.applicationContext)
              safeInvoke(shown = true)
            }

            override fun onUnityAdsShowFailure(
              placementId: String,
              error: UnityAds.UnityAdsShowError,
              message: String
            ) {
              addLog("Interstitial show failed [$placementId]: $error - $message")
              loadInterstitial(activity.applicationContext)
              safeInvoke(shown = false, errorMsg = "$error: $message")
            }
          }
        )
      } catch (e: Exception) {
        addLog("Exception showing interstitial: ${e.message}")
        loadInterstitial(activity.applicationContext)
        safeInvoke(shown = false, errorMsg = e.message ?: "Unknown error")
      }
      return
    }

    // Case 2: Ad is not ready yet: attempt fast load with 2.5s timeout so user isn't stuck
    addLog("Interstitial not pre-cached. Triggering on-demand load with timeout...")
    if (!UnityAds.isInitialized) {
      init(activity.applicationContext)
    }

    // Set a 2.5 second timeout to avoid blocking the user
    val timeoutRunnable = Runnable {
      if (!callbackInvoked.get()) {
        addLog("On-demand ad load timed out (2.5s). Proceeding with user flow.")
        safeInvoke(shown = false, errorMsg = "Ad load timeout")
      }
    }
    mainHandler.postDelayed(timeoutRunnable, 2500L)

    loadInterstitial(activity.applicationContext, useFallback = false) {
      mainHandler.removeCallbacks(timeoutRunnable)
      val loadedPlc = loadedInterstitialPlacement
      if (loadedPlc != null && !callbackInvoked.get()) {
        loadedInterstitialPlacement = null
        _interstitialReady.value = false
        try {
          addLog("Displaying on-demand Interstitial ad: $loadedPlc")
          UnityAds.show(
            activity,
            loadedPlc,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
              override fun onUnityAdsShowStart(placementId: String) {
                addLog("Interstitial ad started: $placementId")
              }

              override fun onUnityAdsShowClick(placementId: String) {
                addLog("Interstitial ad clicked: $placementId")
              }

              override fun onUnityAdsShowComplete(
                placementId: String,
                state: UnityAds.UnityAdsShowCompletionState
              ) {
                addLog("Interstitial ad finished: $placementId (state: $state)")
                loadInterstitial(activity.applicationContext)
                safeInvoke(shown = true)
              }

              override fun onUnityAdsShowFailure(
                placementId: String,
                error: UnityAds.UnityAdsShowError,
                message: String
              ) {
                addLog("Interstitial show failed: $message")
                loadInterstitial(activity.applicationContext)
                safeInvoke(shown = false, errorMsg = message)
              }
            }
          )
        } catch (e: Exception) {
          addLog("Exception showing interstitial: ${e.message}")
          loadInterstitial(activity.applicationContext)
          safeInvoke(shown = false, errorMsg = e.message ?: "Unknown error")
        }
      }
    }
  }

  // =========================================================================
  // REWARDED ADS
  // =========================================================================

  fun loadRewarded(context: Context, useFallback: Boolean = false) {
    val ctx = context.applicationContext
    if (!UnityAds.isInitialized) {
      init(ctx)
      return
    }

    if (isRewardedLoading && !useFallback) {
      return
    }

    val placementId = if (useFallback) PLACEMENT_REWARDED_FALLBACK else PLACEMENT_REWARDED_PRIMARY
    isRewardedLoading = true
    addLog("Loading Rewarded Ad: $placementId (useFallback = $useFallback)")

    UnityAds.load(placementId, UnityAdsLoadOptions(), object : IUnityAdsLoadListener {
      override fun onUnityAdsAdLoaded(placement: String) {
        addLog("Rewarded ad loaded successfully: $placement")
        loadedRewardedPlacement = placement
        isRewardedLoading = false
        rewardedRetryCount = 0
        _rewardedReady.value = true
      }

      override fun onUnityAdsFailedToLoad(
        placement: String,
        error: UnityAds.UnityAdsLoadError,
        message: String
      ) {
        addLog("Rewarded ad failed [$placement]: $error - $message")
        isRewardedLoading = false

        if (!useFallback && placement == PLACEMENT_REWARDED_PRIMARY) {
          addLog("Trying Rewarded fallback placement: $PLACEMENT_REWARDED_FALLBACK")
          loadRewarded(ctx, useFallback = true)
        } else {
          _rewardedReady.value = false
          if (rewardedRetryCount < MAX_RETRIES) {
            rewardedRetryCount++
            val delayMs = (5000L * rewardedRetryCount).coerceAtMost(30000L)
            mainHandler.postDelayed({
              loadRewarded(ctx, useFallback = false)
            }, delayMs)
          }
        }
      }
    })
  }

  fun isRewardedLoaded(): Boolean {
    return loadedRewardedPlacement != null
  }

  fun showRewarded(
    activity: Activity,
    onRewardEarned: () -> Unit,
    onClosed: () -> Unit = {},
    onAdFailed: (String) -> Unit = {}
  ) {
    val placement = loadedRewardedPlacement
    if (!UnityAds.isInitialized || placement == null) {
      addLog("Rewarded ad not loaded.")
      loadRewarded(activity.applicationContext)
      onAdFailed("Rewarded ad not ready")
      onClosed()
      return
    }

    loadedRewardedPlacement = null
    _rewardedReady.value = false
    var earnedReward = false
    val callbackInvoked = AtomicBoolean(false)

    fun safeInvokeClose() {
      if (callbackInvoked.compareAndSet(false, true)) {
        mainHandler.post {
          if (earnedReward) {
            onRewardEarned()
          }
          onClosed()
        }
      }
    }

    try {
      UnityAds.show(
        activity,
        placement,
        UnityAdsShowOptions(),
        object : IUnityAdsShowListener {
          override fun onUnityAdsShowStart(placementId: String) {
            addLog("Rewarded ad started: $placementId")
          }

          override fun onUnityAdsShowClick(placementId: String) {
            addLog("Rewarded ad clicked: $placementId")
          }

          override fun onUnityAdsShowComplete(
            placementId: String,
            state: UnityAds.UnityAdsShowCompletionState
          ) {
            if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
              earnedReward = true
              addLog("Rewarded ad completed! Reward earned.")
            }
            loadRewarded(activity.applicationContext)
            safeInvokeClose()
          }

          override fun onUnityAdsShowFailure(
            placementId: String,
            error: UnityAds.UnityAdsShowError,
            message: String
          ) {
            addLog("Rewarded ad show failure [$placementId]: $error - $message")
            loadRewarded(activity.applicationContext)
            if (callbackInvoked.compareAndSet(false, true)) {
              mainHandler.post {
                onAdFailed("$error: $message")
                onClosed()
              }
            }
          }
        }
      )
    } catch (e: Exception) {
      addLog("Exception showing rewarded ad: ${e.message}")
      loadRewarded(activity.applicationContext)
      if (callbackInvoked.compareAndSet(false, true)) {
        mainHandler.post {
          onAdFailed(e.message ?: "Unknown error")
          onClosed()
        }
      }
    }
  }

  // =========================================================================
  // BANNER ADS
  // =========================================================================

  fun createBannerView(
    activity: Activity,
    size: UnityBannerSize = UnityBannerSize(320, 50),
    useFallback: Boolean = false,
    listener: BannerView.IListener? = null
  ): BannerView {
    val placementId = if (useFallback) PLACEMENT_BANNER_FALLBACK else PLACEMENT_BANNER_PRIMARY
    val bannerView = BannerView(activity, placementId, size)

    bannerView.listener = object : BannerView.IListener {
      override fun onBannerLoaded(bannerAdView: BannerView?) {
        addLog("Banner loaded: $placementId")
        listener?.onBannerLoaded(bannerAdView)
      }

      override fun onBannerShown(bannerAdView: BannerView?) {
        addLog("Banner shown: $placementId")
        listener?.onBannerShown(bannerAdView)
      }

      override fun onBannerClick(bannerAdView: BannerView?) {
        addLog("Banner clicked: $placementId")
        listener?.onBannerClick(bannerAdView)
      }

      override fun onBannerFailedToLoad(bannerAdView: BannerView?, errorInfo: BannerErrorInfo?) {
        addLog("Banner failed to load [$placementId]: ${errorInfo?.errorMessage}")
        listener?.onBannerFailedToLoad(bannerAdView, errorInfo)
      }

      override fun onBannerLeftApplication(bannerAdView: BannerView?) {
        addLog("Banner left application: $placementId")
        listener?.onBannerLeftApplication(bannerAdView)
      }
    }

    return bannerView
  }
}
