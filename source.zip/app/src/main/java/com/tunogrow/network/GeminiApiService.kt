package com.tunogrow.network

import android.content.Context
import com.tunogrow.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

object GeminiApiService {
    fun initPrefs(context: Context) {
        // Initialized on startup
    }

    suspend fun chatWithCreatorAi(messages: List<ChatMessage>): Result<String> = withContext(Dispatchers.IO) {
        val lastMessage = messages.lastOrNull()?.text ?: ""
        val fallback = getSmartFallbackResponse(lastMessage)
        Result.success(fallback)
    }

    suspend fun askJarvis(query: String): Result<String> = withContext(Dispatchers.IO) {
        val fallback = getSmartFallbackResponse(query)
        Result.success(fallback)
    }

    fun getSmartFallbackResponse(query: String): String {
        val q = query.lowercase(Locale.ROOT)
        if ("title" in q || "viral" in q) {
            return "🔥 **Top 5 High-CTR Viral Title Ideas:**\n1. \"I Tried This YouTube Growth Hack For 30 Days (SHOCKING)\"\n2. \"How I Gained 1,000 Subscribers in 7 Days (Step-by-Step)\"\n3. \"Stop Making This 1 Mistake In Your YouTube Videos!\"\n4. \"The Secret YouTube Algorithm Trick No One Talks About\"\n5. \"0 to 100K Views: What Actually Works In 2026\"\n\n💡 **Pro Tip:** Keep titles under 55 characters and lead with curiosity or a strong emotion!"
        }
        if ("tag" in q || "seo" in q) {
            return "🏷️ **High-Ranking YouTube Tags for Growth:**\n#YouTubeGrowth, #GetSubscribers, #YouTubeShorts, #ViralVideo, #ContentCreator, #CreatorTips, #AlgorithmHacks, #TunoGrow, #VideoSEO, #ChannelGrowth\n\n📋 **SEO Checklist:**\n• Put your primary keyword in the first 3 words of your Title.\n• Use 3-5 relevant hashtags in the description.\n• Write at least 200 words in description explaining the video."
        }
        if ("subscriber" in q || "1000" in q || "follower" in q) {
            return "🎯 **Strategy to Reach 1,000 Subscribers Fast:**\n1. **Post Consistent High-Quality Videos:** Consistency is the fastest engine to discover new audiences.\n2. **Clear Call-to-Action (CTA):** At 75% of your video, say \"Subscribe for more daily growth tricks.\"\n3. **Optimize Thumbnails:** Use high contrast, max 3 text words, and express high emotion.\n4. **Leverage Tuno Grow Campaigns:** Swap views & subscribers with fellow verified creators."
        }
        return "✨ **Tuno Grow Creator Assistant Advice:**\nThe YouTube algorithm in 2026 prioritizes two primary signals:\n1. **Click-Through Rate (CTR):** High-contrast thumbnails and curiosity-inducing titles.\n2. **Average View Duration (AVD):** Fast-paced storytelling without unnecessary filler.\n\nUse Tuno Grow campaigns to jumpstart initial traction!"
    }
}
