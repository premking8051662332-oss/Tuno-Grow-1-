package com.tunogrow.network

import com.tunogrow.model.ReelVideoModel
import com.tunogrow.model.YouTubeApiResult
import com.tunogrow.model.YouTubeChannelInfo
import com.tunogrow.model.YouTubeVideoInfo
import com.tunogrow.model.YouTubeUploadResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object YouTubeApiService {
    const val DEFAULT_YOUTUBE_API_KEY = "AIzaSyBcZPF6DCopmh4AuBAtWg2J3D9Xfik7hks"
    const val TARGET_PROJECT_NUMBER = "584614426055"
    const val OLD_PROJECT_NUMBER = "527632091487"
    const val YOUTUBE_API_BASE_URL = "https://www.googleapis.com/youtube/v3"
    const val YOUTUBE_UPLOAD_BASE_URL = "https://www.googleapis.com/upload/youtube/v3"
    const val REQUIRED_SCOPE = "https://www.googleapis.com/auth/youtube.readonly"
    const val UPLOAD_SCOPE = "https://www.googleapis.com/auth/youtube.upload"
    const val COMBINED_SCOPES = "https://www.googleapis.com/auth/youtube.readonly https://www.googleapis.com/auth/youtube.upload"

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    val configuredApiKey: String get() = DEFAULT_YOUTUBE_API_KEY

    suspend fun checkSubscriptionVerification(
        accessToken: String,
        channelId: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/subscriptions?part=snippet&mine=true&forChannelId=$channelId&key=$configuredApiKey"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $accessToken")
                .header("Accept", "application/json")
                .get()
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("YouTube API error: ${response.code} $body"))
            }

            val json = JSONObject(body)
            val items = json.optJSONArray("items")
            val isSubscribed = items != null && items.length() > 0
            Result.success(isSubscribed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun subscribeChannel(
        accessToken: String,
        channelId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/subscriptions?part=snippet&key=$configuredApiKey"
            val payload = JSONObject().apply {
                put("snippet", JSONObject().apply {
                    put("resourceId", JSONObject().apply {
                        put("kind", "youtube#channel")
                        put("channelId", channelId)
                    })
                })
            }
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $accessToken")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful || response.code == 409) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("HTTP ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun rateVideo(
        accessToken: String,
        videoId: String,
        rating: String = "like"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/videos/rate?id=$videoId&rating=$rating&key=$configuredApiKey"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $accessToken")
                .post("".toRequestBody())
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful || response.code == 204) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("HTTP ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchMyChannel(accessToken: String): YouTubeApiResult = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/channels?part=snippet,statistics&mine=true&key=$configuredApiKey"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $accessToken")
                .get()
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext YouTubeApiResult.Failure("API Error ${response.code}")
            }

            val json = JSONObject(body)
            val items = json.optJSONArray("items")
            if (items == null || items.length() == 0) {
                return@withContext YouTubeApiResult.NoChannelFound
            }

            val item = items.getJSONObject(0)
            val info = parseChannelItem(item)
            if (info != null) {
                YouTubeApiResult.Success(info)
            } else {
                YouTubeApiResult.NoChannelFound
            }
        } catch (e: Exception) {
            YouTubeApiResult.Failure(e.message ?: "Failed to fetch channel")
        }
    }

    suspend fun getChannelDetails(channelId: String): Result<YouTubeChannelInfo> = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/channels?part=snippet,statistics&id=$channelId&key=$configuredApiKey"
            val request = Request.Builder().url(url).get().build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            val json = JSONObject(body)
            val items = json.optJSONArray("items")
            if (items != null && items.length() > 0) {
                val info = parseChannelItem(items.getJSONObject(0))
                if (info != null) return@withContext Result.success(info)
            }
            Result.failure(Exception("Channel not found"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getChannelVideos(channelId: String): Result<List<YouTubeVideoInfo>> = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/search?part=snippet&channelId=$channelId&maxResults=10&order=date&type=video&key=$configuredApiKey"
            val request = Request.Builder().url(url).get().build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            val json = JSONObject(body)
            val items = json.optJSONArray("items")
            val list = mutableListOf<YouTubeVideoInfo>()
            if (items != null) {
                for (i in 0 until items.length()) {
                    val obj = items.getJSONObject(i)
                    val idObj = obj.optJSONObject("id")
                    val videoId = idObj?.optString("videoId") ?: ""
                    val snippet = obj.optJSONObject("snippet")
                    if (videoId.isNotBlank() && snippet != null) {
                        val thumbs = snippet.optJSONObject("thumbnails")
                        val defaultThumb = thumbs?.optJSONObject("medium")?.optString("url")
                            ?: thumbs?.optJSONObject("default")?.optString("url") ?: ""
                        list.add(
                            YouTubeVideoInfo(
                                id = videoId,
                                title = snippet.optString("title"),
                                description = snippet.optString("description"),
                                thumbnailUrl = defaultThumb,
                                channelId = snippet.optString("channelId"),
                                channelTitle = snippet.optString("channelTitle"),
                                publishedAt = snippet.optString("publishedAt")
                            )
                        )
                    }
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resolveChannelByUrl(rawInput: String): Result<YouTubeChannelInfo> = withContext(Dispatchers.IO) {
        val input = rawInput.trim()
        val channelIdMatch = Regex("(?:channel/|c/|@)?([a-zA-Z0-9_-]+)").find(input)
        val extracted = channelIdMatch?.groupValues?.getOrNull(1) ?: input
        if (extracted.startsWith("UC") && extracted.length >= 20) {
            return@withContext getChannelDetails(extracted)
        }
        // Try searching
        searchChannels(extracted).mapCatching { list ->
            list.firstOrNull() ?: throw Exception("No channel found for: $extracted")
        }
    }

    suspend fun searchChannels(query: String): Result<List<YouTubeChannelInfo>> = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/search?part=snippet&q=$query&type=channel&maxResults=5&key=$configuredApiKey"
            val request = Request.Builder().url(url).get().build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            val json = JSONObject(body)
            val items = json.optJSONArray("items")
            val list = mutableListOf<YouTubeChannelInfo>()
            if (items != null) {
                for (i in 0 until items.length()) {
                    val obj = items.getJSONObject(i)
                    val chId = obj.optJSONObject("id")?.optString("channelId") ?: ""
                    val snippet = obj.optJSONObject("snippet")
                    if (chId.isNotBlank() && snippet != null) {
                        val thumbs = snippet.optJSONObject("thumbnails")
                        val thumbUrl = thumbs?.optJSONObject("default")?.optString("url") ?: ""
                        list.add(
                            YouTubeChannelInfo(
                                id = chId,
                                title = snippet.optString("title"),
                                description = snippet.optString("description"),
                                imageUrl = thumbUrl
                            )
                        )
                    }
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchReels(maxResults: Int = 10): Result<List<ReelVideoModel>> = withContext(Dispatchers.IO) {
        try {
            val defaultReels = listOf(
                ReelVideoModel(
                    videoId = "dQw4w9WgXcQ",
                    title = "How to 10X your YouTube growth in 2026",
                    youtubeUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                    thumbnailUrl = "https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg",
                    channelId = "UC12345",
                    channelTitle = "Creator Academy",
                    duration = "0:45",
                    views = "120K",
                    rewardCoins = 10L
                ),
                ReelVideoModel(
                    videoId = "9bZkp7q19f0",
                    title = "Secret algorithm hack for YouTube Shorts",
                    youtubeUrl = "https://www.youtube.com/watch?v=9bZkp7q19f0",
                    thumbnailUrl = "https://img.youtube.com/vi/9bZkp7q19f0/hqdefault.jpg",
                    channelId = "UC67890",
                    channelTitle = "Growth Secrets",
                    duration = "0:30",
                    views = "85K",
                    rewardCoins = 10L
                )
            )
            Result.success(defaultReels)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseChannelItem(item: JSONObject): YouTubeChannelInfo? {
        val id = item.optString("id")
        val snippet = item.optJSONObject("snippet") ?: return null
        val title = snippet.optString("title")
        val description = snippet.optString("description")
        val customUrl = snippet.optString("customUrl")
        val thumbnails = snippet.optJSONObject("thumbnails")
        val imageUrl = thumbnails?.optJSONObject("medium")?.optString("url")
            ?: thumbnails?.optJSONObject("default")?.optString("url") ?: ""
        val stats = item.optJSONObject("statistics")
        val subCount = stats?.optString("subscriberCount") ?: "0"
        val vidCount = stats?.optString("videoCount") ?: "0"
        val viewCount = stats?.optString("viewCount") ?: "0"
        val hiddenSubs = stats?.optBoolean("hiddenSubscriberCount") ?: false

        return YouTubeChannelInfo(
            id = id,
            title = title,
            description = description,
            customUrl = customUrl,
            imageUrl = imageUrl,
            subscriberCount = subCount,
            videoCount = vidCount,
            viewCount = viewCount,
            hiddenSubscriberCount = hiddenSubs
        )
    }

    data class Diagnostics(
        val expectedYouTubeProject: String,
        val apiKeyProject: String,
        val oauthClientProject: String,
        val credentialsMatch: Boolean,
        val youtubeDataApiEnabled: Boolean = true,
        val usesOldProject: Boolean = false
    )

    fun getDiagnostics(oauthProject: String): Diagnostics {
        val match = oauthProject == TARGET_PROJECT_NUMBER
        val old = oauthProject == OLD_PROJECT_NUMBER
        return Diagnostics(
            expectedYouTubeProject = TARGET_PROJECT_NUMBER,
            apiKeyProject = TARGET_PROJECT_NUMBER,
            oauthClientProject = oauthProject,
            credentialsMatch = match,
            youtubeDataApiEnabled = true,
            usesOldProject = old
        )
    }

    suspend fun updateVideoPrivacy(
        accessToken: String,
        videoId: String,
        privacyStatus: String = "public"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val url = "$YOUTUBE_API_BASE_URL/videos?part=status&key=$configuredApiKey"
            val payload = JSONObject().apply {
                put("id", videoId)
                put("status", JSONObject().apply {
                    put("privacyStatus", privacyStatus)
                })
            }
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $accessToken")
                .put(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("HTTP ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun uploadVideo(
        accessToken: String,
        title: String,
        description: String,
        tags: List<String>,
        privacyStatus: String,
        videoLength: Long,
        mimeType: String,
        openStream: () -> java.io.InputStream?,
        onProgress: (uploaded: Long, total: Long) -> Unit
    ): YouTubeUploadResult = withContext(Dispatchers.IO) {
        try {
            val metaUrl = "$YOUTUBE_UPLOAD_BASE_URL/videos?uploadType=resumable&part=snippet,status&key=$configuredApiKey"
            val metadata = JSONObject().apply {
                put("snippet", JSONObject().apply {
                    put("title", title)
                    put("description", description)
                    put("tags", org.json.JSONArray(tags))
                })
                put("status", JSONObject().apply {
                    put("privacyStatus", privacyStatus)
                })
            }
            val metaRequest = Request.Builder()
                .url(metaUrl)
                .header("Authorization", "Bearer $accessToken")
                .header("X-Upload-Content-Type", mimeType)
                .header("X-Upload-Content-Length", videoLength.toString())
                .post(metadata.toString().toRequestBody("application/json; charset=UTF-8".toMediaType()))
                .build()
            val metaResponse = client.newCall(metaRequest).execute()
            if (!metaResponse.isSuccessful) {
                return@withContext YouTubeUploadResult.Failure("Init upload failed HTTP ${metaResponse.code}")
            }
            val uploadLocation = metaResponse.header("Location")
                ?: return@withContext YouTubeUploadResult.Failure("No upload location returned")

            val stream = openStream() ?: return@withContext YouTubeUploadResult.Failure("Cannot open video stream")
            val bytes = stream.use { it.readBytes() }
            onProgress(bytes.size.toLong(), bytes.size.toLong())

            val uploadRequest = Request.Builder()
                .url(uploadLocation)
                .header("Authorization", "Bearer $accessToken")
                .put(bytes.toRequestBody(mimeType.toMediaType()))
                .build()
            val uploadResponse = client.newCall(uploadRequest).execute()
            val body = uploadResponse.body?.string() ?: ""
            if (uploadResponse.isSuccessful) {
                val json = JSONObject(body)
                val videoId = json.optString("id")
                YouTubeUploadResult.Success(videoId, title, "https://youtu.be/$videoId")
            } else {
                YouTubeUploadResult.Failure("Upload failed HTTP ${uploadResponse.code}")
            }
        } catch (e: Exception) {
            YouTubeUploadResult.Failure(e.message ?: "Upload exception")
        }
    }
}
