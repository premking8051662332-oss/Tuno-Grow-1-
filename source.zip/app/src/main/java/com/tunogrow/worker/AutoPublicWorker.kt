package com.tunogrow.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class AutoPublicWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val KEY_JOB_ID = "job_id"
        const val KEY_VIDEO_ID = "video_id"
        const val KEY_USER_ID = "user_id"
        const val KEY_TITLE = "title"
    }

    override suspend fun doWork(): Result {
        return Result.success()
    }
}
