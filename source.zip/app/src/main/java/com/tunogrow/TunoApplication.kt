package com.tunogrow

import android.app.Application
import com.tunogrow.ads.UnityAdsManager

class TunoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        UnityAdsManager.init(this)
    }
}
