package com.tunogrow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tunogrow.ui.admin.AdminScreen
import com.tunogrow.ui.auth.AuthScreen
import com.tunogrow.ui.components.TunoBottomNav
import com.tunogrow.ui.components.TunoGrowLogo
import com.tunogrow.ui.getcoin.GetCoinScreen
import com.tunogrow.ui.getfollower.GetFollowerScreen
import com.tunogrow.ui.home.HomeScreen
import com.tunogrow.ui.profile.ProfileScreen
import com.tunogrow.ui.tasks.YouTubeTaskScreen
import com.tunogrow.ui.theme.TunoDarkBackground
import com.tunogrow.ui.theme.TunoGrowTheme
import com.tunogrow.ui.theme.TunoRed
import com.tunogrow.viewmodel.AuthViewModel
import com.tunogrow.viewmodel.TunoViewModel

import androidx.lifecycle.compose.collectAsStateWithLifecycle

import androidx.compose.runtime.saveable.rememberSaveable
import com.tunogrow.ui.splash.SplashScreen
import com.tunogrow.ui.upgrade.UpgradeAccountScreen
import com.tunogrow.ui.coins.FreeCoinsScreen
import com.tunogrow.ui.transfer.TransferCoinScreen
import com.tunogrow.ui.invite.InviteFriendsScreen
import com.tunogrow.ui.support.SupportScreen
import com.tunogrow.ui.getcoin.JarvisScreen
import com.tunogrow.ui.getcoin.ChatAiScreen
import com.tunogrow.ui.order.SubmitOrdersScreen
import com.tunogrow.ui.order.OrderForOthersScreen
import com.tunogrow.auth.GoogleAuthHelper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import android.app.Activity
import com.tunogrow.jarvis.FloatingJarvisOverlay
import com.tunogrow.jarvis.JarvisCommandController
import com.tunogrow.jarvis.AppActionRegistry
import com.tunogrow.ui.components.NotificationDialog
import com.tunogrow.ui.components.ApiSettingsDialog
import com.tunogrow.ui.components.AboutDialog
import com.tunogrow.ads.UnityAdsManager
import com.tunogrow.network.GeminiApiService

class MainActivity : ComponentActivity() {
  private val authViewModel: AuthViewModel by viewModels()
  private val tunoViewModel: TunoViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Unity Ads SDK on launch
    UnityAdsManager.init(this)

    // Check pending OAuth redirect result (equivalent to getRedirectResult)
    authViewModel.checkPendingAuthResult(this)

    // Initialize Jarvis Voice Controller and API preferences
    JarvisCommandController.init(this)
    GeminiApiService.initPrefs(this)
    com.tunogrow.ui.profile.ProfilePreferences.init(this)

    setContent {
      val isDarkMode by com.tunogrow.ui.profile.ProfilePreferences.darkMode.collectAsStateWithLifecycle()
      TunoGrowTheme(darkTheme = isDarkMode) {
        val isAuthLoading by authViewModel.isAuthLoading.collectAsStateWithLifecycle()
        val currentUser by authViewModel.currentUser.collectAsStateWithLifecycle()
        var splashAnimDone by rememberSaveable { mutableStateOf(false) }

        LaunchedEffect(currentUser?.uid) {
          tunoViewModel.refreshForUser()
        }

        if (!splashAnimDone || isAuthLoading) {
          SplashScreen(
            onAnimationFinished = {
              splashAnimDone = true
            }
          )
        } else if (currentUser == null) {
          AuthScreen(viewModel = authViewModel)
        } else {
          val navController = rememberNavController()
          val navBackStackEntry by navController.currentBackStackEntryAsState()
          val currentRoute = navBackStackEntry?.destination?.route ?: "home"

          val googleSignInLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.StartActivityForResult()
          ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
              val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
              try {
                val account = task.getResult(ApiException::class.java)
                if (account != null) {
                  tunoViewModel.setPendingGoogleAccount(account)
                  tunoViewModel.connectYouTubeChannelWithAccount(this@MainActivity, account) { _, _ -> }
                }
              } catch (_: Exception) {}
            }
          }

          val showBottomNav = currentRoute in listOf("home", "get_coin", "get_follower")

          LaunchedEffect(currentRoute) {
            AppActionRegistry.updateCurrentScreen(currentRoute)
          }

          DisposableEffect(navController) {
            AppActionRegistry.navigateToRoute = { route ->
              navController.navigate(route) {
                popUpTo("home") { saveState = true }
                launchSingleTop = true
                restoreState = true
              }
            }
            AppActionRegistry.popBackAction = {
              navController.popBackStack()
            }
            AppActionRegistry.triggerLogout = {
              authViewModel.logout()
              tunoViewModel.refreshForUser()
            }
            onDispose {
              AppActionRegistry.navigateToRoute = null
              AppActionRegistry.popBackAction = null
              AppActionRegistry.triggerLogout = null
            }
          }

          val showNotifications by AppActionRegistry.showNotificationsDialog.collectAsStateWithLifecycle()
          val showApiSettings by AppActionRegistry.showApiSettingsDialog.collectAsStateWithLifecycle()
          val showAbout by AppActionRegistry.showAboutDialog.collectAsStateWithLifecycle()
          val notifications by tunoViewModel.notifications.collectAsStateWithLifecycle()

          Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
              modifier = Modifier.fillMaxSize(),
              contentWindowInsets = WindowInsets.systemBars,
              bottomBar = {
                if (showBottomNav) {
                  TunoBottomNav(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                      if (route != currentRoute) {
                        navController.navigate(route) {
                          popUpTo("home") { saveState = true }
                          launchSingleTop = true
                          restoreState = true
                        }
                      }
                    }
                  )
                }
              }
            ) { innerPadding ->
            NavHost(
              navController = navController,
              startDestination = "home",
              modifier = Modifier.padding(innerPadding)
            ) {
              composable("home") {
                HomeScreen(
                  viewModel = tunoViewModel,
                  onNavigate = { route -> navController.navigate(route) },
                  onOpenProfile = { navController.navigate("profile") },
                  onLogout = {
                    authViewModel.logout()
                    tunoViewModel.refreshForUser()
                  }
                )
              }

              composable("get_coin") {
                GetCoinScreen(
                  viewModel = tunoViewModel,
                  onNavigate = { route -> navController.navigate(route) }
                )
              }
              composable("video_task") {
                YouTubeTaskScreen(
                  viewModel = tunoViewModel,
                  initialTaskType = "subscribe",
                  onBack = { navController.popBackStack() }
                )
              }
              composable("view_task") {
                YouTubeTaskScreen(
                  viewModel = tunoViewModel,
                  initialTaskType = "subscribe",
                  onBack = { navController.popBackStack() }
                )
              }
              composable("like_task") {
                YouTubeTaskScreen(
                  viewModel = tunoViewModel,
                  initialTaskType = "subscribe",
                  onBack = { navController.popBackStack() }
                )
              }
              composable("subscribe_task") {
                YouTubeTaskScreen(
                  viewModel = tunoViewModel,
                  initialTaskType = "subscribe",
                  onBack = { navController.popBackStack() }
                )
              }
              composable("youtube_task/{taskType}") {
                YouTubeTaskScreen(
                  viewModel = tunoViewModel,
                  initialTaskType = "subscribe",
                  onBack = { navController.popBackStack() }
                )
              }

              composable("jarvis") {
                JarvisScreen(
                  viewModel = tunoViewModel,
                  onBack = { navController.popBackStack() }
                )
              }
              composable("chat_ai") {
                ChatAiScreen(
                  onBack = { navController.popBackStack() }
                )
              }
              composable("get_follower") {
                GetFollowerScreen(viewModel = tunoViewModel)
              }
              composable("profile") {
                ProfileScreen(
                  authViewModel = authViewModel,
                  tunoViewModel = tunoViewModel,
                  onOpenAdmin = { navController.navigate("admin") },
                  onBack = {
                    navController.navigate("home") {
                      popUpTo("home") { saveState = true }
                      launchSingleTop = true
                    }
                  }
                )
              }
              composable("admin") {
                AdminScreen(
                  viewModel = tunoViewModel,
                  onBack = { navController.popBackStack() }
                )
              }
              composable("submit_orders") {
                SubmitOrdersScreen(
                  viewModel = tunoViewModel,
                  onBack = { navController.popBackStack() }
                )
              }
              composable("order_for_others") {
                OrderForOthersScreen(
                  viewModel = tunoViewModel,
                  onBack = { navController.popBackStack() }
                )
              }
              composable("splash_intro") {
                SplashScreen(
                  onAnimationFinished = {
                    navController.popBackStack()
                  }
                )
              }
              composable("upgrade_account") {
                UpgradeAccountScreen(
                  viewModel = tunoViewModel,
                  onBack = { navController.popBackStack() }
                )
              }
              composable("free_coins") {
                FreeCoinsScreen(
                  viewModel = tunoViewModel,
                  onNavigate = { route -> navController.navigate(route) },
                  onBack = { navController.popBackStack() }
                )
              }
              composable("transfer_coin") {
                TransferCoinScreen(
                  viewModel = tunoViewModel,
                  onBack = { navController.popBackStack() }
                )
              }
              composable("invite_friends") {
                InviteFriendsScreen(
                  viewModel = tunoViewModel,
                  onBack = { navController.popBackStack() }
                )
              }
              composable("support") {
                SupportScreen(
                  onBack = { navController.popBackStack() }
                )
              }
            }
          }

          // Always available Floating Jarvis Voice Controller on all screens
          FloatingJarvisOverlay()

          // Voice / Button controllable dialogs
          if (showNotifications) {
            NotificationDialog(
              notifications = notifications,
              onDismiss = { AppActionRegistry.showNotificationsDialog.value = false },
              onClearAll = { tunoViewModel.markNotificationsAsRead() }
            )
          }

          if (showApiSettings) {
            ApiSettingsDialog(
              onDismiss = { AppActionRegistry.showApiSettingsDialog.value = false }
            )
          }

          if (showAbout) {
            AboutDialog(
              onDismiss = { AppActionRegistry.showAboutDialog.value = false }
            )
          }
        }
      }
    }
  }
}
}
