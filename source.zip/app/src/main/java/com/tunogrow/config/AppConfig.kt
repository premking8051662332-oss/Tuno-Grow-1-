package com.tunogrow.config

/**
 * Central configuration constants for Tuno Grow application.
 * Allows easy modification of external links, contact emails, and social channels.
 */
object AppConfig {
  // Official Website / Our Website URLs
  const val WEBSITE_URL = "https://tunoofficial1.blogspot.com"
  const val OFFICIAL_WEBSITE_URL = "https://tunoofficial1.blogspot.com"
  const val OUR_WEBSITE_URL = "https://tunoofficial1.blogspot.com"

  // Share App URL
  const val SHARE_APP_URL = "https://tunovideodownloadapk.blogspot.com/?m=1"

  // Official Telegram Channel URL
  const val TELEGRAM_CHANNEL_URL = "https://t.me/Tuno_Grow"

  // Official Telegram Group URL
  const val TELEGRAM_GROUP_URL = "http://t.me/TunoGrow_Bot"

  // Official Support Email
  const val SUPPORT_EMAIL = "officialtunosupport.@gmail.com"
}
