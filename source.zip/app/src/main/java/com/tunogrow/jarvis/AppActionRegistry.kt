package com.tunogrow.jarvis

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object AppActionRegistry {
    private val _currentScreen = MutableStateFlow("home")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    val showNotificationsDialog = MutableStateFlow(false)
    val showApiSettingsDialog = MutableStateFlow(false)
    val showAboutDialog = MutableStateFlow(false)

    var navigateToRoute: ((String) -> Unit)? = null
    var popBackAction: (() -> Unit)? = null
    var triggerLogout: (() -> Unit)? = null

    fun updateCurrentScreen(route: String) {
        _currentScreen.value = route
    }

    fun openApiSettings() {
        showApiSettingsDialog.value = true
    }
}
