package com.tunogrow.jarvis

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object JarvisCommandController {
    private val _isListening = MutableStateFlow(false)
    val isListening = _isListening.asStateFlow()

    private val _jarvisResponse = MutableStateFlow("Tap to speak to Jarvis")
    val jarvisResponse = _jarvisResponse.asStateFlow()

    fun init(context: Context) {
        // Initializes voice command handler
    }

    fun startListening() {
        _isListening.value = true
        _jarvisResponse.value = "Listening..."
    }

    fun stopListening() {
        _isListening.value = false
        _jarvisResponse.value = "Tap to speak to Jarvis"
    }
}
