package com.tunogrow.ui.invite

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.config.AppConfig
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InviteFriendsScreen(
  viewModel: TunoViewModel,
  onBack: () -> Unit
) {
  BackHandler { onBack() }

  val context = LocalContext.current
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val coroutineScope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  // Unique referral code based on user's UID
  val referralCode = remember(userProfile?.uid) {
    userProfile?.uid?.take(8)?.uppercase() ?: "TUNO2026"
  }

  // Simulated or stored stats
  val invitedCount = remember(userProfile?.uid) {
    // Derive invited count or default stat
    (userProfile?.uid?.hashCode()?.mod(5) ?: 0).coerceAtLeast(0)
  }
  val earnedFromReferrals = invitedCount * 100L

  val shareMessage = "Join me on Tuno Grow to boost your YouTube channel with real subscribers and video views! Use my invite code: $referralCode to get 100 free bonus coins! Download here: ${AppConfig.SHARE_APP_URL}"

  Scaffold(
    containerColor = TunoDarkBackground,
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Invite Friends",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color.White
          )
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
        },
        actions = {
          Surface(
            color = Color(0xFF2C1E0A),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, TunoGold.copy(alpha = 0.5f)),
            modifier = Modifier.padding(end = 12.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.MonetizationOn,
                contentDescription = null,
                tint = TunoGold,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${userProfile?.coins ?: 0}",
                color = TunoGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header Banner
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = Color.Transparent),
          border = BorderStroke(1.dp, Color(0xFF2563EB).copy(alpha = 0.4f))
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                Brush.verticalGradient(
                  listOf(
                    Color(0xFF0F2656),
                    Color(0xFF0B172E)
                  )
                )
              )
              .padding(20.dp)
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Box(
                modifier = Modifier
                  .size(56.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF1D4ED8)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.GroupAdd,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(32.dp)
                )
              }
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "Refer Friends & Earn Coins",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Invite your fellow YouTube creators to Tuno Grow. Both of you receive +100 Coins when they sign up with your referral code.",
                fontSize = 13.sp,
                color = TunoTextSecondary,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
              )
            }
          }
        }
      }

      // Referral Code Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2226))
        ) {
          Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "YOUR UNIQUE INVITE CODE",
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              color = TunoTextSecondary,
              letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Surface(
              color = Color(0xFF141414),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.5.dp, Color(0xFF2563EB)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = referralCode,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color.White,
                  letterSpacing = 2.sp
                )

                Row {
                  IconButton(
                    onClick = {
                      val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                      val clip = ClipData.newPlainText("Tuno Grow Invite Code", referralCode)
                      clipboard.setPrimaryClip(clip)
                      coroutineScope.launch {
                        snackbarHostState.showSnackbar("Invite code copied: $referralCode")
                      }
                    }
                  ) {
                    Icon(
                      imageVector = Icons.Default.ContentCopy,
                      contentDescription = "Copy Code",
                      tint = Color(0xFF64B5F6)
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons: Copy & Share
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              OutlinedButton(
                onClick = {
                  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                  val clip = ClipData.newPlainText("Tuno Grow Invite Code", referralCode)
                  clipboard.setPrimaryClip(clip)
                  coroutineScope.launch {
                    snackbarHostState.showSnackbar("Invite code copied!")
                  }
                },
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF2563EB))
              ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF64B5F6), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Copy Code", color = Color(0xFF64B5F6), fontWeight = FontWeight.Bold)
              }

              Button(
                onClick = {
                  val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, shareMessage)
                    type = "text/plain"
                  }
                  val shareIntent = Intent.createChooser(sendIntent, "Share Tuno Grow Invite")
                  context.startActivity(shareIntent)
                },
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D5CC4))
              ) {
                Icon(Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share Link", color = Color.White, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      // Stats Section: Invited users & Earned coins
      item {
        Text(
          text = "Your Referral Performance",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
            border = BorderStroke(1.dp, Color(0xFF2E2226))
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF1E3A8A)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.People,
                  contentDescription = null,
                  tint = Color(0xFF93C5FD),
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "$invitedCount",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Text(
                text = "Invited Users",
                fontSize = 12.sp,
                color = TunoTextSecondary
              )
            }
          }

          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
            border = BorderStroke(1.dp, Color(0xFF2E2226))
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF2C1E0A)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.MonetizationOn,
                  contentDescription = null,
                  tint = TunoGold,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "+$earnedFromReferrals",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TunoGold
              )
              Text(
                text = "Earned Coins",
                fontSize = 12.sp,
                color = TunoTextSecondary
              )
            }
          }
        }
      }

      // How It Works Steps
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2226))
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
              text = "How Referral Rewards Work",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )

            ReferralStepItem(
              stepNumber = "1",
              title = "Share your code",
              description = "Send your invite code or link to YouTube creators and friends."
            )
            ReferralStepItem(
              stepNumber = "2",
              title = "Friend signs up",
              description = "They enter your code when joining Tuno Grow."
            )
            ReferralStepItem(
              stepNumber = "3",
              title = "Both get +100 Coins",
              description = "Instant credit to both wallets for campaigns and promotions."
            )
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}

@Composable
private fun ReferralStepItem(
  stepNumber: String,
  title: String,
  description: String
) {
  Row(
    verticalAlignment = Alignment.Top,
    modifier = Modifier.fillMaxWidth()
  ) {
    Box(
      modifier = Modifier
        .size(28.dp)
        .clip(CircleShape)
        .background(Color(0xFF1D5CC4)),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = stepNumber,
        color = Color.White,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
      )
    }
    Spacer(modifier = Modifier.width(12.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White
      )
      Text(
        text = description,
        fontSize = 12.sp,
        color = TunoTextSecondary,
        lineHeight = 16.sp
      )
    }
  }
}
