package com.tunogrow.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TunoDarkColorScheme = darkColorScheme(
    primary = TunoRed,
    onPrimary = Color.White,
    primaryContainer = TunoRedDark,
    onPrimaryContainer = Color.White,
    secondary = TunoGold,
    onSecondary = Color.Black,
    background = TunoDarkBackground,
    onBackground = TunoTextPrimary,
    surface = TunoDarkSurface,
    onSurface = TunoTextPrimary,
    surfaceVariant = TunoCardSurface,
    onSurfaceVariant = TunoTextSecondary
)

@Composable
fun TunoGrowTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TunoDarkColorScheme,
        typography = Typography,
        content = content
    )
}
