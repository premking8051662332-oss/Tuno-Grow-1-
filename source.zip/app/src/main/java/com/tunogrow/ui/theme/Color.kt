package com.tunogrow.ui.theme

import androidx.compose.ui.graphics.Color

val TunoRed = Color(4294913365L)
val TunoRedDark = Color(4292288066L)
val TunoDarkBackground = Color(4279374354L)
val TunoDarkSurface = Color(4280163870L)
val TunoCardSurface = Color(4280624421L)
val TunoTextPrimary = Color(4294967295L)
val TunoTextSecondary = Color(4289769648L)
val TunoGold = Color(4294956800L)
