package com.tunogrow.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tunogrow.ui.theme.TunoCardSurface
import com.tunogrow.ui.theme.TunoDarkBackground
import com.tunogrow.ui.theme.TunoRed
import com.tunogrow.ui.theme.TunoTextSecondary

@Composable
fun ApiSettingsDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("API Settings", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Tuno Grow uses Google AI Studio Gemini API and YouTube Data API v3 for smart channel recommendations and automated tasks.",
                    color = TunoTextSecondary,
                    fontSize = 13.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
            ) {
                Text("Close", color = Color.White)
            }
        },
        containerColor = TunoDarkBackground
    )
}
