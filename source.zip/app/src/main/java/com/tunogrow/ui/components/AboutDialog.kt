package com.tunogrow.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tunogrow.config.AppConfig
import com.tunogrow.ui.theme.TunoDarkBackground
import com.tunogrow.ui.theme.TunoRed
import com.tunogrow.ui.theme.TunoTextSecondary

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("About Tuno Grow", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Version: ${AppConfig.APP_VERSION_NAME}", color = Color.White, fontSize = 14.sp)
                Text(
                    "Tuno Grow is the premier YouTube Channel Growth & Community platform for subscribers, views, likes, and rewards.",
                    color = TunoTextSecondary,
                    fontSize = 13.sp
                )
                Text("Support: ${AppConfig.SUPPORT_EMAIL}", color = TunoTextSecondary, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
            ) {
                Text("OK", color = Color.White)
            }
        },
        containerColor = TunoDarkBackground
    )
}
