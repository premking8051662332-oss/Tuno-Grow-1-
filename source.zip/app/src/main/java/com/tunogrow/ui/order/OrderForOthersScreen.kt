package com.tunogrow.ui.order

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderForOthersScreen(
    viewModel: TunoViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    var channelName by remember { mutableStateOf("") }
    var channelUrl by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("10") }

    val quantity = quantityText.toIntOrNull() ?: 10
    val totalCost = quantity * 10L

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Order For Others", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
            )
        },
        containerColor = TunoDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (userProfile?.isBanned == true) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3E1215)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha.",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Text(
                "Sponsor a Friend's Channel",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Text(
                "Enter their YouTube channel name or URL to boost their subscribers using your coins.",
                color = TunoTextSecondary,
                fontSize = 13.sp
            )

            OutlinedTextField(
                value = channelName,
                onValueChange = { channelName = it },
                label = { Text("Channel Name") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = TunoRed,
                    unfocusedBorderColor = Color(0xFF444444)
                )
            )

            OutlinedTextField(
                value = channelUrl,
                onValueChange = { channelUrl = it },
                label = { Text("Channel URL or Channel ID") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = TunoRed,
                    unfocusedBorderColor = Color(0xFF444444)
                )
            )

            OutlinedTextField(
                value = quantityText,
                onValueChange = { quantityText = it },
                label = { Text("Subscribers (min 5)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = TunoRed,
                    unfocusedBorderColor = Color(0xFF444444)
                )
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total Cost (10 🪙/sub)", color = TunoTextSecondary, fontSize = 12.sp)
                        Text("$totalCost Coins", color = TunoGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Text(
                        text = "Balance: ${userProfile?.coins ?: 0} 🪙",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (userProfile?.isBanned == true) {
                        Toast.makeText(context, "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha.", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    if (channelName.isBlank()) {
                        Toast.makeText(context, "Please enter channel name", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val targetChId = if (channelUrl.startsWith("UC")) channelUrl else "UC_${System.currentTimeMillis()}"

                    viewModel.createExternalOrder(
                        channelId = targetChId,
                        channelName = channelName,
                        videoId = "",
                        videoTitle = "",
                        videoThumbnail = "",
                        actionType = "subscribe",
                        targetUserId = targetChId,
                        targetUserName = channelName,
                        quantity = quantity,
                        costPerUnit = 10L
                    ) { success, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (success) onBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = userProfile?.isBanned != true && (userProfile?.coins ?: 0L) >= totalCost && channelName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = TunoRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Place Gift Order", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }
    }
}
