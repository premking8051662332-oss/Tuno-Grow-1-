package com.tunogrow.ui.getcoin

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.tunogrow.model.FollowerRequestModel
import com.tunogrow.model.TaskModel
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


data class YouTubeActionItem(
  val id: String,
  val type: String, // "Subscribe", "Like", "Views"
  val title: String,
  val channelTitle: String,
  val targetUrl: String,
  val avatarUrl: String,
  val rewardCoins: Long,
  val ownerUid: String = ""
)

@Composable
fun GetCoinScreen(
  viewModel: TunoViewModel,
  onNavigate: (String) -> Unit = {}
) {
  val context = LocalContext.current
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val completions by viewModel.userCompletions.collectAsStateWithLifecycle()
  val tasks by viewModel.tasks.collectAsStateWithLifecycle()
  val followerRequests by viewModel.followerRequests.collectAsStateWithLifecycle()
  val activeCommunityOrders by viewModel.activeCommunityOrders.collectAsStateWithLifecycle()
  val completedOrderIds by viewModel.completedOrderIds.collectAsStateWithLifecycle()
  val videoTasks by viewModel.videoTasks.collectAsStateWithLifecycle()
  val userVideoTaskProgress by viewModel.userVideoTaskProgress.collectAsStateWithLifecycle()
  val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
  val coroutineScope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  // Keep ONLY Subscribe Category strictly as requested
  val categories = remember { listOf("Subscribe") }
  var selectedCategory by remember { mutableStateOf("Subscribe") }

  // Cooldown / Verification state
  var activeVerifyingTaskId by remember { mutableStateOf<String?>(null) }
  var cooldownSeconds by remember { mutableStateOf(0) }
  var isClaimingReward by remember { mutableStateOf(false) }



  val currentUserId = userProfile?.uid ?: ""

  // Derive YouTube Actions from Realtime Firestore Orders & Tasks:
  // Specification Rules:
  // 1. Prevent self-earning: order.createdByUserId == currentUserId are filtered out
  // 2. Prevent duplicate earning: completedOrderIds.contains(order.orderId) are filtered out
  // 3. Hide finished orders: remainingCount <= 0 or status != "active" are filtered out
  val ytActions: List<YouTubeActionItem> = remember(activeCommunityOrders, tasks, currentUserId, completedOrderIds) {
    val items = mutableListOf<YouTubeActionItem>()

    // 1. From real community orders submitted via "Order For Others" or "Submit Orders"
    activeCommunityOrders.forEach { order ->
      // Filter out self-created orders (Prevent self-earning)
      if (currentUserId.isNotBlank() && order.createdByUserId == currentUserId) return@forEach
      // Filter out completed by this user (Prevent duplicate earning)
      if (completedOrderIds.contains(order.orderId)) return@forEach
      // Filter out inactive or exhausted orders
      if (!order.status.equals("active", ignoreCase = true) || order.remainingCount <= 0 || order.completedCount >= order.requestedCount) return@forEach

      val normType = when (order.orderType.lowercase()) {
        "like" -> "Like"
        "views", "view" -> "Views"
        else -> "Subscribe"
      }
      val targetUrl = when {
        order.videoId.isNotBlank() -> "https://www.youtube.com/watch?v=${order.videoId}"
        order.channelId.isNotBlank() -> "https://www.youtube.com/channel/${order.channelId}"
        else -> "https://www.youtube.com"
      }
      val title = when (normType) {
        "Like" -> if (order.videoTitle.isNotBlank()) "Like: ${order.videoTitle}" else "Like Video"
        "Views" -> if (order.videoTitle.isNotBlank()) "Watch: ${order.videoTitle}" else "Watch Video"
        else -> "Subscribe to ${order.channelName.ifBlank { "Creator Channel" }}"
      }
      val reward = when (normType) {
        "Subscribe" -> 10L
        "Views" -> 8L
        else -> 5L
      }

      items.add(
        YouTubeActionItem(
          id = order.orderId,
          type = normType,
          title = title,
          channelTitle = order.channelName.ifBlank { order.targetUserName.ifBlank { "Creator" } },
          targetUrl = targetUrl,
          avatarUrl = order.videoThumbnail,
          rewardCoins = reward,
          ownerUid = order.createdByUserId
        )
      )
    }

    // 2. From tasks collection (system / admin or community tasks)
    tasks.forEach { t ->
      if (currentUserId.isNotBlank() && t.ownerUid == currentUserId) return@forEach
      if (completedOrderIds.contains(t.taskId)) return@forEach
      if (items.none { it.id == t.taskId }) {
        items.add(
          YouTubeActionItem(
            id = t.taskId,
            type = "Subscribe",
            title = t.title,
            channelTitle = t.title.substringAfter("Subscribe to ").ifBlank { "Creator" },
            targetUrl = t.youtubeChannelUrl,
            avatarUrl = "",
            rewardCoins = t.reward,
            ownerUid = t.ownerUid
          )
        )
      }
    }

    items
  }

  val filteredYtActions = remember(ytActions) {
    ytActions.filter { it.type.equals("Subscribe", ignoreCase = true) }
  }

  // Counts of available internal tasks for the 3 main cards
  val availableViewCount = remember(ytActions) {
    ytActions.count { it.type.equals("Views", ignoreCase = true) }
  }
  val availableLikeCount = remember(ytActions) {
    ytActions.count { it.type.equals("Like", ignoreCase = true) }
  }
  val availableSubCount = remember(ytActions) {
    ytActions.count { it.type.equals("Subscribe", ignoreCase = true) }
  }

  // Daily limit computation (e.g. max 20 YouTube tasks per day)
  val todayStart = remember {
    val cal = java.util.Calendar.getInstance()
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.timeInMillis
  }
  val ytCompletionsToday = completions.count { it.createdAt >= todayStart }
  val dailyLimit = 20
  val isDailyLimitReached = ytCompletionsToday >= dailyLimit

  LaunchedEffect(actionMessage) {
    if (actionMessage != null) {
      snackbarHostState.showSnackbar(actionMessage ?: "")
      viewModel.clearActionMessage()
    }
  }

  fun openYouTubeUrl(url: String, actionId: String) {
    try {
      val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
      activeVerifyingTaskId = actionId
    } catch (_: Exception) {
      try {
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(webIntent)
        activeVerifyingTaskId = actionId
      } catch (_: Exception) {
        coroutineScope.launch {
          snackbarHostState.showSnackbar("Unable to open YouTube")
        }
      }
    }
  }

  fun handleClaimYouTubeAction(item: YouTubeActionItem) {
    if (isDailyLimitReached) {
      coroutineScope.launch {
        snackbarHostState.showSnackbar("Daily YouTube limit reached (20/20 tasks). Please return tomorrow!")
      }
      return
    }

    isClaimingReward = true
    viewModel.completeYouTubeAction(
      actionId = item.id,
      actionType = item.type,
      targetTitle = item.title,
      targetUrl = item.targetUrl,
      rewardCoins = item.rewardCoins,
      ownerUid = item.ownerUid
    ) { success, msg ->
      isClaimingReward = false
      if (success) {
        activeVerifyingTaskId = null
        cooldownSeconds = 0
      }
      coroutineScope.launch {
        snackbarHostState.showSnackbar(msg)
      }
    }
  }

  Scaffold(
    containerColor = TunoDarkBackground,
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp)
    ) {
      Spacer(modifier = Modifier.height(8.dp))

      // Top Header: Title & Navigation Shortcuts
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f, fill = false)) {
          Text(
            text = "Get Coin",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Text(
            text = "Complete Actions & Earn Real Coins",
            fontSize = 12.sp,
            color = TunoTextSecondary
          )
        }

        // Top Shortcuts: Reel, Jarvis, Chat AI
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF2A1B3D),
            border = BorderStroke(1.dp, Color(0xFFAB47BC)),
            modifier = Modifier.clickable { onNavigate("jarvis") }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.AutoAwesome, contentDescription = "Jarvis", tint = Color(0xFFCE93D8), modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(3.dp))
              Text("Jarvis", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF1B2B3D),
            border = BorderStroke(1.dp, Color(0xFF42A5F5)),
            modifier = Modifier.clickable { onNavigate("chat_ai") }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Chat, contentDescription = "Chat AI", tint = Color(0xFF90CAF9), modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(3.dp))
              Text("Chat AI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Coin Balance Banner
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = TunoCardSurface,
        border = BorderStroke(1.dp, TunoGold.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(TunoGold.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = TunoGold, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("Current Coin Balance", fontSize = 12.sp, color = TunoTextSecondary)
              Text(
                text = "${userProfile?.coins ?: 0} Coins",
                fontWeight = FontWeight.ExtraBold,
                color = TunoGold,
                fontSize = 17.sp
              )
            }
          }

          Surface(
            color = if (isDailyLimitReached) Color(0xFF2E1010) else Color(0xFF1A261A),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, if (isDailyLimitReached) TunoRed else Color(0xFF2E7D32))
          ) {
            Text(
              text = "Daily: $ytCompletionsToday/$dailyLimit",
              fontSize = 11.sp,
              color = if (isDailyLimitReached) Color(0xFFFCA5A5) else Color(0xFF81C784),
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // =======================================================================
      // 1. GET COIN — SUBSCRIBE TASK CARD (Subscribe category only)
      // =======================================================================
      Text(
        text = "Available YouTube Tasks",
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White,
        modifier = Modifier.padding(horizontal = 2.dp)
      )

      Spacer(modifier = Modifier.height(8.dp))

      // [ Subscribe Task Card ]
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigate("subscribe_task") },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF281414)),
        border = BorderStroke(1.5.dp, Brush.verticalGradient(listOf(Color(0xFFDC2626), Color(0xFF991B1B)))),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(Color(0xFFDC2626).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Subscriptions, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(26.dp))
          }
          Spacer(modifier = Modifier.width(14.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("Subscribe Tasks", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text("$availableSubCount Channels Available (+10 Coins)", fontSize = 12.sp, color = Color(0xFFFCA5A5), fontWeight = FontWeight.SemiBold)
          }
          Button(
            onClick = { onNavigate("subscribe_task") },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFCC0000)),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
          ) {
            Text("Subscribe", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Main Category Tab: Subscribe (10🪙) Only
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .height(44.dp),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFCC0000),
        border = BorderStroke(1.dp, Color(0xFFCC0000))
      ) {
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Subscriptions, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Subscribe Tasks (+10🪙)",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
          Text(
            text = "$availableSubCount available",
            fontSize = 11.sp,
            color = Color.White.copy(alpha = 0.9f),
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Available Orders for Selected Category
      if (filteredYtActions.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
          ) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(Color(0xFF1E293B)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = when (selectedCategory) {
                  "Like" -> Icons.Default.ThumbUp
                  "Subscribe" -> Icons.Default.Subscriptions
                  else -> Icons.Default.Visibility
                },
                contentDescription = null,
                tint = when (selectedCategory) {
                  "Like" -> Color(0xFF64B5F6)
                  "Subscribe" -> Color(0xFFFF8A80)
                  else -> Color(0xFFD8B4FE)
                },
                modifier = Modifier.size(32.dp)
              )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("No $selectedCategory orders available", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              "Orders placed by users in \"Order For Others\" appear here in real-time.",
              fontSize = 12.sp,
              color = TunoTextSecondary,
              textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(filteredYtActions) { item ->
            val isCompleted = completedOrderIds.contains(item.id) || completions.any { it.taskId == item.id }

            YouTubeActionCard(
              item = item,
              isCompleted = isCompleted,
              isVerifying = false,
              cooldownSeconds = 0,
              isClaimingReward = false,
              onOpenYouTube = {
                onNavigate("subscribe_task")
              },
              onClaimReward = {
                onNavigate("subscribe_task")
              }
            )
          }

          item {
            Spacer(modifier = Modifier.height(24.dp))
          }
        }
      }
    }
  }

}

/**
 * YouTube Action Card with Open YouTube button and Timer-based verification
 */
@Composable
private fun YouTubeActionCard(
  item: YouTubeActionItem,
  isCompleted: Boolean,
  isVerifying: Boolean,
  cooldownSeconds: Int,
  isClaimingReward: Boolean,
  onOpenYouTube: () -> Unit,
  onClaimReward: () -> Unit
) {
  val accentColor = when (item.type.lowercase()) {
    "like" -> Color(0xFF1E60D4)
    "views" -> Color(0xFF9C27B0)
    else -> Color(0xFFCC0000)
  }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
    border = BorderStroke(1.dp, if (isCompleted) Color(0xFF1E3A24) else Color(0xFF2E2E3E))
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          if (item.avatarUrl.isNotBlank()) {
            AsyncImage(
              model = item.avatarUrl,
              contentDescription = item.title,
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .border(1.dp, accentColor, CircleShape),
              contentScale = ContentScale.Crop
            )
          } else {
            Box(
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = when (item.type.lowercase()) {
                  "like" -> Icons.Default.ThumbUp
                  "views" -> Icons.Default.Visibility
                  else -> Icons.Default.Subscriptions
                },
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(24.dp)
              )
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                color = accentColor.copy(alpha = 0.2f),
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = item.type,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = accentColor,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = item.channelTitle,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = item.title,
              fontSize = 11.sp,
              color = TunoTextSecondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }

        // Reward Badge
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = TunoGold.copy(alpha = 0.15f),
          border = BorderStroke(1.dp, TunoGold.copy(alpha = 0.4f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = TunoGold, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = "+${item.rewardCoins}",
              fontWeight = FontWeight.ExtraBold,
              color = TunoGold,
              fontSize = 13.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action Buttons: Open YouTube and Verify/Claim
      if (isCompleted) {
        Surface(
          modifier = Modifier.fillMaxWidth().height(40.dp),
          shape = RoundedCornerShape(10.dp),
          color = Color(0xFF16A34A).copy(alpha = 0.15f),
          border = BorderStroke(1.dp, Color(0xFF16A34A).copy(alpha = 0.4f))
        ) {
          Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF86EFAC), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Completed & Claimed", color = Color(0xFF86EFAC), fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      } else {
        Button(
          onClick = {
            onOpenYouTube()
            onClaimReward()
          },
          enabled = !isClaimingReward,
          modifier = Modifier.fillMaxWidth().height(42.dp),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = accentColor)
        ) {
          if (isClaimingReward) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
          } else {
            Icon(
              imageVector = when (item.type.lowercase()) {
                "like" -> Icons.Default.ThumbUp
                "views" -> Icons.Default.PlayArrow
                else -> Icons.Default.Subscriptions
              },
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = when (item.type.lowercase()) {
                "like" -> "Like Video (+5 Coins)"
                "views" -> "Watch Video 2s (+8 Coins)"
                else -> "Subscribe (+10 Coins)"
              },
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}


