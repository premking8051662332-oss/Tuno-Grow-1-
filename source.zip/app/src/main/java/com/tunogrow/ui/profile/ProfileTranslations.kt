package com.tunogrow.ui.profile

object ProfileTranslations {
    data class LanguageItem(
        val code: String,
        val englishName: String,
        val nativeName: String
    )

    data class Strings(
        val profileTitle: String = "Profile & Settings",
        val accountId: String = "Account ID",
        val copyId: String = "Copy ID",
        val copiedToClipboard: String = "Copied to clipboard",
        val coins: String = "Coins",
        val appShare: String = "Share App",
        val appShareDesc: String = "Share with fellow creators",
        val checkForUpdates: String = "Check for Updates",
        val checkForUpdatesDesc: String = "Keep Tuno Grow up to date",
        val checkingUpdate: String = "Checking for updates...",
        val latestVersionMsg: String = "You are using the latest version of Tuno Grow.",
        val updateNow: String = "Update Now",
        val feedback: String = "Feedback",
        val feedbackDesc: String = "Rate and review app experience",
        val rateApp: String = "Rate Tuno Grow",
        val messagePlaceholder: String = "Write your feedback or suggestion...",
        val submit: String = "Submit",
        val submitting: String = "Submitting...",
        val thankYouFeedback: String = "Thank you for your feedback!",
        val help: String = "Help & Support",
        val helpDesc: String = "FAQs and direct support contact",
        val faqs: String = "Frequently Asked Questions",
        val emailSupport: String = "Email Support",
        val contactSupport: String = "Contact Support",
        val settings: String = "App Settings",
        val settingsDesc: String = "Theme, notifications, cache and data",
        val searchSettings: String = "Search settings...",
        val darkMode: String = "Dark Mode",
        val darkModeDesc: String = "Toggle dark/light visual theme",
        val language: String = "Language",
        val languageDesc: String = "Select preferred UI language",
        val selectLanguage: String = "Select Language",
        val notifications: String = "Push Notifications",
        val autoUpdate: String = "Auto Check Updates",
        val clearCache: String = "Clear Cache",
        val clearAppCache: String = "Clear temporary cached files",
        val cacheClearedMsg: String = "Cache cleared successfully",
        val privacyPolicy: String = "Privacy Policy",
        val termsConditions: String = "Terms & Conditions",
        val aboutApp: String = "About Tuno Grow",
        val appVersion: String = "Version",
        val apiSettings: String = "API Settings",
        val adminPortal: String = "Admin Portal",
        val signOut: String = "Sign Out",
        val close: String = "Close"
    )

    val supportedLanguages = listOf(
        LanguageItem("en", "English", "English"),
        LanguageItem("hi", "Hindi", "हिन्दी"),
        LanguageItem("bho", "Bhojpuri", "भोजपुरी"),
        LanguageItem("har", "Haryanvi", "हरियाणवी"),
        LanguageItem("raj", "Rajasthani", "राजस्थानी"),
        LanguageItem("pa", "Punjabi", "ਪੰਜਾਬੀ"),
        LanguageItem("bn", "Bengali", "বাংলা"),
        LanguageItem("gu", "Gujarati", "ગુજરાતી"),
        LanguageItem("mr", "Marathi", "मराठी"),
        LanguageItem("ta", "Tamil", "தமிழ்"),
        LanguageItem("te", "Telugu", "తెలుగు"),
        LanguageItem("kn", "Kannada", "ಕನ್ನಡ"),
        LanguageItem("ml", "Malayalam", "മലയാളം"),
        LanguageItem("or", "Odia", "ଓଡ଼ିଆ"),
        LanguageItem("as", "Assamese", "অসমীয়া")
    )

    val en = Strings()
    val hi = Strings(
        profileTitle = "प्रोफ़ाइल और सेटिंग्स",
        accountId = "खाता आईडी",
        copyId = "आईडी कॉपी करें",
        copiedToClipboard = "क्लिपबोर्ड पर कॉपी किया गया",
        coins = "कॉइन्स",
        appShare = "ऐप शेयर करें",
        appShareDesc = "साथी रचनाकारों के साथ साझा करें",
        checkForUpdates = "अपडेट जांचें",
        checkForUpdatesDesc = "ट्यूनो ग्रो को अपडेट रखें",
        checkingUpdate = "अपडेट की जांच हो रही है...",
        latestVersionMsg = "आप ट्यूनो ग्रो का नवीनतम संस्करण उपयोग कर रहे हैं।",
        updateNow = "अभी अपडेट करें",
        feedback = "फीडबैक",
        feedbackDesc = "रेटिंग दें और अनुभव साझा करें",
        rateApp = "ऐप को रेटिंग दें",
        messagePlaceholder = "अपनी राय या सुझाव लिखें...",
        submit = "जमा करें",
        submitting = "भेजा जा रहा है...",
        thankYouFeedback = "आपकी प्रतिक्रिया के लिए धन्यवाद!",
        help = "मदद और सहायता",
        helpDesc = "अक्सर पूछे जाने वाले सवाल और सहायता",
        faqs = "अक्सर पूछे जाने वाले प्रश्न",
        emailSupport = "ईमेल सहायता",
        contactSupport = "सहायता संपर्क",
        settings = "ऐप सेटिंग्स",
        settingsDesc = "थीम, सूचनाएं और कैश",
        searchSettings = "सेटिंग्स खोजें...",
        darkMode = "डार्क मोड",
        darkModeDesc = "डार्क / लाइट थीम बदलें",
        language = "भाषा",
        languageDesc = "पसंदीदा भाषा चुनें",
        selectLanguage = "भाषा चुनें",
        notifications = "सूचनाएं",
        autoUpdate = "ऑटो अपडेट जांचें",
        clearCache = "कैश साफ़ करें",
        clearAppCache = "अस्थायी फाइलें साफ़ करें",
        cacheClearedMsg = "कैश सफलतापूर्वक साफ़ किया गया",
        privacyPolicy = "गोपनीयता नीति",
        termsConditions = "नियम और शर्तें",
        aboutApp = "ऐप के बारे में",
        appVersion = "संस्करण",
        apiSettings = "एपीआई सेटिंग्स",
        adminPortal = "व्यवस्थापक पोर्टल",
        signOut = "साइन आउट",
        close = "बंद करें"
    )

    val bho = hi.copy(
        profileTitle = "प्रोफ़ाइल आ सेटिंग्स",
        appShare = "ऐप शेयर करीं",
        appShareDesc = "सब साथी लोगिन संगे शेयर करीं",
        checkForUpdates = "अपडेट जांचीं",
        feedback = "फीडबैक दीं",
        feedbackDesc = "ऐप के रेटिंग दीं आ आपन राय बताईं",
        help = "मदद आ सहायता",
        selectLanguage = "भाषा चुनीं",
        clearCache = "कैश साफ़ करीं",
        submit = "भेजीं",
        thankYouFeedback = "बहुत-बहुत धन्यवाद! राउर फीडबैक मिल गइल।"
    )

    val har = hi.copy(
        help = "मदद अर सहारा",
        language = "बोली / भाषा",
        clearCache = "कैश साफ़ करो",
        submit = "जमा करो",
        thankYouFeedback = "बहुत धन्यवाद भाई! थारा फीडबैक मिल गया।"
    )

    val raj = hi
    val pa = hi
    val bn = hi
    val gu = hi
    val mr = hi
    val ta = hi
    val te = hi
    val kn = hi
    val ml = hi
    val or = hi
    val asLang = hi

    fun get(langCode: String): Strings {
        return when (langCode.lowercase()) {
            "hi" -> hi
            "bho" -> bho
            "har" -> har
            "raj" -> raj
            "pa" -> pa
            "bn" -> bn
            "gu" -> gu
            "mr" -> mr
            "ta" -> ta
            "te" -> te
            "kn" -> kn
            "ml" -> ml
            "or" -> or
            "as" -> asLang
            else -> en
        }
    }
}
