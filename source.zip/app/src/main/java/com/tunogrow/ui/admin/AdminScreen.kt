package com.tunogrow.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.ui.theme.TunoCardSurface
import com.tunogrow.ui.theme.TunoDarkBackground
import com.tunogrow.ui.theme.TunoRed
import com.tunogrow.ui.theme.TunoTextSecondary
import com.tunogrow.viewmodel.TunoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: TunoViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val settings by viewModel.adminSettings.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = TunoDarkBackground,
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = TunoCardSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Reward Configuration", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Subscribe Reward: ${settings.subscribeReward} Coins", color = TunoTextSecondary, fontSize = 14.sp)
                    Text("Follower Cost: ${settings.followerCostPerSub} Coins / Subscriber", color = TunoTextSecondary, fontSize = 14.sp)
                }
            }
        }
    }
}
