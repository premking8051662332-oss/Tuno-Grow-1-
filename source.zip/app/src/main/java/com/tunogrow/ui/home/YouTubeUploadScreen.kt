package com.tunogrow.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tunogrow.ui.theme.TunoDarkBackground
import com.tunogrow.viewmodel.TunoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouTubeUploadScreen(
    viewModel: TunoViewModel,
    onBack: () -> Unit,
    onConnectYouTube: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Upload Video", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
            )
        },
        containerColor = TunoDarkBackground
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            Text("Upload Video Feature coming soon!", color = Color.Gray)
        }
    }
}

@Composable
fun EditDraftDialog(
    draft: com.tunogrow.model.DraftVideoModel,
    onDismiss: () -> Unit,
    onSave: (newTitle: String, newDesc: String, newTags: String, newPrivacy: String, newDelayMin: Int) -> Unit
) {
    val titleState = remember { mutableStateOf(draft.title) }
    val descriptionState = remember { mutableStateOf(draft.description) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Draft", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = titleState.value,
                    onValueChange = { titleState.value = it },
                    label = { Text("Title") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = descriptionState.value,
                    onValueChange = { descriptionState.value = it },
                    label = { Text("Description") }
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(titleState.value, descriptionState.value, draft.tags, draft.privacyStatus, draft.delayMinutes) }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CancelDraftDialog(
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cancel Draft", color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Text("Are you sure you want to cancel this draft upload?", color = Color.LightGray) },
        confirmButton = {
            Button(onClick = onConfirm) { Text("Yes, Cancel") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("No") }
        }
    )
}
