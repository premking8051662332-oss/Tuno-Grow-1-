package com.tunogrow.ui.profile

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.tunogrow.model.VideoUploadState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.tunogrow.auth.GoogleAuthHelper
import com.tunogrow.model.UserProfile
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tunogrow.ui.components.TunoGrowLogo
import com.tunogrow.ui.splash.SplashScreen
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.AuthViewModel
import com.tunogrow.viewmodel.TunoViewModel
import java.text.SimpleDateFormat
import java.util.*

import com.tunogrow.model.DraftVideoModel
import com.tunogrow.config.AppConfig
import com.tunogrow.ui.home.EditDraftDialog
import com.tunogrow.ui.home.CancelDraftDialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun ProfileScreen(
  authViewModel: AuthViewModel,
  tunoViewModel: TunoViewModel,
  onOpenAdmin: () -> Unit,
  onBack: () -> Unit
) {
  androidx.activity.compose.BackHandler { onBack() }
  val userProfile by tunoViewModel.userProfile.collectAsStateWithLifecycle()
  val isLoading by tunoViewModel.isLoading.collectAsStateWithLifecycle()
  val authRecoveryIntent by tunoViewModel.authRecoveryIntent.collectAsStateWithLifecycle()
  val actionMessage by tunoViewModel.actionMessage.collectAsStateWithLifecycle()
  val configError by tunoViewModel.configError.collectAsStateWithLifecycle()
  val noYouTubeChannelFound by tunoViewModel.noYouTubeChannelFound.collectAsStateWithLifecycle()
  val isConnected = userProfile?.youtubeConnected == true && !userProfile?.youtubeChannelId.isNullOrEmpty()

  val context = LocalContext.current
  val currentLangCode by ProfilePreferences.language.collectAsStateWithLifecycle()
  val isDarkMode by ProfilePreferences.darkMode.collectAsStateWithLifecycle()
  val strings = remember(currentLangCode) { ProfileTranslations.get(currentLangCode) }

  var showFeedbackDialog by remember { mutableStateOf(false) }
  var showUpdateDialog by remember { mutableStateOf(false) }
  var showLanguageDialog by remember { mutableStateOf(false) }
  var showHelpDialog by remember { mutableStateOf(false) }
  var showSettingsDialog by remember { mutableStateOf(false) }
  var infoDialogData by remember { mutableStateOf<Pair<String, String>?>(null) }

  LaunchedEffect(Unit) {
    ProfilePreferences.init(context)
  }

  var snackbarMessage by remember { mutableStateOf<String?>(null) }
  var showDisconnectDialog by remember { mutableStateOf(false) }
  var showReplaceConfirmDialog by remember { mutableStateOf(false) }
  var showSplashIntro by remember { mutableStateOf(false) }

  // Video Upload & Draft States
  val uploadState by tunoViewModel.uploadState.collectAsStateWithLifecycle()
  val draftVideos by tunoViewModel.draftVideos.collectAsStateWithLifecycle()
  var draftToEdit by remember { mutableStateOf<DraftVideoModel?>(null) }
  var draftToCancel by remember { mutableStateOf<DraftVideoModel?>(null) }
  var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
  var selectedVideoFileName by remember { mutableStateOf("") }
  var selectedVideoFileSize by remember { mutableStateOf("") }
  var videoTitle by remember { mutableStateOf("") }
  var videoDescription by remember { mutableStateOf("") }
  var videoTags by remember { mutableStateOf("") }
  var videoVisibility by remember { mutableStateOf("public") }
  var titleError by remember { mutableStateOf<String?>(null) }
  var descriptionError by remember { mutableStateOf<String?>(null) }
  var videoThumbnail by remember { mutableStateOf<Bitmap?>(null) }
  var videoDurationMs by remember { mutableStateOf<Long?>(null) }

  // Extract video preview frame and duration when a video is selected
  LaunchedEffect(selectedVideoUri) {
    val uri = selectedVideoUri
    if (uri != null) {
      withContext(Dispatchers.IO) {
        try {
          val retriever = MediaMetadataRetriever()
          retriever.setDataSource(context, uri)
          val bmp = retriever.frameAtTime ?: retriever.getFrameAtTime(1_000_000)
          val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
          val dur = durStr?.toLongOrNull()
          retriever.release()
          withContext(Dispatchers.Main) {
            videoThumbnail = bmp
            videoDurationMs = dur
          }
        } catch (_: Exception) {
          withContext(Dispatchers.Main) {
            videoThumbnail = null
            videoDurationMs = null
          }
        }
      }
    } else {
      videoThumbnail = null
      videoDurationMs = null
    }
  }

  // Zero-permission Android Photo/Video Picker
  val videoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      selectedVideoUri = uri
      var name = "video.mp4"
      var sizeBytes = 0L
      try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
          val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
          val sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
          if (cursor.moveToFirst()) {
            if (nameIndex != -1) name = cursor.getString(nameIndex) ?: "video.mp4"
            if (sizeIndex != -1) sizeBytes = cursor.getLong(sizeIndex)
          }
        }
      } catch (_: Exception) {}
      if (sizeBytes <= 0L) {
        try {
          context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
            sizeBytes = afd.length
          }
        } catch (_: Exception) {}
      }
      selectedVideoFileName = name
      selectedVideoFileSize = if (sizeBytes > 0L) {
        val mb = sizeBytes / (1024.0 * 1024.0)
        String.format(Locale.US, "%.1f MB", mb)
      } else "Unknown size"

      if (videoTitle.isBlank()) {
        videoTitle = name.substringBeforeLast(".")
      }
    }
  }

  // Launcher for YouTube OAuth connection (Official Google account chooser & read-only authorization)
  val youtubeSignInLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_CANCELED) {
      snackbarMessage = "YouTube connection cancelled."
      return@rememberLauncherForActivityResult
    }

    val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
    try {
      val account = task.getResult(ApiException::class.java)
      if (account != null) {
        tunoViewModel.setPendingGoogleAccount(account)
        tunoViewModel.connectYouTubeChannelWithAccount(context, account) { success, msg ->
          if (success) {
            snackbarMessage = "Connected YouTube Channel: ${tunoViewModel.userProfile.value?.youtubeChannelName ?: ""}"
          } else if (!msg.isNullOrBlank() && msg != "Permission required") {
            snackbarMessage = msg
          }
        }
      } else {
        snackbarMessage = "YouTube authorization was not completed."
      }
    } catch (e: ApiException) {
      android.util.Log.e("ProfileScreen", "GoogleSignIn ApiException statusCode: ${e.statusCode}, message: ${e.message}")
      val msg = when (e.statusCode) {
        12501, 16 -> "YouTube connection cancelled."
        10 -> "YouTube OAuth configuration is incorrect."
        7 -> "Network error. Please try again."
        12500 -> "YouTube connection failed: Google Sign-In failed (code 12500)"
        8 -> "YouTube connection failed: Google Play Services internal error (code 8)"
        else -> "YouTube connection failed: Google Sign-In error (code ${e.statusCode})"
      }
      snackbarMessage = msg
    } catch (e: Exception) {
      android.util.Log.e("ProfileScreen", "Unexpected exception during YouTube connection", e)
      snackbarMessage = "YouTube connection failed: ${e.localizedMessage ?: e.javaClass.simpleName}"
    }
  }

  // Recovery launcher for user consent / permissions prompt
  val recoveryLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      tunoViewModel.onConsentRecoveryGranted(context) { success, msg ->
        snackbarMessage = msg ?: if (success) "YouTube channel updated" else "YouTube authorization was not completed."
      }
    } else {
      snackbarMessage = "YouTube connection cancelled."
    }
  }

  LaunchedEffect(authRecoveryIntent) {
    authRecoveryIntent?.let { intent ->
      recoveryLauncher.launch(intent)
      tunoViewModel.clearRecoveryIntent()
    }
  }

  LaunchedEffect(actionMessage) {
    actionMessage?.let { msg ->
      snackbarMessage = msg
      tunoViewModel.clearActionMessage()
    }
  }

  val dateStr = remember(userProfile?.createdAt) {
    if (userProfile != null) {
      SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(userProfile!!.createdAt))
    } else "N/A"
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(TunoDarkBackground)
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
              Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = strings.profileTitle,
              fontSize = 22.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }

          // Language Selector quick pill on the top bar
          val currentLanguageItem = ProfileTranslations.supportedLanguages.firstOrNull { it.code.equals(currentLangCode, ignoreCase = true) }
          Surface(
            modifier = Modifier
              .clickable { showLanguageDialog = true },
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1E293B),
            border = BorderStroke(1.dp, Color(0xFF334155))
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFF64B5F6), modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = currentLanguageItem?.nativeName ?: "हिन्दी",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }
      }

      // =========================================================================
      // HEADER SECTION
      // - Large circular user avatar
      // - User Name
      // - Account ID: Automatically generated and starts with "tuno" (e.g. tuno8A4K91)
      // - Copy Account ID button
      // =========================================================================
      item {
        val accountId = userProfile?.accountId ?: "tuno8A4K91"
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current

        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2E3E)),
          elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            // Large circular user avatar
            Box(
              modifier = Modifier
                .size(86.dp)
                .clip(CircleShape)
                .border(2.dp, Brush.linearGradient(listOf(TunoRed, TunoGold)), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              if (!userProfile?.photoURL.isNullOrBlank()) {
                AsyncImage(
                  model = userProfile?.photoURL,
                  contentDescription = "Profile Photo",
                  modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape),
                  contentScale = ContentScale.Crop
                )
              } else {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.linearGradient(listOf(Color(0xFF8B1519), Color(0xFF4A0A0C)))),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(46.dp))
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // User Name
            Text(
              text = userProfile?.displayName?.ifBlank { "Creator" } ?: "Creator",
              fontSize = 22.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )

            if (!userProfile?.email.isNullOrBlank()) {
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = userProfile?.email ?: "",
                fontSize = 12.sp,
                color = TunoTextSecondary
              )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Account ID Card: Automatically generated starting with "tuno" + Copy button
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xFF14141E),
              border = BorderStroke(1.dp, Color(0xFF28283C)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.weight(1f)
                ) {
                  Box(
                    modifier = Modifier
                      .size(32.dp)
                      .clip(CircleShape)
                      .background(Color(0xFF222338)),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(Icons.Default.Badge, contentDescription = null, tint = Color(0xFF90CAF9), modifier = Modifier.size(16.dp))
                  }
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = strings.accountId,
                      fontSize = 11.sp,
                      color = TunoTextSecondary
                    )
                    Text(
                      text = accountId,
                      fontSize = 15.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      letterSpacing = 1.sp
                    )
                  }
                }

                // Copy Account ID button
                OutlinedButton(
                  onClick = {
                    clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(accountId))
                    snackbarMessage = strings.copiedToClipboard
                  },
                  shape = RoundedCornerShape(10.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                  border = BorderStroke(1.dp, Color(0xFF3B4D6B)),
                  colors = ButtonDefaults.outlinedButtonColors(containerColor = Color(0xFF1A233A))
                ) {
                  Icon(
                    Icons.Default.ContentCopy,
                    contentDescription = strings.copyId,
                    tint = Color(0xFF64B5F6),
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = strings.copyId,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF90CAF9)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Coins Display
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFF1B1808),
              border = BorderStroke(1.dp, TunoGold.copy(alpha = 0.4f))
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = TunoGold, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "${userProfile?.coins ?: 0} ${strings.coins}",
                  fontWeight = FontWeight.Bold,
                  color = TunoGold,
                  fontSize = 14.sp
                )
              }
            }
          }
        }
      }

      // =========================================================================
      // PROFILE MENU
      // Display each item as a modern card (rounded 16px) with icon:
      // 1. 📤 App Share
      // 2. 🔄 Check for Updates
      // 3. ⭐ Feedback
      // 4. ❓ Help
      // 5. ⚙️ Settings
      // 6. 🌙 Dark Mode (Toggle Switch)
      // 7. 🌐 Language Selection
      // =========================================================================
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          // 1. 📤 App Share
          ProfileMenuCard(
            icon = Icons.Default.Share,
            iconTint = Color(0xFF60A5FA),
            iconBg = Color(0xFF172554),
            title = "📤 ${strings.appShare}",
            subtitle = strings.appShareDesc,
            onClick = {
              val shareText = "Grow your YouTube channel fast with Tuno Grow! Get real subscribers, video views, and likes with daily tasks. Download now: ${AppConfig.SHARE_APP_URL} (Invite ID: ${userProfile?.accountId ?: "tuno8A4K91"})"
              val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Tuno Grow - YouTube Channel Growth")
                putExtra(Intent.EXTRA_TEXT, shareText)
              }
              context.startActivity(Intent.createChooser(intent, strings.appShare))
            }
          )

          // 2. 🔄 Check for Updates
          ProfileMenuCard(
            icon = Icons.Default.Sync,
            iconTint = Color(0xFF34D399),
            iconBg = Color(0xFF064E3B),
            title = "🔄 ${strings.checkForUpdates}",
            subtitle = strings.checkForUpdatesDesc,
            onClick = { showUpdateDialog = true }
          )

          // 3. ⭐ Feedback
          ProfileMenuCard(
            icon = Icons.Default.Star,
            iconTint = TunoGold,
            iconBg = Color(0xFF451A03),
            title = "⭐ ${strings.feedback}",
            subtitle = strings.feedbackDesc,
            onClick = { showFeedbackDialog = true }
          )

          // 4. ❓ Help
          ProfileMenuCard(
            icon = Icons.Default.Help,
            iconTint = Color(0xFF38BDF8),
            iconBg = Color(0xFF0C4A6E),
            title = "❓ ${strings.help}",
            subtitle = strings.helpDesc,
            onClick = { showHelpDialog = true }
          )

          // 5. ⚙️ Settings
          ProfileMenuCard(
            icon = Icons.Default.Settings,
            iconTint = Color(0xFFA78BFA),
            iconBg = Color(0xFF3B0764),
            title = "⚙️ ${strings.settings}",
            subtitle = strings.settingsDesc,
            onClick = { showSettingsDialog = true }
          )

          // 6. 🌙 Dark Mode (Toggle Switch)
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
            border = BorderStroke(1.dp, Color(0xFF26263A))
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E1B4B)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.DarkMode, contentDescription = null, tint = Color(0xFF818CF8), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                  Text(
                    text = "🌙 ${strings.darkMode}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                  Text(
                    text = strings.darkModeDesc,
                    fontSize = 12.sp,
                    color = TunoTextSecondary
                  )
                }
              }

              Switch(
                checked = isDarkMode,
                onCheckedChange = { enabled ->
                  ProfilePreferences.setDarkMode(enabled)
                },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = Color.White,
                  checkedTrackColor = Color(0xFF1E60D4),
                  uncheckedThumbColor = Color.Gray,
                  uncheckedTrackColor = Color(0xFF262626)
                )
              )
            }
          }

          // 7. 🌐 Language Selection
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { showLanguageDialog = true },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
            border = BorderStroke(1.dp, Color(0xFF26263A))
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF0F253E)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFF64B5F6), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                  Text(
                    text = "🌐 ${strings.language}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                  Text(
                    text = strings.languageDesc,
                    fontSize = 12.sp,
                    color = TunoTextSecondary
                  )
                }
              }

              val currentLang = ProfileTranslations.supportedLanguages.firstOrNull { it.code.equals(currentLangCode, ignoreCase = true) }
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF1E293B),
                border = BorderStroke(1.dp, Color(0xFF334155))
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = currentLang?.nativeName ?: "English",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64B5F6)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }
      }

      // 2. YouTube Channel Section
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, if (isConnected) TunoRed.copy(alpha = 0.5f) else Color(0xFF2A2A2A)),
          elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (isConnected) "Connected YouTube Channel" else "YouTube Channel",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              if (isConnected) {
                Surface(
                  color = Color(0xFF1B5E20),
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      Icons.Default.CheckCircle,
                      contentDescription = null,
                      tint = Color(0xFF81C784),
                      modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                      text = "YouTube Connected ✓",
                      color = Color(0xFF81C784),
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isConnected) {
              // Real YouTube Channel Logo
              if (!userProfile?.youtubeChannelImage.isNullOrBlank()) {
                AsyncImage(
                  model = userProfile?.youtubeChannelImage,
                  contentDescription = "YouTube Channel Logo",
                  modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape),
                  contentScale = ContentScale.Crop
                )
              } else {
                Box(
                  modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2E0808)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = TunoRed,
                    modifier = Modifier.size(44.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Channel Name
              Text(
                text = userProfile?.youtubeChannelName?.ifBlank { "YouTube Channel" } ?: "YouTube Channel",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
              )

              Spacer(modifier = Modifier.height(4.dp))

              // Channel ID
              Text(
                text = "Channel ID: ${userProfile?.youtubeChannelId ?: "N/A"}",
                fontSize = 12.sp,
                color = TunoTextSecondary,
                textAlign = TextAlign.Center
              )

              Spacer(modifier = Modifier.height(8.dp))

              val lastSync = userProfile?.formattedLastSynced ?: "Never"
              if (lastSync != "Never") {
                Text(
                  text = "Last synced: $lastSync",
                  fontSize = 11.sp,
                  color = TunoGold
                )
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Statistics Block (Subscriber count, Public video count, Total view count)
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF141414)
              ) {
                Column(
                  modifier = Modifier.padding(vertical = 12.dp, horizontal = 16.dp),
                  verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(text = "Subscribers", color = Color(0xFFB0B0B0), fontSize = 14.sp)
                    Text(
                      text = userProfile?.displaySubscriberCount ?: "0",
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      fontSize = 14.sp
                    )
                  }
                  HorizontalDivider(color = Color(0xFF262626))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(text = "Videos", color = Color(0xFFB0B0B0), fontSize = 14.sp)
                    Text(
                      text = userProfile?.displayVideoCount ?: "0",
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      fontSize = 14.sp
                    )
                  }
                  HorizontalDivider(color = Color(0xFF262626))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(text = "Views", color = Color(0xFFB0B0B0), fontSize = 14.sp)
                    Text(
                      text = userProfile?.displayViewCount ?: "0",
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      fontSize = 14.sp
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Action Buttons: [Refresh YouTube] and [Open Channel]
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                // Refresh YouTube button
                OutlinedButton(
                  onClick = {
                    tunoViewModel.refreshYouTubeChannel(context) { success, msg ->
                      snackbarMessage = msg ?: if (success) "YouTube channel updated" else "YouTube authorization was not completed."
                    }
                  },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                  border = BorderStroke(1.dp, Color(0xFF444444)),
                  enabled = !isLoading
                ) {
                  if (isLoading) {
                    CircularProgressIndicator(
                      color = TunoRed,
                      modifier = Modifier.size(16.dp),
                      strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Refreshing...", fontSize = 13.sp)
                  } else {
                    Icon(
                      imageVector = Icons.Default.Refresh,
                      contentDescription = null,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Refresh YouTube", fontSize = 13.sp)
                  }
                }

                // Open Channel button
                Button(
                  onClick = {
                    val channelId = userProfile?.youtubeChannelId
                    val url = if (!channelId.isNullOrEmpty()) {
                      "https://www.youtube.com/channel/$channelId"
                    } else {
                      "https://www.youtube.com"
                    }
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                  },
                  modifier = Modifier.weight(1f),
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
                ) {
                  Icon(
                    imageVector = Icons.Default.OpenInNew,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = "Open Channel", fontSize = 13.sp)
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                TextButton(
                  onClick = { showReplaceConfirmDialog = true }
                ) {
                  Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.LightGray)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Switch Account", fontSize = 12.sp, color = Color.LightGray)
                }

                TextButton(
                  onClick = { showDisconnectDialog = true }
                ) {
                  Icon(Icons.Default.LinkOff, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFFEF5350))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Disconnect", fontSize = 12.sp, color = Color(0xFFEF5350))
                }
              }
            } else {
              // Not connected yet: show prompt and "Connect YouTube" button
              Icon(
                imageVector = Icons.Default.PlayCircle,
                contentDescription = null,
                tint = TunoRed,
                modifier = Modifier.size(54.dp)
              )

              Spacer(modifier = Modifier.height(12.dp))

              Text(
                text = "Connect YouTube Channel",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = "Connect your official YouTube channel to participate in Tuno Grow subscriber tasks, track real statistics, and grow your channel.",
                fontSize = 13.sp,
                color = TunoTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
              )

              Spacer(modifier = Modifier.height(18.dp))

              // The required "Connect YouTube" button
              Button(
                onClick = {
                  val client = GoogleAuthHelper.getYouTubeSignInClient(context)
                  client.signOut().addOnCompleteListener {
                    youtubeSignInLauncher.launch(client.signInIntent)
                  }
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TunoRed),
                enabled = !isLoading
              ) {
                if (isLoading) {
                  CircularProgressIndicator(
                    color = Color.White,
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Connecting...", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                } else {
                  Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Connect YouTube",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }

              if (noYouTubeChannelFound) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFF2E1700),
                  border = BorderStroke(1.dp, Color(0xFFFF9800))
                ) {
                  Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF9800), modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                      text = "No YouTube channel was found for this Google account.",
                      color = Color(0xFFFFCC80),
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Medium
                    )
                  }
                }
              }

              if (configError != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFF2E0808),
                  border = BorderStroke(1.dp, Color(0xFFE53935))
                ) {
                  Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFE53935), modifier = Modifier.size(20.dp))
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text = "Credential / Project Configuration Error",
                        color = Color(0xFFFFCDD2),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                      )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                      text = configError?.first ?: "",
                      color = Color(0xFFFFEBEE),
                      fontSize = 12.sp,
                      lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                      onClick = {
                        val signInClient = GoogleAuthHelper.getYouTubeSignInClient(context)
                        youtubeSignInLauncher.launch(signInClient.signInIntent)
                      },
                      modifier = Modifier.fillMaxWidth(),
                      shape = RoundedCornerShape(8.dp),
                      colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                    ) {
                      Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text("Retry Connect YouTube", fontSize = 12.sp)
                    }
                  }
                }
              }
            }
          }
        }
      }

      // 3. Upload YouTube Video Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, if (uploadState.isUploading) TunoRed.copy(alpha = 0.5f) else Color(0xFF2E2E2E))
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            // Card Title Header
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.linearGradient(listOf(TunoRed, Color(0xFF900C24)))),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    Icons.Default.CloudUpload,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = "Upload YouTube Video",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                  Text(
                    text = "Publish directly to your YouTube channel",
                    fontSize = 11.sp,
                    color = TunoTextSecondary
                  )
                }
              }
              if (isConnected) {
                Surface(
                  color = Color(0xFF1B5E20),
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Text(
                    text = "Ready ✓",
                    color = Color(0xFF81C784),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!isConnected) {
              // Warning when channel not connected
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF261C14),
                border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f))
              ) {
                Column(modifier = Modifier.padding(14.dp)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      Icons.Default.Info,
                      contentDescription = null,
                      tint = Color(0xFFF59E0B),
                      modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "YouTube Channel Required",
                      color = Color(0xFFFDE68A),
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Bold
                    )
                  }
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = "Please connect your YouTube channel above to upload videos directly from Tuno Grow.",
                    color = Color(0xFFFEF3C7),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                  )
                  Spacer(modifier = Modifier.height(10.dp))
                  Button(
                    onClick = {
                      val signInClient = GoogleAuthHelper.getYouTubeSignInClient(context)
                      youtubeSignInLauncher.launch(signInClient.signInIntent)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
                  ) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Connect YouTube Channel", fontSize = 12.sp, color = Color.White)
                  }
                }
              }
            } else {
              // 1. Channel Target Indicator
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF1E1E1E)
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    Icons.Default.PlayCircle,
                    contentDescription = null,
                    tint = TunoRed,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Uploading to: ",
                    fontSize = 12.sp,
                    color = TunoTextSecondary
                  )
                  Text(
                    text = userProfile?.youtubeChannelName?.ifBlank { "Connected Channel" } ?: "Connected Channel",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              // 1. Select Video Button & 2. Selected Video Filename
              if (selectedVideoUri == null) {
                OutlinedButton(
                  onClick = {
                    videoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                  },
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color.White
                  ),
                  border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(TunoRed, Color(0xFF00FF66))))
                ) {
                  Icon(
                    Icons.Default.VideoLibrary,
                    contentDescription = null,
                    tint = Color(0xFF00FF66),
                    modifier = Modifier.size(20.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Select Video to Upload",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "Choose any video from your device (MP4, MOV, WebM, etc.)",
                  fontSize = 11.sp,
                  color = TunoTextSecondary,
                  modifier = Modifier.padding(start = 4.dp)
                )
              } else {
                // 2. Selected Video Filename Box
                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFF1E221E),
                  border = BorderStroke(1.dp, Color(0xFF00FF66).copy(alpha = 0.4f))
                ) {
                  Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      modifier = Modifier.weight(1f)
                    ) {
                      Box(
                        modifier = Modifier
                          .size(40.dp)
                          .clip(RoundedCornerShape(8.dp))
                          .background(Color(0xFF263326)),
                        contentAlignment = Alignment.Center
                      ) {
                        Icon(
                          Icons.Default.PlayCircle,
                          contentDescription = null,
                          tint = Color(0xFF00FF66),
                          modifier = Modifier.size(24.dp)
                        )
                      }
                      Spacer(modifier = Modifier.width(10.dp))
                      Column {
                        Text(
                          text = selectedVideoFileName.ifBlank { "video.mp4" },
                          fontSize = 13.sp,
                          fontWeight = FontWeight.Bold,
                          color = Color.White,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis
                        )
                        Text(
                          text = "Size: $selectedVideoFileSize",
                          fontSize = 11.sp,
                          color = TunoGold
                        )
                      }
                    }
                    TextButton(
                      onClick = {
                        if (!uploadState.isUploading) {
                          videoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                          )
                        }
                      },
                      enabled = !uploadState.isUploading
                    ) {
                      Text(
                        text = "Change",
                        fontSize = 12.sp,
                        color = Color(0xFF00FF66),
                        fontWeight = FontWeight.Bold
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 3. Video Preview if supported
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF121212))
                    .border(1.dp, Color(0xFF2E2E2E), RoundedCornerShape(12.dp)),
                  contentAlignment = Alignment.Center
                ) {
                  val bmp = videoThumbnail
                  if (bmp != null) {
                    Image(
                      bitmap = bmp.asImageBitmap(),
                      contentDescription = "Video Preview",
                      modifier = Modifier.fillMaxSize(),
                      contentScale = ContentScale.Crop
                    )
                    Box(
                      modifier = Modifier
                        .fillMaxSize()
                        .background(
                          Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                          )
                        )
                    )
                    // Centered Play Overlay
                    Box(
                      modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "Play Preview",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                      )
                    }
                    // Video duration badge
                    if (videoDurationMs != null && videoDurationMs!! > 0) {
                      val totalSec = videoDurationMs!! / 1000
                      val min = totalSec / 60
                      val sec = totalSec % 60
                      Surface(
                        modifier = Modifier
                          .align(Alignment.BottomEnd)
                          .padding(8.dp),
                        color = Color.Black.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(4.dp)
                      ) {
                        Text(
                          text = String.format(Locale.US, "%d:%02d", min, sec),
                          color = Color.White,
                          fontSize = 11.sp,
                          fontWeight = FontWeight.Bold,
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                  } else {
                    // Stylized Preview Placeholder
                    Column(
                      horizontalAlignment = Alignment.CenterHorizontally,
                      verticalArrangement = Arrangement.Center
                    ) {
                      Icon(
                        Icons.Default.Movie,
                        contentDescription = null,
                        tint = TunoRed,
                        modifier = Modifier.size(36.dp)
                      )
                      Spacer(modifier = Modifier.height(6.dp))
                      Text(
                        text = "Video Preview Ready",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                      )
                      Text(
                        text = selectedVideoFileName.ifBlank { "Selected file" },
                        color = TunoTextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                      )
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              // 4. Title Input
              OutlinedTextField(
                value = videoTitle,
                onValueChange = {
                  if (it.length <= 100) videoTitle = it
                  if (it.isNotBlank()) titleError = null
                },
                label = { Text("Video Title *") },
                placeholder = { Text("Give your video an engaging title") },
                singleLine = true,
                isError = titleError != null,
                supportingText = {
                  if (titleError != null) {
                    Text(text = titleError!!, color = Color(0xFFEF5350), fontSize = 11.sp)
                  }
                },
                enabled = !uploadState.isUploading,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = TunoRed,
                  unfocusedBorderColor = Color(0xFF3E3E3E),
                  focusedLabelColor = TunoRed,
                  cursorColor = TunoRed,
                  errorBorderColor = Color(0xFFEF5350)
                ),
                trailingIcon = {
                  Text(
                    text = "${videoTitle.length}/100",
                    fontSize = 11.sp,
                    color = TunoTextSecondary,
                    modifier = Modifier.padding(end = 8.dp)
                  )
                }
              )

              Spacer(modifier = Modifier.height(6.dp))

              // 5. Description Multiline Input
              OutlinedTextField(
                value = videoDescription,
                onValueChange = {
                  if (it.length <= 5000) videoDescription = it
                  if (it.isNotBlank()) descriptionError = null
                },
                label = { Text("Description *") },
                placeholder = { Text("Tell viewers what your video is about...") },
                minLines = 3,
                maxLines = 6,
                isError = descriptionError != null,
                supportingText = {
                  if (descriptionError != null) {
                    Text(text = descriptionError!!, color = Color(0xFFEF5350), fontSize = 11.sp)
                  }
                },
                enabled = !uploadState.isUploading,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = TunoRed,
                  unfocusedBorderColor = Color(0xFF3E3E3E),
                  focusedLabelColor = TunoRed,
                  cursorColor = TunoRed,
                  errorBorderColor = Color(0xFFEF5350)
                )
              )

              Spacer(modifier = Modifier.height(10.dp))

              // 5. Tags Input
              OutlinedTextField(
                value = videoTags,
                onValueChange = { videoTags = it },
                label = { Text("Tags") },
                placeholder = { Text("gaming, tutorial, review (comma separated)") },
                singleLine = true,
                enabled = !uploadState.isUploading,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = TunoRed,
                  unfocusedBorderColor = Color(0xFF3E3E3E),
                  focusedLabelColor = TunoRed,
                  cursorColor = TunoRed
                )
              )

              Spacer(modifier = Modifier.height(14.dp))

              // 6. Visibility Selector
              Text(
                text = "Visibility",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                listOf(
                  Triple("public", "Public", Icons.Default.Public),
                  Triple("unlisted", "Unlisted", Icons.Default.Link),
                  Triple("private", "Private", Icons.Default.Lock)
                ).forEach { (value, label, icon) ->
                  val isSelected = videoVisibility == value
                  Surface(
                    onClick = { if (!uploadState.isUploading) videoVisibility = value },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) Color(0xFF2E0808) else Color(0xFF1E1E1E),
                    border = BorderStroke(
                      width = 1.dp,
                      color = if (isSelected) TunoRed else Color(0xFF333333)
                    )
                  ) {
                    Row(
                      modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                      horizontalArrangement = Arrangement.Center,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isSelected) TunoRed else TunoTextSecondary,
                        modifier = Modifier.size(15.dp)
                      )
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else TunoTextSecondary
                      )
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(18.dp))

              // 7. Upload Progress Bar (when uploading)
              if (uploadState.isUploading) {
                Column(modifier = Modifier.fillMaxWidth()) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = uploadState.statusMessage ?: "Uploading...",
                      fontSize = 12.sp,
                      color = Color(0xFF00FF66),
                      fontWeight = FontWeight.Medium
                    )
                    Text(
                      text = "${(uploadState.progress * 100).toInt()}%",
                      fontSize = 12.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color.White
                    )
                  }
                  Spacer(modifier = Modifier.height(6.dp))
                  LinearProgressIndicator(
                    progress = { uploadState.progress },
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(6.dp)
                      .clip(RoundedCornerShape(3.dp)),
                    color = TunoRed,
                    trackColor = Color(0xFF333333)
                  )
                  Spacer(modifier = Modifier.height(12.dp))
                }
              }

              // 8. Success Banner (when finished)
              if (!uploadState.isUploading && uploadState.uploadedVideoId != null) {
                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFF142918),
                  border = BorderStroke(1.dp, Color(0xFF00FF66).copy(alpha = 0.6f))
                ) {
                  Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF00FF66),
                        modifier = Modifier.size(20.dp)
                      )
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text = "Video Uploaded Successfully!",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                      )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                      text = "Video ID: ${uploadState.uploadedVideoId}",
                      fontSize = 12.sp,
                      color = TunoGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                      Button(
                        onClick = {
                          try {
                            val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uploadState.uploadedVideoUrl ?: "https://www.youtube.com/watch?v=${uploadState.uploadedVideoId}"))
                            context.startActivity(ytIntent)
                          } catch (_: Exception) {}
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
                      ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open on YouTube", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                      }
                      OutlinedButton(
                        onClick = {
                          selectedVideoUri = null
                          selectedVideoFileName = ""
                          selectedVideoFileSize = ""
                          videoTitle = ""
                          videoDescription = ""
                          videoTags = ""
                          tunoViewModel.resetUploadState()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFF444444)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                      ) {
                        Text("Upload Another", fontSize = 12.sp)
                      }
                    }
                  }
                }
                Spacer(modifier = Modifier.height(12.dp))
              }

              // 9. Error Banner
              if (!uploadState.isUploading && uploadState.errorMessage != null) {
                Surface(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFF2B0E10),
                  border = BorderStroke(1.dp, Color(0xFFE53935).copy(alpha = 0.6f))
                ) {
                  Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(
                        Icons.Default.Error,
                        contentDescription = null,
                        tint = Color(0xFFE53935),
                        modifier = Modifier.size(18.dp)
                      )
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text = "Upload Error",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFCDD2)
                      )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = uploadState.errorMessage ?: "Upload failed",
                      fontSize = 12.sp,
                      color = Color(0xFFFFEBEE),
                      lineHeight = 16.sp
                    )
                    if (uploadState.requiresUploadPermission) {
                      Spacer(modifier = Modifier.height(10.dp))
                      Button(
                        onClick = {
                          val signInClient = GoogleAuthHelper.getYouTubeSignInClient(context)
                          youtubeSignInLauncher.launch(signInClient.signInIntent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                      ) {
                        Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Grant YouTube Upload Permission", fontSize = 12.sp)
                      }
                    }
                  }
                }
                Spacer(modifier = Modifier.height(12.dp))
              }

              // 8. Main Upload Button
              Button(
                onClick = {
                  if (uploadState.isUploading) return@Button

                  if (!isConnected) {
                    snackbarMessage = "Please connect your YouTube channel first."
                    return@Button
                  }

                  val uri = selectedVideoUri
                  if (uri == null) {
                    snackbarMessage = "Please select a video file to upload."
                    return@Button
                  }

                  var hasError = false
                  if (videoTitle.isBlank()) {
                    titleError = "Please enter a video title."
                    hasError = true
                  }
                  if (videoDescription.isBlank()) {
                    descriptionError = "Please enter a video description."
                    hasError = true
                  }

                  if (hasError) return@Button

                  tunoViewModel.uploadVideo(
                    context = context,
                    videoUri = uri,
                    title = videoTitle,
                    description = videoDescription,
                    tagsString = videoTags,
                    visibility = videoVisibility
                  )
                },
                enabled = !uploadState.isUploading,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = TunoRed,
                  disabledContainerColor = Color(0xFF331518)
                )
              ) {
                if (uploadState.isUploading) {
                  CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Uploading (${(uploadState.progress * 100).toInt()}%)...",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                } else {
                  Icon(
                    Icons.Default.CloudUpload,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (selectedVideoUri == null) "Select Video First" else "Upload Video to YouTube",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                  )
                }
              }
            }
          }
        }
      }

      // =========================================================================
      // 4. Saved Drafts & Scheduled Uploads Section (Requirement 6)
      // =========================================================================
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, if (draftVideos.any { it.status == "scheduled" }) TunoGold.copy(alpha = 0.5f) else Color(0xFF2E2E2E))
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF2E1F08)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.SaveAs,
                    contentDescription = null,
                    tint = TunoGold,
                    modifier = Modifier.size(20.dp)
                  )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = "Saved Drafts",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                  Text(
                    text = "Scheduled Video Queue",
                    fontSize = 11.sp,
                    color = TunoTextSecondary
                  )
                }
              }

              Surface(
                color = if (draftVideos.isNotEmpty()) Color(0xFF2E1F08) else Color(0xFF222222),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = "${draftVideos.size} Drafts",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (draftVideos.isNotEmpty()) TunoGold else Color.Gray,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (draftVideos.isEmpty()) {
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF141414),
                border = BorderStroke(1.dp, Color(0xFF2A2A2A))
              ) {
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Icon(
                    imageVector = Icons.Default.CloudQueue,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(36.dp)
                  )
                  Spacer(modifier = Modifier.height(8.dp))
                  Text(
                    text = "No drafts saved yet",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Use 'Save Draft' on the Home Upload card to schedule future automated uploads.",
                    fontSize = 12.sp,
                    color = TunoTextSecondary,
                    textAlign = TextAlign.Center
                  )
                }
              }
            } else {
              Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                draftVideos.forEach { draft ->
                  ProfileDraftCard(
                    draft = draft,
                    onEdit = { draftToEdit = draft },
                    onCancel = { draftToCancel = draft },
                    onUploadNow = {
                      tunoViewModel.uploadDraftNow(context, draft.draftId) { _, _ -> }
                    },
                    onDelete = {
                      tunoViewModel.deleteDraftVideo(context, draft.draftId, draft.videoFileReference) { }
                    },
                    onWatch = {
                      val url = "https://www.youtube.com/watch?v=${draft.youtubeVideoId}"
                      context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    },
                    onRetry = {
                      tunoViewModel.uploadDraftNow(context, draft.draftId) { _, _ -> }
                    }
                  )
                }
              }
            }
          }
        }
      }

      // 5. Account Details Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Account Information",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
            Spacer(modifier = Modifier.height(12.dp))
            ProfileDetailItem("User ID", userProfile?.uid?.take(12)?.plus("...") ?: "N/A")
            Spacer(modifier = Modifier.height(8.dp))
            ProfileDetailItem("Member Since", dateStr)
            Spacer(modifier = Modifier.height(8.dp))
            ProfileDetailItem("Total Earned", "${userProfile?.totalEarned ?: 0} coins")
            Spacer(modifier = Modifier.height(8.dp))
            ProfileDetailItem("Total Spent", "${userProfile?.totalSpent ?: 0} coins")
          }
        }
      }

      // 4. Admin Portal Entry (if admin)
      if (userProfile?.isAdmin == true) {
        item {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable(onClick = onOpenAdmin),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1308)),
            border = BorderStroke(1.dp, TunoGold.copy(alpha = 0.5f))
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = TunoGold, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text("Admin Portal", fontWeight = FontWeight.Bold, color = TunoGold, fontSize = 16.sp)
                  Text("Manage users, tasks, and reward settings", fontSize = 12.sp, color = TunoTextSecondary)
                }
              }
              Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TunoGold)
            }
          }
        }
      }

      // 5. API Settings Card (Jarvis API & Chat AI API)
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              com.tunogrow.jarvis.AppActionRegistry.openApiSettings()
            },
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF333344))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(TunoRed.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Key, contentDescription = null, tint = TunoRed, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text("API Settings", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                Text("Configure custom Jarvis API & Chat AI API keys", fontSize = 12.sp, color = TunoTextSecondary)
              }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
          }
        }
      }

      // 6. Sign Out Button
      item {
        Button(
          onClick = {
            authViewModel.logout()
            tunoViewModel.refreshForUser()
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF200B0E),
            contentColor = TunoRed
          ),
          border = BorderStroke(1.dp, TunoRed.copy(alpha = 0.5f))
        ) {
          Icon(Icons.Default.ExitToApp, contentDescription = null, tint = TunoRed)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Sign Out", fontWeight = FontWeight.Bold, color = TunoRed)
        }
        Spacer(modifier = Modifier.height(24.dp))
        // Official Tuno Grow App Branding
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          TunoGrowLogo(
            size = 64.dp,
            shape = RoundedCornerShape(16.dp),
            contentDescription = "Tuno Grow Official Logo",
            modifier = Modifier.clickable { showSplashIntro = true }
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Tuno Grow v1.0",
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = TunoTextSecondary
          )
          Spacer(modifier = Modifier.height(4.dp))
          TextButton(onClick = { showSplashIntro = true }) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TunoRed, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Watch Splash Intro Animation", color = TunoRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }

    if (showSplashIntro) {
      Dialog(
        onDismissRequest = { showSplashIntro = false },
        properties = DialogProperties(
          usePlatformDefaultWidth = false,
          decorFitsSystemWindows = false
        )
      ) {
        SplashScreen(
          onAnimationFinished = {
            showSplashIntro = false
          }
        )
      }
    }

    val showApiSettings by com.tunogrow.jarvis.AppActionRegistry.showApiSettingsDialog.collectAsStateWithLifecycle()
    if (showApiSettings) {
      com.tunogrow.ui.components.ApiSettingsDialog(
        onDismiss = { com.tunogrow.jarvis.AppActionRegistry.showApiSettingsDialog.value = false }
      )
    }

    // Confirmation dialog: Prevent accidentally replacing an already-connected channel without confirmation (Requirement 8)
    if (showReplaceConfirmDialog) {
      AlertDialog(
        onDismissRequest = { showReplaceConfirmDialog = false },
        title = {
          Text(
            text = "Replace Connected YouTube Channel?",
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        },
        text = {
          Text(
            text = "You currently have '${userProfile?.youtubeChannelName ?: "your YouTube channel"}' connected to this Tuno Grow account. Are you sure you want to connect a different YouTube channel?",
            color = Color.LightGray
          )
        },
        confirmButton = {
          Button(
            onClick = {
              showReplaceConfirmDialog = false
              val client = GoogleAuthHelper.getYouTubeSignInClient(context)
              client.signOut().addOnCompleteListener {
                youtubeSignInLauncher.launch(client.signInIntent)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
          ) {
            Text("Replace", fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(onClick = { showReplaceConfirmDialog = false }) {
            Text("Cancel", color = Color.White)
          }
        },
        containerColor = TunoDarkSurface
      )
    }

    // Confirmation dialog: Disconnect YouTube Channel
    if (showDisconnectDialog) {
      AlertDialog(
        onDismissRequest = { showDisconnectDialog = false },
        title = {
          Text(
            text = "Disconnect YouTube Channel?",
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        },
        text = {
          Text(
            text = "Are you sure you want to disconnect '${userProfile?.youtubeChannelName ?: "your YouTube channel"}' from Tuno Grow?",
            color = Color.LightGray
          )
        },
        confirmButton = {
          Button(
            onClick = {
              showDisconnectDialog = false
              tunoViewModel.disconnectYouTubeChannel(context) {
                snackbarMessage = "YouTube channel disconnected"
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
          ) {
            Text("Disconnect", fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(onClick = { showDisconnectDialog = false }) {
            Text("Cancel", color = Color.White)
          }
        },
        containerColor = TunoDarkSurface
      )
    }

    // Dialog: Edit Scheduled Draft
    draftToEdit?.let { draft ->
      EditDraftDialog(
        draft = draft,
        onDismiss = { draftToEdit = null },
        onSave = { newTitle, newDesc, newTags, newPrivacy, newDelayMin ->
          tunoViewModel.updateDraftVideo(
            context = context,
            draftId = draft.draftId,
            title = newTitle,
            description = newDesc,
            tags = newTags,
            privacyStatus = newPrivacy,
            newDelayMinutes = newDelayMin
          ) { success, _ ->
            if (success) {
              draftToEdit = null
            }
          }
        }
      )
    }

    // Dialog: Cancel Scheduled Draft
    draftToCancel?.let { draft ->
      CancelDraftDialog(
        onDismiss = { draftToCancel = null },
        onConfirm = {
          val id = draft.draftId
          draftToCancel = null
          tunoViewModel.cancelDraftVideo(context, id) { }
        }
      )
    }

    // =========================================================================
    // PROFILE DIALOGS (Feedback, Updates, Language, Help/FAQ, Settings, Info)
    // =========================================================================
    if (showFeedbackDialog) {
      FeedbackDialog(
        strings = strings,
        onDismiss = { showFeedbackDialog = false },
        onSubmitted = { msg ->
          snackbarMessage = msg
        }
      )
    }

    if (showUpdateDialog) {
      CheckUpdatesDialog(
        strings = strings,
        onDismiss = { showUpdateDialog = false }
      )
    }

    if (showLanguageDialog) {
      LanguagePickerDialog(
        currentLangCode = currentLangCode,
        strings = strings,
        onDismiss = { showLanguageDialog = false },
        onLanguageSelected = { newCode ->
          ProfilePreferences.setLanguage(newCode)
          snackbarMessage = "Language updated"
        }
      )
    }

    if (showHelpDialog) {
      HelpSupportDialog(
        strings = strings,
        onDismiss = { showHelpDialog = false }
      )
    }

    if (showSettingsDialog) {
      SettingsDialog(
        strings = strings,
        onDismiss = { showSettingsDialog = false },
        onOpenPrivacyPolicy = {
          infoDialogData = Pair(
            strings.privacyPolicy,
            "Tuno Grow is dedicated to respecting and protecting the privacy of content creators. We only collect essential information required to provide YouTube growth and community engagement features. Your account details, including Account ID and YouTube public identifiers, are encrypted in transit and at rest. We never ask for or store your Google/YouTube account passwords. All third-party interactions are authorized via official Google Identity and OAuth2 protocols in compliance with Google Play Developer Policies. You may request deletion of your account and personal data at any time via ${AppConfig.SUPPORT_EMAIL}."
          )
        },
        onOpenTerms = {
          infoDialogData = Pair(
            strings.termsConditions,
            "By using Tuno Grow, you agree to comply with our Community Guidelines and YouTube Terms of Service. Tuno Grow facilitates genuine community discovery and collaboration among real creators. Automated bot interactions, fraudulent coin acquisition, and misuse of system resources are strictly prohibited and will result in account suspension. Coins acquired within the app represent promotional engagement tokens and hold no real-world monetary redemption value outside the platform."
          )
        },
        onOpenAbout = {
          infoDialogData = Pair(
            strings.aboutApp,
            "Tuno Grow is the premier growth companion for YouTube creators and digital storytellers. Designed to empower channels through community engagement, Tuno Grow offers authentic subscriber tasks, video discovery, watch analytics, and campaign scheduling. Built with modern Android architecture and Jetpack Compose for peak performance, smooth animations, and top-tier security."
          )
        },
        onCacheCleared = {
          snackbarMessage = strings.cacheClearedMsg
        }
      )
    }

    infoDialogData?.let { (title, content) ->
      InfoContentDialog(
        title = title,
        content = content,
        onDismiss = { infoDialogData = null }
      )
    }

    if (snackbarMessage != null) {
      Snackbar(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .padding(16.dp),
        action = {
          TextButton(onClick = { snackbarMessage = null }) {
            Text("OK", color = TunoRed)
          }
        }
      ) {
        Text(snackbarMessage ?: "")
      }
    }
  }
}

/**
 * Modern Card representing each item in the Profile Menu (rounded 16px).
 */
@Composable
fun ProfileMenuCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconTint: Color,
  iconBg: Color,
  title: String,
  subtitle: String,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
    border = BorderStroke(1.dp, Color(0xFF26263A))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(iconBg),
          contentAlignment = Alignment.Center
        ) {
          Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column {
          Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Text(
            text = subtitle,
            fontSize = 12.sp,
            color = TunoTextSecondary
          )
        }
      }

      Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
    }
  }
}

/**
 * Modern Card representing a saved draft / scheduled upload inside the Profile screen.
 */
@Composable
fun ProfileDraftCard(
  draft: DraftVideoModel,
  onEdit: () -> Unit,
  onCancel: () -> Unit,
  onUploadNow: () -> Unit,
  onDelete: () -> Unit,
  onWatch: () -> Unit,
  onRetry: () -> Unit
) {
  var remainingSeconds by remember(draft.scheduledUploadAt, draft.status) {
    val diff = (draft.scheduledUploadAt - System.currentTimeMillis()) / 1000L
    mutableStateOf(maxOf(0L, diff))
  }

  val isScheduled = draft.status == "scheduled"

  LaunchedEffect(draft.draftId, draft.scheduledUploadAt, isScheduled) {
    while (isActive && isScheduled && draft.scheduledUploadAt > 0L) {
      val diff = (draft.scheduledUploadAt - System.currentTimeMillis()) / 1000L
      val sec = maxOf(0L, diff)
      remainingSeconds = sec
      if (sec <= 0L) break
      delay(1000L)
    }
  }

  val scheduledTimeFormatted = remember(draft.scheduledUploadAt) {
    val date = Date(draft.scheduledUploadAt)
    val sdfTime = SimpleDateFormat("h:mm a", Locale.getDefault())
    val sdfDate = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
    val nowCal = Calendar.getInstance()
    val targetCal = Calendar.getInstance().apply { timeInMillis = draft.scheduledUploadAt }

    if (nowCal.get(Calendar.DAY_OF_YEAR) == targetCal.get(Calendar.DAY_OF_YEAR) &&
      nowCal.get(Calendar.YEAR) == targetCal.get(Calendar.YEAR)
    ) {
      "Today, ${sdfTime.format(date)}"
    } else {
      sdfDate.format(date)
    }
  }

  val countdownText = remember(remainingSeconds) {
    val totalMin = remainingSeconds / 60
    if (totalMin > 0) {
      "Uploads in $totalMin minutes"
    } else if (remainingSeconds > 0) {
      "Uploads in $remainingSeconds seconds"
    } else {
      "Upload time reached"
    }
  }

  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    color = Color(0xFF141414),
    border = BorderStroke(
      1.dp,
      when (draft.status) {
        "scheduled" -> TunoGold.copy(alpha = 0.5f)
        "uploading" -> Color(0xFF2196F3)
        "uploaded" -> Color(0xFF4CAF50).copy(alpha = 0.5f)
        "failed" -> TunoRed.copy(alpha = 0.5f)
        else -> Color(0xFF2A2A2A)
      }
    )
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Thumbnail placeholder
          Box(
            modifier = Modifier
              .size(50.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF222222)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Videocam,
              contentDescription = null,
              tint = if (isScheduled) TunoGold else TunoRed,
              modifier = Modifier.size(26.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = draft.title.ifBlank { "Untitled Draft" },
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "Scheduled: $scheduledTimeFormatted",
              fontSize = 12.sp,
              color = Color(0xFFCCCCCC)
            )
            if (isScheduled) {
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = countdownText,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TunoGold
              )
            }
          }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Status Pill
        when (draft.status) {
          "scheduled" -> {
            Surface(
              color = Color(0xFF332005),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "SCHEDULED",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TunoGold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }
          "uploading" -> {
            Surface(
              color = Color(0xFF0D253A),
              shape = RoundedCornerShape(6.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                CircularProgressIndicator(
                  color = Color(0xFF64B5F6),
                  strokeWidth = 1.5.dp,
                  modifier = Modifier.size(10.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "UPLOADING",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF64B5F6)
                )
              }
            }
          }
          "uploaded" -> {
            Surface(
              color = Color(0xFF1B5E20),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "UPLOADED",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF81C784),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }
          "failed" -> {
            Surface(
              color = Color(0xFF33090C),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "FAILED",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TunoRed,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }
          else -> {
            Surface(
              color = Color(0xFF222222),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = draft.status.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }
        }
      }

      if (draft.status == "failed" || !draft.errorMessage.isNullOrBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = draft.errorMessage ?: "Upload failed. Please retry.",
          fontSize = 11.sp,
          color = TunoRed
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Action Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        if (draft.status == "scheduled") {
          // Edit Button
          OutlinedButton(
            onClick = onEdit,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, Color(0xFF444444))
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("Edit", fontSize = 11.sp, color = Color.White)
          }

          // Cancel Upload Button
          OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, Color(0xFF444444))
          ) {
            Icon(Icons.Default.Cancel, contentDescription = null, tint = TunoTextSecondary, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("Cancel", fontSize = 11.sp, color = TunoTextSecondary)
          }

          // Upload Now Button
          Button(
            onClick = onUploadNow,
            modifier = Modifier.weight(1.2f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
          ) {
            Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("Upload Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        } else if (draft.status == "uploaded") {
          // Watch on YouTube
          Button(
            onClick = onWatch,
            modifier = Modifier.weight(1.4f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20))
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Watch on YouTube", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          // Delete
          OutlinedButton(
            onClick = onDelete,
            modifier = Modifier.weight(0.8f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, Color(0xFF444444))
          ) {
            Text("Remove", fontSize = 11.sp, color = TunoTextSecondary)
          }
        } else if (draft.status == "failed") {
          // Retry
          Button(
            onClick = onRetry,
            modifier = Modifier.weight(1.2f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("Retry Upload", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          // Edit
          OutlinedButton(
            onClick = onEdit,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, Color(0xFF444444))
          ) {
            Text("Edit", fontSize = 11.sp, color = Color.White)
          }

          // Delete
          OutlinedButton(
            onClick = onDelete,
            modifier = Modifier.weight(0.8f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, Color(0xFF444444))
          ) {
            Text("Remove", fontSize = 11.sp, color = TunoTextSecondary)
          }
        } else {
          // Cancelled status
          OutlinedButton(
            onClick = onEdit,
            modifier = Modifier.weight(1.2f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, TunoGold)
          ) {
            Icon(Icons.Default.Schedule, contentDescription = null, tint = TunoGold, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text("Reschedule", fontSize = 11.sp, color = TunoGold)
          }

          OutlinedButton(
            onClick = onDelete,
            modifier = Modifier.weight(0.8f),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, Color(0xFF444444))
          ) {
            Text("Remove", fontSize = 11.sp, color = TunoTextSecondary)
          }
        }
      }
    }
  }
}

@Composable
fun ProfileDetailItem(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(text = label, color = TunoTextSecondary, fontSize = 13.sp)
    Text(text = value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
  }
}

