package com.tunogrow.ui.order

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubmitOrdersScreen(
    viewModel: TunoViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    var targetCountText by remember { mutableStateOf("10") }
    var orderType by remember { mutableStateOf("subscribe") } // subscribe or view

    val targetCount = targetCountText.toIntOrNull() ?: 10
    val costPerUnit = if (orderType == "subscribe") 10L else 2L
    val totalCost = targetCount * costPerUnit

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Submit Order", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
            )
        },
        containerColor = TunoDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (userProfile?.isBanned == true) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3E1215)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha.",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = TunoDarkSurface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Target YouTube Channel", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (userProfile?.youtubeConnected == true) {
                            "${userProfile?.youtubeChannelName} (${userProfile?.displaySubscriberCount} subs)"
                        } else {
                            "No channel connected. Please connect your channel from Home."
                        },
                        color = if (userProfile?.youtubeConnected == true) Color(0xFF00C853) else Color.Red,
                        fontSize = 13.sp
                    )
                }
            }

            // Order Type Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FilterChip(
                    selected = orderType == "subscribe",
                    onClick = { orderType = "subscribe" },
                    label = { Text("Subscribers (10 🪙/sub)") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = orderType == "view",
                    onClick = { orderType = "view" },
                    label = { Text("Views (2 🪙/view)") },
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = targetCountText,
                onValueChange = { targetCountText = it },
                label = { Text("Requested Quantity (min 5)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = TunoRed,
                    unfocusedBorderColor = Color(0xFF444444)
                )
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total Cost", color = TunoTextSecondary, fontSize = 12.sp)
                        Text("$totalCost Coins", color = TunoGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Text(
                        text = "Your Balance: ${userProfile?.coins ?: 0} 🪙",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (userProfile?.isBanned == true) {
                        Toast.makeText(context, "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha.", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    if (userProfile?.youtubeConnected != true) {
                        Toast.makeText(context, "Please connect your YouTube channel first", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val chId = userProfile?.youtubeChannelId ?: ""
                    val chName = userProfile?.youtubeChannelName ?: "Creator"
                    val chUrl = "https://www.youtube.com/channel/$chId"

                    viewModel.createFollowerRequest(
                        channelUrl = chUrl,
                        targetSubs = targetCount,
                        channelId = chId,
                        channelTitle = chName
                    ) { success, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (success) onBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = userProfile?.isBanned != true && (userProfile?.coins ?: 0L) >= totalCost,
                colors = ButtonDefaults.buttonColors(containerColor = TunoRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Place Order", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }
    }
}
