package com.tunogrow.ui.profile

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.tunogrow.config.AppConfig
import com.tunogrow.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * 1. ⭐ Feedback Dialog with 1-5 Star Rating & Success Animation
 */
@Composable
fun FeedbackDialog(
  strings: ProfileTranslations.Strings,
  onDismiss: () -> Unit,
  onSubmitted: (String) -> Unit
) {
  var rating by remember { mutableStateOf(5) }
  var feedbackText by remember { mutableStateOf("") }
  var isSubmitting by remember { mutableStateOf(false) }
  var isSuccess by remember { mutableStateOf(false) }
  val coroutineScope = rememberCoroutineScope()

  val ratingLabels = listOf("Poor", "Fair", "Good", "Very Good", "Excellent")

  Dialog(onDismissRequest = { if (!isSubmitting) onDismiss() }) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
      border = BorderStroke(1.dp, Color(0xFF2E2E3E))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        if (isSuccess) {
          // Success State with check animation
          Spacer(modifier = Modifier.height(12.dp))
          Box(
            modifier = Modifier
              .size(68.dp)
              .clip(CircleShape)
              .background(Color(0xFF16A34A).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = Color(0xFF4ADE80),
              modifier = Modifier.size(44.dp)
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = "Thank You!",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = strings.thankYouFeedback,
            fontSize = 13.sp,
            color = TunoTextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
          )

          Spacer(modifier = Modifier.height(20.dp))

          Button(
            onClick = onDismiss,
            modifier = Modifier
              .fillMaxWidth()
              .height(46.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60D4))
          ) {
            Text(strings.close, fontWeight = FontWeight.Bold)
          }
        } else {
          // Input Form State
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Star, contentDescription = null, tint = TunoGold, modifier = Modifier.size(24.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = strings.feedback,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
            IconButton(onClick = onDismiss, enabled = !isSubmitting) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = strings.rateApp,
            fontSize = 13.sp,
            color = TunoTextSecondary
          )

          Spacer(modifier = Modifier.height(14.dp))

          // 1-5 Star Interactive Rating
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            for (i in 1..5) {
              val isSelected = i <= rating
              IconButton(
                onClick = { rating = i },
                modifier = Modifier.size(42.dp)
              ) {
                Icon(
                  imageVector = if (isSelected) Icons.Default.Star else Icons.Default.StarBorder,
                  contentDescription = "$i Stars",
                  tint = if (isSelected) TunoGold else Color.Gray,
                  modifier = Modifier.size(32.dp)
                )
              }
            }
          }

          Text(
            text = ratingLabels.getOrElse(rating - 1) { "Good" },
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TunoGold
          )

          Spacer(modifier = Modifier.height(16.dp))

          OutlinedTextField(
            value = feedbackText,
            onValueChange = { feedbackText = it },
            placeholder = { Text(strings.messagePlaceholder, fontSize = 13.sp, color = Color.Gray) },
            modifier = Modifier
              .fillMaxWidth()
              .height(110.dp),
            maxLines = 4,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = Color(0xFF1E60D4),
              unfocusedBorderColor = Color(0xFF333333),
              focusedContainerColor = Color(0xFF141414),
              unfocusedContainerColor = Color(0xFF141414),
              focusedTextColor = Color.White,
              unfocusedTextColor = Color.White
            )
          )

          Spacer(modifier = Modifier.height(18.dp))

          Button(
            onClick = {
              isSubmitting = true
              coroutineScope.launch {
                try {
                  val uid = FirebaseAuth.getInstance().currentUser?.uid ?: "anonymous"
                  val data = mapOf(
                    "uid" to uid,
                    "rating" to rating,
                    "message" to feedbackText.trim(),
                    "timestamp" to System.currentTimeMillis()
                  )
                  FirebaseFirestore.getInstance().collection("feedbacks").add(data).await()
                } catch (_: Exception) {}
                isSubmitting = false
                isSuccess = true
                onSubmitted(strings.thankYouFeedback)
              }
            },
            enabled = !isSubmitting,
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60D4))
          ) {
            if (isSubmitting) {
              CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(8.dp))
              Text(strings.submitting, fontWeight = FontWeight.Bold)
            } else {
              Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(strings.submit, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
          }
        }
      }
    }
  }
}

/**
 * 2. 🔄 Check for Updates Dialog
 */
@Composable
fun CheckUpdatesDialog(
  strings: ProfileTranslations.Strings,
  onDismiss: () -> Unit
) {
  var isChecking by remember { mutableStateOf(true) }

  LaunchedEffect(Unit) {
    delay(1200L)
    isChecking = false
  }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
      border = BorderStroke(1.dp, Color(0xFF2E2E3E))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        if (isChecking) {
          CircularProgressIndicator(color = Color(0xFF1E60D4), modifier = Modifier.size(44.dp), strokeWidth = 3.dp)
          Spacer(modifier = Modifier.height(16.dp))
          Text(strings.checkingUpdate, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
          Spacer(modifier = Modifier.height(4.dp))
          Text("Connecting to Tuno Grow servers...", fontSize = 12.sp, color = TunoTextSecondary)
        } else {
          Box(
            modifier = Modifier
              .size(60.dp)
              .clip(CircleShape)
              .background(Color(0xFF16A34A).copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4ADE80), modifier = Modifier.size(36.dp))
          }

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "App is Up to Date!",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "${strings.latestVersionMsg}\nInstalled: v1.0.4 (Build 104)",
            fontSize = 13.sp,
            color = TunoTextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
          )

          Spacer(modifier = Modifier.height(20.dp))

          Button(
            onClick = onDismiss,
            modifier = Modifier
              .fillMaxWidth()
              .height(46.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60D4))
          ) {
            Text(strings.close, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

/**
 * 3. 🌐 Language Selection Modal Picker (15 Languages)
 */
@Composable
fun LanguagePickerDialog(
  currentLangCode: String,
  strings: ProfileTranslations.Strings,
  onDismiss: () -> Unit,
  onLanguageSelected: (String) -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 560.dp)
        .padding(horizontal = 8.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
      border = BorderStroke(1.dp, Color(0xFF2E2E3E))
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFF64B5F6), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.selectLanguage,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
          }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Select from 15 Indian languages. The UI updates instantly.",
          fontSize = 12.sp,
          color = TunoTextSecondary
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
          modifier = Modifier.weight(1f, fill = false),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(ProfileTranslations.supportedLanguages) { lang ->
            val isSelected = lang.code.equals(currentLangCode, ignoreCase = true)

            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onLanguageSelected(lang.code)
                  onDismiss()
                },
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(
                containerColor = if (isSelected) Color(0xFF0F253E) else Color(0xFF161616)
              ),
              border = BorderStroke(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) Color(0xFF1E60D4) else Color(0xFF262626)
              )
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = lang.nativeName,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color(0xFF64B5F6) else Color.White
                  )
                  Text(
                    text = lang.englishName,
                    fontSize = 12.sp,
                    color = TunoTextSecondary
                  )
                }

                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF1E60D4),
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222222))
        ) {
          Text(strings.close, color = Color.White)
        }
      }
    }
  }
}

/**
 * 4. ❓ Help & FAQ Section Dialog
 */
@Composable
fun HelpSupportDialog(
  strings: ProfileTranslations.Strings,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val faqs = listOf(
    Pair("How to earn coins on Tuno Grow?", "You can earn coins by completing creator tasks, watching Reels, subscribing to fellow creators, or claiming daily bonus rewards."),
    Pair("How does Order For Others work?", "Search for any YouTube user ID or YouTube Channel URL in the Order For Others screen, choose the service (Subscribe, Like, Views), select quantity and confirm."),
    Pair("Are YouTube interactions safe?", "Yes! All actions are performed by real users on the official YouTube app/website. Tuno Grow never stores passwords or performs unauthorized automated actions."),
    Pair("What is my Account ID used for?", "Your Account ID (starting with 'tuno') uniquely identifies your creator profile on Tuno Grow for coin transfers, referrals, and priority support.")
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 580.dp)
        .padding(horizontal = 8.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
      border = BorderStroke(1.dp, Color(0xFF2E2E3E))
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Help, contentDescription = null, tint = Color(0xFF42A5F5), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.help,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
          modifier = Modifier.weight(1f, fill = false),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          item {
            Text(strings.faqs, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TunoGold)
          }

          items(faqs) { (q, a) ->
            var expanded by remember { mutableStateOf(false) }

            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
              border = BorderStroke(1.dp, Color(0xFF262626))
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = q,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                  )
                  Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color.Gray
                  )
                }

                if (expanded) {
                  Spacer(modifier = Modifier.height(8.dp))
                  Text(text = a, fontSize = 12.sp, color = TunoTextSecondary, lineHeight = 16.sp)
                }
              }
            }
          }

          item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Need more help?", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }

          item {
            // Email Support Button
            Button(
              onClick = {
                try {
                  val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:${AppConfig.SUPPORT_EMAIL}")
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(AppConfig.SUPPORT_EMAIL))
                    putExtra(Intent.EXTRA_SUBJECT, "Tuno Grow Support Request")
                  }
                  context.startActivity(intent)
                } catch (_: Exception) {
                  try {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                      type = "message/rfc822"
                      putExtra(Intent.EXTRA_EMAIL, arrayOf(AppConfig.SUPPORT_EMAIL))
                      putExtra(Intent.EXTRA_SUBJECT, "Tuno Grow Support Request")
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Send Email"))
                  } catch (_: Exception) {}
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60D4))
            ) {
              Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(strings.emailSupport, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222222))
        ) {
          Text(strings.close, color = Color.White)
        }
      }
    }
  }
}

/**
 * 5. General Info / Policy Dialog (Privacy, Terms, About)
 */
@Composable
fun InfoContentDialog(
  title: String,
  content: String,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 520.dp)
        .padding(horizontal = 8.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
      border = BorderStroke(1.dp, Color(0xFF2E2E3E))
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
          item {
            Text(
              text = content,
              fontSize = 13.sp,
              color = TunoTextSecondary,
              lineHeight = 18.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60D4))
        ) {
          Text("Close", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

/**
 * 6. ⚙️ Settings Dialog with Search Settings option, Toggles, Cache clear, and Policies
 */
@Composable
fun SettingsDialog(
  strings: ProfileTranslations.Strings,
  onDismiss: () -> Unit,
  onOpenPrivacyPolicy: () -> Unit,
  onOpenTerms: () -> Unit,
  onOpenAbout: () -> Unit,
  onCacheCleared: () -> Unit
) {
  val context = LocalContext.current
  var searchQuery by remember { mutableStateOf("") }
  var notificationsEnabled by remember { mutableStateOf(ProfilePreferences.notifications.value) }
  var autoUpdateEnabled by remember { mutableStateOf(ProfilePreferences.autoUpdate.value) }
  var isClearingCache by remember { mutableStateOf(false) }
  val coroutineScope = rememberCoroutineScope()

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 600.dp)
        .padding(horizontal = 8.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
      border = BorderStroke(1.dp, Color(0xFF2E2E3E))
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Color(0xFF90CAF9), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.settings,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Settings Option
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text(strings.searchSettings, fontSize = 13.sp, color = Color.Gray) },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp)) },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(16.dp))
              }
            }
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFF1E60D4),
            unfocusedBorderColor = Color(0xFF333333),
            focusedContainerColor = Color(0xFF141414),
            unfocusedContainerColor = Color(0xFF141414),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          )
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
          modifier = Modifier.weight(1f, fill = false),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          val query = searchQuery.trim().lowercase()

          // 1. Notifications Toggle
          if (query.isEmpty() || strings.notifications.lowercase().contains(query) || "notification".contains(query)) {
            item {
              SettingToggleRow(
                icon = Icons.Default.Notifications,
                title = strings.notifications,
                subtitle = "Receive coin alerts and updates",
                checked = notificationsEnabled,
                onCheckedChange = {
                  notificationsEnabled = it
                  ProfilePreferences.setNotifications(it)
                }
              )
            }
          }

          // 2. Auto Update Toggle
          if (query.isEmpty() || strings.autoUpdate.lowercase().contains(query) || "update".contains(query)) {
            item {
              SettingToggleRow(
                icon = Icons.Default.Sync,
                title = strings.autoUpdate,
                subtitle = "Check for app updates automatically",
                checked = autoUpdateEnabled,
                onCheckedChange = {
                  autoUpdateEnabled = it
                  ProfilePreferences.setAutoUpdate(it)
                }
              )
            }
          }

          // 3. Clear Cache
          if (query.isEmpty() || strings.clearCache.lowercase().contains(query) || "cache".contains(query)) {
            item {
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable(enabled = !isClearingCache) {
                    isClearingCache = true
                    coroutineScope.launch {
                      ProfilePreferences.clearAppCache(context)
                      delay(400)
                      isClearingCache = false
                      onCacheCleared()
                    }
                  },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                border = BorderStroke(1.dp, Color(0xFF262626))
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                      modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2E1700)),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(Icons.Default.CleaningServices, contentDescription = null, tint = Color(0xFFFFB74D), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                      Text(strings.clearCache, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                      Text("Free up device storage", fontSize = 11.sp, color = TunoTextSecondary)
                    }
                  }

                  if (isClearingCache) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color(0xFFFFB74D), strokeWidth = 2.dp)
                  } else {
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                  }
                }
              }
            }
          }

          // 4. Privacy Policy
          if (query.isEmpty() || strings.privacyPolicy.lowercase().contains(query) || "privacy".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.PrivacyTip,
                title = strings.privacyPolicy,
                subtitle = "Data security & privacy guidelines",
                onClick = onOpenPrivacyPolicy
              )
            }
          }

          // 5. Terms & Conditions
          if (query.isEmpty() || strings.termsConditions.lowercase().contains(query) || "terms".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Description,
                title = strings.termsConditions,
                subtitle = "User agreement & usage terms",
                onClick = onOpenTerms
              )
            }
          }

          // 6. About App
          if (query.isEmpty() || strings.aboutApp.lowercase().contains(query) || "about".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Info,
                title = strings.aboutApp,
                subtitle = "Learn about the Tuno Grow platform",
                onClick = onOpenAbout
              )
            }
          }

          // 7. Support Email
          if (query.isEmpty() || "support".contains(query) || "email".contains(query) || "help".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Email,
                title = "Support",
                subtitle = AppConfig.SUPPORT_EMAIL,
                onClick = {
                  try {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                      data = Uri.parse("mailto:${AppConfig.SUPPORT_EMAIL}")
                      putExtra(Intent.EXTRA_EMAIL, arrayOf(AppConfig.SUPPORT_EMAIL))
                      putExtra(Intent.EXTRA_SUBJECT, "Tuno Grow Support Request")
                    }
                    context.startActivity(intent)
                  } catch (_: Exception) {
                    try {
                      val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "message/rfc822"
                        putExtra(Intent.EXTRA_EMAIL, arrayOf(AppConfig.SUPPORT_EMAIL))
                        putExtra(Intent.EXTRA_SUBJECT, "Tuno Grow Support Request")
                      }
                      context.startActivity(Intent.createChooser(sendIntent, "Send Email"))
                    } catch (_: Exception) {}
                  }
                }
              )
            }
          }

          // 8. Official Website
          if (query.isEmpty() || "official".contains(query) || "website".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Language,
                title = "Official Website",
                subtitle = AppConfig.OFFICIAL_WEBSITE_URL,
                onClick = {
                  try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.OFFICIAL_WEBSITE_URL))
                    context.startActivity(intent)
                  } catch (_: Exception) {}
                }
              )
            }
          }

          // 9. Our Website
          if (query.isEmpty() || "our".contains(query) || "website".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Public,
                title = "Our Website",
                subtitle = AppConfig.OUR_WEBSITE_URL,
                onClick = {
                  try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.OUR_WEBSITE_URL))
                    context.startActivity(intent)
                  } catch (_: Exception) {}
                }
              )
            }
          }

          // 10. Share App
          if (query.isEmpty() || "share".contains(query) || "download".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Share,
                title = "Share App",
                subtitle = AppConfig.SHARE_APP_URL,
                onClick = {
                  try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.SHARE_APP_URL))
                    context.startActivity(intent)
                  } catch (_: Exception) {}
                }
              )
            }
          }

          // 11. Telegram
          if (query.isEmpty() || "telegram".contains(query) || "channel".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Send,
                title = "Telegram",
                subtitle = AppConfig.TELEGRAM_CHANNEL_URL,
                onClick = {
                  try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.TELEGRAM_CHANNEL_URL))
                    context.startActivity(intent)
                  } catch (_: Exception) {}
                }
              )
            }
          }

          // 12. Telegram Group (New Button)
          if (query.isEmpty() || "telegram".contains(query) || "group".contains(query) || "bot".contains(query)) {
            item {
              SettingNavRow(
                icon = Icons.Default.Groups,
                title = "Telegram Group",
                subtitle = AppConfig.TELEGRAM_GROUP_URL,
                onClick = {
                  try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.TELEGRAM_GROUP_URL))
                    context.startActivity(intent)
                  } catch (_: Exception) {}
                }
              )
            }
          }

          // 7. App Version
          if (query.isEmpty() || strings.appVersion.lowercase().contains(query) || "version".contains(query)) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
                border = BorderStroke(1.dp, Color(0xFF262626))
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                      modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1B2A1E)),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF81C784), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                      Text(strings.appVersion, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                      Text("Official Production Release", fontSize = 11.sp, color = TunoTextSecondary)
                    }
                  }
                  Text("v1.0.4 (Build 104)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF81C784))
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222222))
        ) {
          Text(strings.close, color = Color.White)
        }
      }
    }
  }
}

@Composable
private fun SettingToggleRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
    border = BorderStroke(1.dp, Color(0xFF262626))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Color(0xFF162238)),
          contentAlignment = Alignment.Center
        ) {
          Icon(icon, contentDescription = null, tint = Color(0xFF64B5F6), modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Text(subtitle, fontSize = 11.sp, color = TunoTextSecondary)
        }
      }

      Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
          checkedThumbColor = Color.White,
          checkedTrackColor = Color(0xFF1E60D4),
          uncheckedThumbColor = Color.Gray,
          uncheckedTrackColor = Color(0xFF262626)
        )
      )
    }
  }
}

@Composable
private fun SettingNavRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF141414)),
    border = BorderStroke(1.dp, Color(0xFF262626))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Color(0xFF1E1E2E)),
          contentAlignment = Alignment.Center
        ) {
          Icon(icon, contentDescription = null, tint = Color(0xFFB0BEC5), modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Text(subtitle, fontSize = 11.sp, color = TunoTextSecondary)
        }
      }
      Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
    }
  }
}
