package com.tunogrow.ui.getfollower

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GetFollowerScreen(
    viewModel: TunoViewModel,
    onNavigateToSubmitOrder: () -> Unit = {},
    onNavigateToOrderForOthers: () -> Unit = {}
) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val myOrders by viewModel.myOrders.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Channel Growth", color = Color.White, fontWeight = FontWeight.Bold) },
                actions = {
                    Surface(
                        color = TunoCardSurface,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.padding(end = 16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = TunoGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${userProfile?.coins ?: 0}", color = TunoGold, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
            )
        },
        containerColor = TunoDarkBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Promote Your Channel", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Get active subscribers and viewers from real YouTube creators.", color = TunoTextSecondary, fontSize = 13.sp)
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onNavigateToSubmitOrder() },
                    colors = CardDefaults.cardColors(containerColor = TunoDarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AddCircle, contentDescription = null, tint = TunoRed, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("New Subscriber Campaign", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Boost your linked YouTube channel", color = TunoTextSecondary, fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onNavigateToSubmitOrder,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = TunoRed),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Create Order (10 🪙 / sub)", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onNavigateToOrderForOthers() },
                    colors = CardDefaults.cardColors(containerColor = TunoDarkSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.GroupAdd, contentDescription = null, tint = Color(0xFFAB47BC), modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Sponsor Another Creator", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Gift subscribers to any YouTube channel URL", color = TunoTextSecondary, fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onNavigateToOrderForOthers,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFAB47BC)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Order For Others", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Text("My Active Campaigns", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            if (myOrders.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No active campaigns right now. Create one above to grow your channel!",
                            color = TunoTextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(myOrders.size) { idx ->
                    val order = myOrders[idx]
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(order.channelName, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("${order.completedCount}/${order.requestedCount}", color = TunoGold, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { if (order.requestedCount > 0) order.completedCount.toFloat() / order.requestedCount else 0f },
                                modifier = Modifier.fillMaxWidth(),
                                color = TunoRed
                            )
                        }
                    }
                }
            }
        }
    }
}
