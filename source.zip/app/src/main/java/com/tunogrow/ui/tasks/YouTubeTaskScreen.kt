package com.tunogrow.ui.tasks

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.tunogrow.ads.UnityAdsManager
import com.tunogrow.auth.GoogleAuthHelper
import com.tunogrow.model.OrderModel
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouTubeTaskScreen(
    viewModel: TunoViewModel,
    initialTaskType: String = "subscribe",
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val activeOrders by viewModel.activeCommunityOrders.collectAsStateWithLifecycle()
    val completions by viewModel.userCompletions.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val loadingMsg by viewModel.loadingMessage.collectAsStateWithLifecycle()

    var showBanDialog by remember { mutableStateOf(false) }
    var banDialogMessage by remember { mutableStateOf("") }
    var selectedOrderForVerification by remember { mutableStateOf<OrderModel?>(null) }
    var openedOrderIds by remember { mutableStateOf(setOf<String>()) }
    var isYouTubeConnected by remember { mutableStateOf(userProfile?.youtubeConnected == true) }

    LaunchedEffect(userProfile?.youtubeConnected) {
        if (userProfile?.youtubeConnected == true) {
            isYouTubeConnected = true
        }
    }

    // Launch anti-unsubscribe check on screen load
    LaunchedEffect(Unit) {
        viewModel.checkPreviousSubscriptionsAntiUnsubscribe(context) { isBanned, msg ->
            if (isBanned || msg.isNotBlank()) {
                banDialogMessage = msg
                showBanDialog = true
            }
        }
    }

    LaunchedEffect(userProfile?.isBanned) {
        if (userProfile?.isBanned == true) {
            banDialogMessage = "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha."
            showBanDialog = true
        }
    }

    val youtubeSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(Exception::class.java)
                if (account != null) {
                    viewModel.connectYouTubeChannelWithAccount(context, account) { success, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (success) {
                            // State Reset on Successful Reconnect
                            isYouTubeConnected = true
                            // If an order was pending verification, auto verify or leave button active
                            selectedOrderForVerification?.let { pendingOrder ->
                                viewModel.verifyAndCompleteSubscription(
                                    context = context,
                                    orderId = pendingOrder.orderId,
                                    targetChannelId = pendingOrder.channelId,
                                    channelName = pendingOrder.channelName,
                                    rewardCoins = 10L,
                                    ownerUid = pendingOrder.createdByUserId
                                ) { vSuccess, vMsg ->
                                    Toast.makeText(context, vMsg, Toast.LENGTH_SHORT).show()
                                    if (vSuccess) {
                                        selectedOrderForVerification = null
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Sign in failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Ban alert dialog
    if (showBanDialog || userProfile?.isBanned == true) {
        AlertDialog(
            onDismissRequest = { /* Cannot dismiss if banned */ },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Banned",
                    tint = Color.Red,
                    modifier = Modifier.size(40.dp)
                )
            },
            title = {
                Text(
                    text = "ID Banned",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = banDialogMessage.ifBlank {
                        "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha."
                    },
                    color = TunoTextSecondary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBanDialog = false
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TunoRed)
                ) {
                    Text("OK", color = Color.White)
                }
            },
            containerColor = TunoDarkSurface
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Subscribe Tasks",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .background(TunoCardSurface, RoundedCornerShape(16.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Coins",
                            tint = TunoGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${userProfile?.coins ?: 0}",
                            color = TunoGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
            )
        },
        containerColor = TunoDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // PROMINENT WARNING NOTICE (Requirement 1)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2C0B0E)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFFF3B30), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = Color(0xFFFF3B30),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Warning: Agar user ne unsubscribe kiya, toh uski Tuno Grow ID permanently ban kar di jayegi aur 10 coins deduct kar liye jayenge.",
                        color = Color(0xFFFFD2D2),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 16.sp
                    )
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = TunoRed,
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(loadingMsg ?: "", color = TunoTextSecondary, fontSize = 12.sp)
                    }
                }
            }

            val completedTaskIds = remember(completions) {
                completions.map { it.taskId }.toSet()
            }
            val currentUid = userProfile?.uid ?: ""
            val subscribeOrders = remember(activeOrders, completedTaskIds) {
                activeOrders.filter {
                    it.orderType == "subscribe" &&
                            it.createdByUserId != currentUid &&
                            it.orderId !in completedTaskIds
                }
            }

            if (subscribeOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "All done",
                            tint = Color(0xFF00C853),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Tasks Available Right Now",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Check back soon for new creator subscribe campaigns!",
                            color = TunoTextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(subscribeOrders, key = { it.orderId }) { order ->
                        val isOpened = order.orderId in openedOrderIds

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = TunoDarkSurface),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(TunoRed),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = order.channelName.take(1).uppercase(),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 18.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = order.channelName.ifBlank { "YouTube Channel" },
                                            color = Color.White,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Subscribe to earn rewards",
                                            color = TunoTextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Surface(
                                        color = TunoCardSurface,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.MonetizationOn,
                                                contentDescription = "Reward",
                                                tint = TunoGold,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "+10",
                                                color = TunoGold,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Button 1: Open Channel in YouTube
                                if (!isOpened) {
                                    Button(
                                        onClick = {
                                            if (userProfile?.isBanned == true) {
                                                banDialogMessage = "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha."
                                                showBanDialog = true
                                                return@Button
                                            }
                                            openedOrderIds = openedOrderIds + order.orderId
                                            selectedOrderForVerification = order

                                            // Open YouTube channel URL
                                            val url = if (order.channelId.isNotBlank()) {
                                                "https://www.youtube.com/channel/${order.channelId}"
                                            } else {
                                                "https://www.youtube.com"
                                            }
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                                    setPackage("com.google.android.youtube")
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = TunoRed),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.OpenInNew,
                                            contentDescription = "Open",
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Open Channel in YouTube", fontWeight = FontWeight.SemiBold)
                                    }
                                } else {
                                    // Channel opened state
                                    OutlinedButton(
                                        onClick = { /* already opened */ },
                                        enabled = false,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            disabledContentColor = Color(0xFF00C853)
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Opened",
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Channel Opened in YouTube", fontWeight = FontWeight.SemiBold)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // VERIFY BUTTON VISIBILITY LOGIC (Requirement 1 & 2):
                                    // If connected: show active "Verify Subscription" button immediately.
                                    // If not connected: show "Connect YouTube Account" button, which when clicked and connected,
                                    // immediately restores the active "Verify Subscription" button below.
                                    if (isYouTubeConnected) {
                                        Button(
                                            onClick = {
                                                if (userProfile?.isBanned == true) {
                                                    banDialogMessage = "Aapki Tuno Grow ID ban kar di gayi hai kyunki aapne channel unsubscribe kiya tha."
                                                    showBanDialog = true
                                                    return@Button
                                                }
                                                val activity = context as? Activity
                                                val proceedVerification = {
                                                    viewModel.verifyAndCompleteSubscription(
                                                        context = context,
                                                        orderId = order.orderId,
                                                        targetChannelId = order.channelId,
                                                        channelName = order.channelName,
                                                        rewardCoins = 10L,
                                                        ownerUid = order.createdByUserId
                                                    ) { vSuccess, vMsg ->
                                                        Toast.makeText(context, vMsg, Toast.LENGTH_SHORT).show()
                                                        if (vSuccess) {
                                                            openedOrderIds = openedOrderIds - order.orderId
                                                            selectedOrderForVerification = null
                                                        }
                                                    }
                                                }

                                                if (activity != null) {
                                                    UnityAdsManager.showInterstitial(activity) {
                                                        proceedVerification()
                                                    }
                                                } else {
                                                    proceedVerification()
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "Verify",
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Verify Subscription", fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    } else {
                                        Button(
                                            onClick = {
                                                selectedOrderForVerification = order
                                                val client = GoogleAuthHelper.getYouTubeSignInClient(context)
                                                youtubeSignInLauncher.launch(client.signInIntent)
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text("Connect YouTube Account to Verify", fontWeight = FontWeight.SemiBold, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
