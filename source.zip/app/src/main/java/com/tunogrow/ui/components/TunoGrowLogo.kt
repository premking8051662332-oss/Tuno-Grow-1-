package com.tunogrow.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.tunogrow.R

/**
 * Official Tuno Grow logo component used across the application:
 * - App Splash Screen
 * - Login / Registration (Auth) Screen
 * - Home Screen header
 * - Profile Screen branding
 * - Empty / Loading / Error states
 */
@Composable
fun TunoGrowLogo(
  modifier: Modifier = Modifier,
  size: Dp = 80.dp,
  shape: Shape = RoundedCornerShape(22.dp),
  contentDescription: String = "Tuno Grow Official Logo"
) {
  Box(
    modifier = modifier
      .size(size)
      .clip(shape),
    contentAlignment = Alignment.Center
  ) {
    Image(
      painter = painterResource(id = R.drawable.img_tunogrow_logo),
      contentDescription = contentDescription,
      modifier = Modifier.size(size),
      contentScale = ContentScale.Fit
    )
  }
}
