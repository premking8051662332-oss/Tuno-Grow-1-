package com.tunogrow.ui.profile

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ProfilePreferences {
    private val _darkMode = MutableStateFlow(true)
    val darkMode: StateFlow<Boolean> = _darkMode.asStateFlow()

    private val _language = MutableStateFlow("en")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _notifications = MutableStateFlow(true)
    val notifications: StateFlow<Boolean> = _notifications.asStateFlow()

    private val _autoUpdate = MutableStateFlow(true)
    val autoUpdate: StateFlow<Boolean> = _autoUpdate.asStateFlow()

    fun init(context: Context) {
        // Initializes profile and theme preferences
    }

    fun setDarkMode(enabled: Boolean) {
        _darkMode.value = enabled
    }

    fun setLanguage(lang: String) {
        _language.value = lang
    }

    fun setNotifications(enabled: Boolean) {
        _notifications.value = enabled
    }

    fun setAutoUpdate(enabled: Boolean) {
        _autoUpdate.value = enabled
    }

    fun clearAppCache(context: Context) {
        try {
            context.cacheDir.deleteRecursively()
        } catch (_: Exception) {}
    }
}
