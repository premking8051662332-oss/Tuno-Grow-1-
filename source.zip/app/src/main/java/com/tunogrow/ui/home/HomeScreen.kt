package com.tunogrow.ui.home

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tunogrow.auth.GoogleAuthHelper
import com.tunogrow.model.CoinTransactionModel
import com.tunogrow.model.formatLastSynced
import com.tunogrow.ui.components.TunoGrowLogo
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.launch

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.config.AppConfig

@Composable
fun HomeScreen(
  viewModel: TunoViewModel,
  onNavigate: (String) -> Unit,
  onOpenProfile: () -> Unit,
  onLogout: () -> Unit = {}
) {
  val context = LocalContext.current
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val transactions by viewModel.transactions.collectAsStateWithLifecycle()
  val completions by viewModel.userCompletions.collectAsStateWithLifecycle()
  val followerRequests by viewModel.followerRequests.collectAsStateWithLifecycle()
  val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
  val loadingMessage by viewModel.loadingMessage.collectAsStateWithLifecycle()
  val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
  val configError by viewModel.configError.collectAsStateWithLifecycle()
  val noYouTubeChannelFound by viewModel.noYouTubeChannelFound.collectAsStateWithLifecycle()
  val recoveryIntent by viewModel.authRecoveryIntent.collectAsStateWithLifecycle()
  val notifications by viewModel.notifications.collectAsStateWithLifecycle()
  var showNotificationDialog by remember { mutableStateOf(false) }

  val coroutineScope = rememberCoroutineScope()
  var snackbarHostState = remember { SnackbarHostState() }

  val openExternalUrl: (String) -> Unit = { url ->
    try {
      val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
      context.startActivity(intent)
    } catch (e: Exception) {
      coroutineScope.launch {
        snackbarHostState.showSnackbar("Unable to open link: $url")
      }
    }
  }

  // Recovery launcher for user consent / permissions
  val recoveryLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      viewModel.onConsentRecoveryGranted(context) { success, msg ->
        if (success) {
          coroutineScope.launch {
            snackbarHostState.showSnackbar("YouTube channel connected successfully!")
          }
        } else if (!msg.isNullOrBlank() && msg != "Permission required") {
          coroutineScope.launch {
            snackbarHostState.showSnackbar(msg)
          }
        }
      }
    } else {
      coroutineScope.launch {
        snackbarHostState.showSnackbar("YouTube connection cancelled.")
      }
    }
  }

  // Connect YouTube Google Sign-In launcher
  val googleSignInLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_CANCELED) {
      coroutineScope.launch {
        snackbarHostState.showSnackbar("YouTube connection cancelled.")
      }
      return@rememberLauncherForActivityResult
    }

    val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
    try {
      val account = task.getResult(ApiException::class.java)
      if (account != null) {
        viewModel.setPendingGoogleAccount(account)
        viewModel.connectYouTubeChannelWithAccount(context, account) { success, msg ->
          if (success) {
            coroutineScope.launch {
              snackbarHostState.showSnackbar("YouTube connected successfully!")
            }
          } else if (!msg.isNullOrBlank() && msg != "Permission required") {
            coroutineScope.launch {
              snackbarHostState.showSnackbar(msg)
            }
          }
        }
      } else {
        coroutineScope.launch {
          snackbarHostState.showSnackbar("YouTube authorization was not completed.")
        }
      }
    } catch (e: ApiException) {
      android.util.Log.e("HomeScreen", "GoogleSignIn ApiException statusCode: ${e.statusCode}, message: ${e.message}")
      val msg = when (e.statusCode) {
        12501, 16 -> "YouTube connection cancelled."
        10 -> "YouTube OAuth configuration is incorrect."
        7 -> "Network error. Please try again."
        12500 -> "YouTube connection failed: Google Sign-In failed (code 12500)"
        8 -> "YouTube connection failed: Google Play Services internal error (code 8)"
        else -> "YouTube connection failed: Google Sign-In error (code ${e.statusCode})"
      }
      coroutineScope.launch {
        snackbarHostState.showSnackbar(msg)
      }
    } catch (e: Exception) {
      android.util.Log.e("HomeScreen", "Unexpected exception during YouTube connection", e)
      coroutineScope.launch {
        snackbarHostState.showSnackbar("YouTube connection failed: ${e.localizedMessage ?: e.javaClass.simpleName}")
      }
    }
  }

  LaunchedEffect(recoveryIntent) {
    recoveryIntent?.let { intent ->
      recoveryLauncher.launch(intent)
      viewModel.clearRecoveryIntent()
    }
  }

  LaunchedEffect(actionMessage) {
    actionMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearActionMessage()
    }
  }

  Scaffold(
    containerColor = TunoDarkBackground,
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { paddingValues ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(12.dp))
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .weight(1f)
              .clickable { onNavigate("splash_intro") }
          ) {
            TunoGrowLogo(
              size = 46.dp,
              shape = RoundedCornerShape(14.dp),
              contentDescription = "Tuno Grow Logo"
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Tuno Grow",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
              )
              Text(
                text = "Welcome, ${userProfile?.displayName?.ifBlank { "Creator" } ?: "Creator"}",
                fontSize = 13.sp,
                color = TunoTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }

          // Top Right 3 Buttons: Upload Video, Notification, Profile
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // 1. Upload Video Button
            IconButton(
              onClick = { onNavigate("upload_video") },
              modifier = Modifier.size(38.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(TunoRed.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.VideoCall,
                  contentDescription = "Upload Video",
                  tint = TunoRed,
                  modifier = Modifier.size(20.dp)
                )
              }
            }

            // 2. Notification Button
            IconButton(
              onClick = { showNotificationDialog = true },
              modifier = Modifier.size(38.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(TunoCardSurface),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Notifications,
                  contentDescription = "Notification",
                  tint = Color.White,
                  modifier = Modifier.size(20.dp)
                )
                if (notifications.isNotEmpty()) {
                  Box(
                    modifier = Modifier
                      .size(8.dp)
                      .clip(CircleShape)
                      .background(TunoRed)
                      .align(Alignment.TopEnd)
                  )
                }
              }
            }

            // 3. Profile Button
            IconButton(
              onClick = onOpenProfile,
              modifier = Modifier.size(38.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(TunoCardSurface),
                contentAlignment = Alignment.Center
              ) {
                if (!userProfile?.photoURL.isNullOrBlank()) {
                  AsyncImage(
                    model = userProfile?.photoURL,
                    contentDescription = "Profile",
                    modifier = Modifier
                      .size(38.dp)
                      .clip(CircleShape),
                    contentScale = ContentScale.Crop
                  )
                } else {
                  Icon(
                    Icons.Default.Person,
                    contentDescription = "Profile",
                    tint = TunoRed,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
            }
          }
        }
      }

      // 1. Profile Card
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenProfile() },
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, TunoRed.copy(alpha = 0.35f)),
          elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    Color(0xFF241215),
                    TunoCardSurface
                  )
                )
              )
              .padding(18.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              // User Profile Photo
              if (!userProfile?.photoURL.isNullOrBlank()) {
                AsyncImage(
                  model = userProfile?.photoURL,
                  contentDescription = "User Profile Photo",
                  modifier = Modifier
                    .size(62.dp)
                    .clip(CircleShape)
                    .border(2.dp, TunoRed, CircleShape),
                  contentScale = ContentScale.Crop
                )
              } else {
                Box(
                  modifier = Modifier
                    .size(62.dp)
                    .clip(CircleShape)
                    .background(TunoRed.copy(alpha = 0.2f))
                    .border(2.dp, TunoRed, CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = TunoRed,
                    modifier = Modifier.size(34.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column(modifier = Modifier.weight(1f)) {
                // User Name
                Text(
                  text = userProfile?.displayName?.ifBlank { "Tuno Creator" } ?: "Tuno Creator",
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                // Account ID
                Text(
                  text = "Account ID: ${userProfile?.uid?.take(16) ?: "N/A"}",
                  fontSize = 12.sp,
                  color = TunoTextSecondary,
                  fontWeight = FontWeight.Medium
                )

                // Connected YouTube info if available
                val isChannelConnected = userProfile?.youtubeConnected == true && !userProfile?.youtubeChannelId.isNullOrEmpty()
                if (isChannelConnected) {
                  Spacer(modifier = Modifier.height(6.dp))
                  Row(
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Surface(
                      color = Color(0xFF1B5E20),
                      shape = RoundedCornerShape(6.dp)
                    ) {
                      Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(
                          imageVector = Icons.Default.CheckCircle,
                          contentDescription = null,
                          tint = Color(0xFF81C784),
                          modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                          text = "YouTube Connected",
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          color = Color(0xFF81C784)
                        )
                      }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "@${userProfile?.youtubeChannelName ?: ""}",
                      fontSize = 11.sp,
                      color = Color.LightGray,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                }
              }

              // Right arrow to open profile
              Surface(
                shape = CircleShape,
                color = Color(0xFF2B1014),
                border = BorderStroke(1.dp, TunoRed.copy(alpha = 0.5f))
              ) {
                Box(
                  modifier = Modifier.size(36.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open Profile",
                    tint = TunoRed,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color(0xFF2E2226))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.TouchApp,
                  contentDescription = null,
                  tint = TunoTextSecondary,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "Profile खोलने के लिए टैप करें",
                  fontSize = 11.sp,
                  color = TunoTextSecondary
                )
              }

              // Coin indicator inside profile card for awareness
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.MonetizationOn,
                  contentDescription = null,
                  tint = TunoGold,
                  modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${userProfile?.coins ?: 0} coins",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  color = TunoGold
                )
              }
            }
          }
        }
      }

      // 1. Profile देखें
      item {
        HomeBlueActionCard(
          icon = Icons.Default.Person,
          title = "Profile देखें",
          onClick = onOpenProfile
        )
      }

      // 2. Submit Orders
      item {
        HomeBlueActionCard(
          icon = Icons.Default.Assignment,
          title = "Submit Orders",
          onClick = { onNavigate("submit_orders") }
        )
      }

      // 3. Order For Others
      item {
        HomeBlueActionCard(
          icon = Icons.Default.ShoppingBag,
          title = "Order For Others",
          onClick = { onNavigate("order_for_others") }
        )
      }

      // 4. Upgrade Your Account
      item {
        HomeBlueActionCard(
          icon = Icons.Default.EmojiEvents,
          title = "Upgrade Your Account",
          onClick = { onNavigate("upgrade_account") }
        )
      }

      // 5. Free Coins
      item {
        HomeBlueActionCard(
          icon = Icons.Default.CardGiftcard,
          title = "Free Coins",
          onClick = { onNavigate("free_coins") }
        )
      }

      // 6. Transfer Coin
      item {
        HomeBlueActionCard(
          icon = Icons.Default.SwapHoriz,
          title = "Transfer Coin",
          onClick = { onNavigate("transfer_coin") }
        )
      }

      // 7. Invite Friends ("New" badge)
      item {
        HomeBlueActionCard(
          icon = Icons.Default.People,
          title = "Invite Friends",
          showNewBadge = true,
          onClick = { onNavigate("invite_friends") }
        )
      }

      // 8. Support
      item {
        HomeBlueActionCard(
          icon = Icons.Default.HeadsetMic,
          title = "Support",
          onClick = { onNavigate("support") }
        )
      }

      // 9. Official Website
      item {
        HomeBlueActionCard(
          icon = Icons.Default.Language,
          title = "Official Website",
          onClick = { openExternalUrl(AppConfig.OFFICIAL_WEBSITE_URL) }
        )
      }

      // 10. Our Website
      item {
        HomeBlueActionCard(
          icon = Icons.Default.Public,
          title = "Our Website",
          onClick = { openExternalUrl(AppConfig.OUR_WEBSITE_URL) }
        )
      }

      // 11. Share App
      item {
        HomeBlueActionCard(
          icon = Icons.Default.Share,
          title = "Share App",
          onClick = { openExternalUrl(AppConfig.SHARE_APP_URL) }
        )
      }

      // 12. Telegram
      item {
        HomeBlueActionCard(
          icon = Icons.Default.Send,
          title = "Telegram",
          onClick = { openExternalUrl(AppConfig.TELEGRAM_CHANNEL_URL) }
        )
      }

      // 13. Telegram Group
      item {
        HomeBlueActionCard(
          icon = Icons.Default.Groups,
          title = "Telegram Group",
          onClick = { openExternalUrl(AppConfig.TELEGRAM_GROUP_URL) }
        )
      }

      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }

    if (showNotificationDialog) {
      com.tunogrow.ui.components.NotificationDialog(
        notifications = notifications,
        onDismiss = { showNotificationDialog = false },
        onClearAll = { viewModel.markNotificationsAsRead() }
      )
    }
  }
}

@Composable
fun TransactionItemRow(tx: CoinTransactionModel) {
  val dateFormatted = remember(tx.createdAt) {
    SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(tx.createdAt))
  }
  val isEarn = tx.amount >= 0

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = TunoCardSurface)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isEarn) Color(0xFF16381E) else Color(0xFF3B1519)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (isEarn) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
            contentDescription = null,
            tint = if (isEarn) Color(0xFF4CAF50) else TunoRed,
            modifier = Modifier.size(20.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = tx.description.ifBlank { if (isEarn) "Coins Earned" else "Coins Spent" },
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = dateFormatted,
            fontSize = 11.sp,
            color = TunoTextSecondary
          )
        }
      }

      Text(
        text = if (isEarn) "+${tx.amount}" else "${tx.amount}",
        fontWeight = FontWeight.ExtraBold,
        fontSize = 15.sp,
        color = if (isEarn) Color(0xFF4CAF50) else TunoRed
      )
    }
  }
}

@Composable
fun HomeBlueActionCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  showNewBadge: Boolean = false,
  backgroundColor: Color = Color(0xFF1E60D4)
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (isPressed) 0.96f else 1.0f,
    animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
    label = "blue_card_press"
  )

  Card(
    modifier = modifier
      .fillMaxWidth()
      .height(64.dp)
      .graphicsLayer {
        scaleX = scale
        scaleY = scale
      }
      .clickable(
        interactionSource = interactionSource,
        indication = null
      ) { onClick() },
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = backgroundColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = Color.White,
          modifier = Modifier.size(26.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
          text = title,
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        if (showNewBadge) {
          Spacer(modifier = Modifier.width(10.dp))
          Surface(
            color = Color(0xFFFF3D00),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "New",
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
            )
          }
        }
      }

      Icon(
        imageVector = Icons.Default.ChevronRight,
        contentDescription = "Navigate to $title",
        tint = Color.White,
        modifier = Modifier.size(24.dp)
      )
    }
  }
}

