package com.tunogrow.ui.splash

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tunogrow.ui.components.TunoGrowLogo
import com.tunogrow.ui.theme.TunoDarkBackground
import com.tunogrow.ui.theme.TunoTextSecondary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onAnimationFinished: () -> Unit
) {
    LaunchedEffect(Unit) {
        delay(600)
        onAnimationFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TunoDarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            TunoGrowLogo(size = 84.dp)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Tuno Grow",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Grow Your YouTube Channel Fast",
                color = TunoTextSecondary,
                fontSize = 14.sp
            )
        }
    }
}
