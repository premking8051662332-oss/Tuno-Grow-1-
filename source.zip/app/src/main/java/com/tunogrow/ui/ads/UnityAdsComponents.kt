package com.tunogrow.ui.ads

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.ads.UnityAdsManager
import com.tunogrow.ui.theme.TunoDarkBackground
import com.tunogrow.ui.theme.TunoGold
import com.tunogrow.ui.theme.TunoCardSurface
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

@Composable
fun UnityBannerView(
  modifier: Modifier = Modifier,
  placementId: String = UnityAdsManager.PLACEMENT_BANNER_BP
) {
  val context = LocalContext.current
  val isInitialized by UnityAdsManager.isInitialized.collectAsStateWithLifecycle()

  if (isInitialized) {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(54.dp)
        .background(Color(0xFF14141E)),
      contentAlignment = Alignment.Center
    ) {
      AndroidView(
        factory = { ctx ->
          val activity = ctx as? Activity ?: (ctx as android.content.ContextWrapper).baseContext as? Activity
          if (activity != null) {
            try {
              val banner = BannerView(activity, placementId, UnityBannerSize(320, 50))
              banner.load()
              banner
            } catch (e: Exception) {
              UnityAdsManager.addLog("BannerView creation error: ${e.message}")
              android.view.View(ctx)
            }
          } else {
            android.view.View(ctx)
          }
        },
        update = { view ->
          // no-op
        },
        onRelease = { view ->
          if (view is BannerView) {
            try {
              view.destroy()
            } catch (_: Exception) {}
          }
        }
      )
    }
  } else {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(54.dp)
        .background(Color(0xFF1A1A24)),
      contentAlignment = Alignment.Center
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = TunoGold, strokeWidth = 2.dp)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "Loading Unity Banner...", fontSize = 12.sp, color = Color.Gray)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnityAdsDiagnosticsScreen(
  onBack: () -> Unit,
  onRewardEarned: (Long) -> Unit
) {
  val context = LocalContext.current
  val activity = context as? Activity
  val isInitialized by UnityAdsManager.isInitialized.collectAsStateWithLifecycle()
  val testMode by UnityAdsManager.testMode.collectAsStateWithLifecycle()
  val interstitialReady by UnityAdsManager.interstitialReady.collectAsStateWithLifecycle()
  val rewardedReady by UnityAdsManager.rewardedReady.collectAsStateWithLifecycle()
  val logs by UnityAdsManager.diagnosticLogs.collectAsStateWithLifecycle()

  var snackbarMessage by remember { mutableStateOf<String?>(null) }
  val snackbarHostState = remember { SnackbarHostState() }

  Scaffold(
    containerColor = TunoDarkBackground,
    topBar = {
      TopAppBar(
        title = {
          Text(text = "Unity Ads Diagnostics & Test", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1E60D4))
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Banner Section
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2E3E))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Banner Ad Preview", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Placement: ${UnityAdsManager.PLACEMENT_BANNER_BP}", fontSize = 12.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(12.dp))
            UnityBannerView()
          }
        }
      }

      // Ad Controls & Mode Toggle
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2E3E))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Unity Ads Configuration", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(text = "Initialization Status", fontSize = 14.sp, color = Color.LightGray)
                Text(
                  text = if (isInitialized) "Initialized ✅" else "Initializing...",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isInitialized) Color(0xFF4ADE80) else TunoGold
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(text = "Ad Mode", fontSize = 14.sp, color = Color.LightGray)
                Text(
                  text = if (testMode) "TEST MODE" else "LIVE MODE",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (testMode) Color(0xFF60A5FA) else Color(0xFFF87171)
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(text = "Ad Mode: LIVE / PRODUCTION (Test ads disabled)", fontSize = 14.sp, color = Color.White)
              Switch(
                checked = false,
                onCheckedChange = { /* Production mode is locked; test ads remain disabled. */ },
                enabled = false,
                colors = SwitchDefaults.colors(checkedThumbColor = TunoGold)
              )
            }
          }
        }
      }

      // Interstitial & Rewarded Action Buttons
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2E3E))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Interstitial & Rewarded Ads", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(14.dp))

            // Interstitial Button
            Button(
              onClick = {
                if (activity != null) {
                  UnityAdsManager.showInterstitial(
                    activity = activity,
                    onAdShown = {
                      snackbarMessage = "Interstitial ad shown successfully!"
                    },
                    onAdFailed = { err ->
                      snackbarMessage = "Interstitial failed: $err"
                    }
                  )
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60D4)),
              enabled = isInitialized
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (interstitialReady) "Show Interstitial Ad (Ready)" else "Show Interstitial Ad (Loading...)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Rewarded Button
            Button(
              onClick = {
                if (activity != null) {
                  UnityAdsManager.showRewarded(
                    activity = activity,
                    onRewardEarned = {
                      onRewardEarned(50L)
                      snackbarMessage = "Reward earned! +50 Coins added."
                    },
                    onAdFailed = { err ->
                      snackbarMessage = "Rewarded ad failed: $err"
                    }
                  )
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
              enabled = isInitialized
            ) {
              Icon(Icons.Default.CardGiftcard, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (rewardedReady) "Watch Rewarded Ad (+50 Coins)" else "Watch Rewarded Ad (Loading...)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      // Diagnostic Logs Section
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF0D0D14)),
          border = BorderStroke(1.dp, Color(0xFF2E2E3E))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(text = "Live Diagnostic Logs", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
              IconButton(onClick = { UnityAdsManager.addLog("Manual log refresh requested.") }) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TunoGold)
              }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Color(0xFF05050A), shape = RoundedCornerShape(8.dp))
                .padding(8.dp)
            ) {
              LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                items(logs.reversed()) { log ->
                  Text(
                    text = log,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (log.contains("FAILED") || log.contains("Error")) Color(0xFFF87171) else if (log.contains("SUCCESS") || log.contains("Loaded")) Color(0xFF4ADE80) else Color(0xFF9CA3AF)
                  )
                }
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }

  LaunchedEffect(snackbarMessage) {
    snackbarMessage?.let {
      snackbarHostState.showSnackbar(it)
      snackbarMessage = null
    }
  }
}
