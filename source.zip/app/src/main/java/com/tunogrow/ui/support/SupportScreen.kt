package com.tunogrow.ui.support

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tunogrow.config.AppConfig
import com.tunogrow.ui.theme.*

data class FaqItem(
  val question: String,
  val answer: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportScreen(
  onBack: () -> Unit
) {
  BackHandler { onBack() }

  val context = LocalContext.current
  var expandedFaqIndex by remember { mutableStateOf<Int?>(0) }

  val faqs = remember {
    listOf(
      FaqItem(
        "How do coins work in Tuno Grow?",
        "Coins are the native credit system of Tuno Grow. You earn coins by watching community shorts/reels, completing channel tasks, claiming daily login bonuses, or inviting friends. You can spend coins to place subscriber and view growth orders."
      ),
      FaqItem(
        "Is connecting my YouTube account safe?",
        "Yes! Tuno Grow uses official Google OAuth 2.0 with minimal required permissions. We never ask for your password and all credentials are saved encrypted on your device and secure Google Firebase servers."
      ),
      FaqItem(
        "How do I submit an order for my YouTube channel?",
        "Tap 'Submit Orders' from the Home screen, select whether you need Subscribers or Views, verify your channel link, and choose your quantity. Your order is immediately published to our creator network."
      ),
      FaqItem(
        "Can I order subscribers for a friend's channel?",
        "Yes! Use 'Order For Others' from the Home screen. Simply paste their YouTube channel URL or video URL to sponsor their growth."
      ),
      FaqItem(
        "How does Coin Transfer work?",
        "Use 'Transfer Coin' from the Home screen. Enter your friend's Account ID, click Verify, and enter the coin amount. The transfer is executed atomically via secure cloud database transactions."
      )
    )
  }

  Scaffold(
    containerColor = TunoDarkBackground,
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Help & Support",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color.White
          )
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = TunoDarkBackground)
      )
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header Banner
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF1E3A8A).copy(alpha = 0.5f))
        ) {
          Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(Color(0xFF1E3A8A)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.HeadsetMic,
                contentDescription = null,
                tint = Color(0xFF93C5FD),
                modifier = Modifier.size(28.dp)
              )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
              Text(
                text = "We're here to help you",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "Got questions or issues with your channel growth orders? Check our FAQs or reach out directly.",
                fontSize = 12.sp,
                color = TunoTextSecondary,
                lineHeight = 16.sp
              )
            }
          }
        }
      }

      // Quick Contact Options
      item {
        Text(
          text = "Contact Options",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          // Support Email
          SupportContactCard(
            icon = Icons.Default.Email,
            iconTint = Color(0xFF64B5F6),
            title = "Support",
            subtitle = AppConfig.SUPPORT_EMAIL,
            actionLabel = "Send Email",
            onClick = {
              try {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                  data = Uri.parse("mailto:${AppConfig.SUPPORT_EMAIL}")
                  putExtra(Intent.EXTRA_EMAIL, arrayOf(AppConfig.SUPPORT_EMAIL))
                  putExtra(Intent.EXTRA_SUBJECT, "Tuno Grow Support Request")
                }
                context.startActivity(intent)
              } catch (_: Exception) {
                try {
                  val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "message/rfc822"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(AppConfig.SUPPORT_EMAIL))
                    putExtra(Intent.EXTRA_SUBJECT, "Tuno Grow Support Request")
                  }
                  context.startActivity(Intent.createChooser(sendIntent, "Send Email"))
                } catch (_: Exception) {}
              }
            }
          )

          // Telegram Channel
          SupportContactCard(
            icon = Icons.Default.Send,
            iconTint = Color(0xFF0088CC),
            title = "Telegram",
            subtitle = AppConfig.TELEGRAM_CHANNEL_URL,
            actionLabel = "Join Channel",
            onClick = {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.TELEGRAM_CHANNEL_URL))
                context.startActivity(intent)
              } catch (_: Exception) {}
            }
          )

          // Telegram Group (New Button)
          SupportContactCard(
            icon = Icons.Default.Groups,
            iconTint = Color(0xFF0088CC),
            title = "Telegram Group",
            subtitle = AppConfig.TELEGRAM_GROUP_URL,
            actionLabel = "Join Group",
            onClick = {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.TELEGRAM_GROUP_URL))
                context.startActivity(intent)
              } catch (_: Exception) {}
            }
          )

          // Official Website
          SupportContactCard(
            icon = Icons.Default.Language,
            iconTint = Color(0xFF4CAF50),
            title = "Official Website",
            subtitle = AppConfig.OFFICIAL_WEBSITE_URL,
            actionLabel = "Visit Site",
            onClick = {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.OFFICIAL_WEBSITE_URL))
                context.startActivity(intent)
              } catch (_: Exception) {}
            }
          )

          // Our Website
          SupportContactCard(
            icon = Icons.Default.Public,
            iconTint = Color(0xFF26A69A),
            title = "Our Website",
            subtitle = AppConfig.OUR_WEBSITE_URL,
            actionLabel = "Visit Site",
            onClick = {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.OUR_WEBSITE_URL))
                context.startActivity(intent)
              } catch (_: Exception) {}
            }
          )

          // Share App
          SupportContactCard(
            icon = Icons.Default.Share,
            iconTint = Color(0xFFFF9800),
            title = "Share App",
            subtitle = AppConfig.SHARE_APP_URL,
            actionLabel = "Open Link",
            onClick = {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.SHARE_APP_URL))
                context.startActivity(intent)
              } catch (_: Exception) {}
            }
          )
        }
      }

      // FAQ Section
      item {
        Text(
          text = "Frequently Asked Questions",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }

      items(faqs.size) { index ->
        val faq = faqs[index]
        val isExpanded = expandedFaqIndex == index

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              expandedFaqIndex = if (isExpanded) null else index
            },
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, if (isExpanded) Color(0xFF2563EB) else Color(0xFF2E2226))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = faq.question,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.weight(1f)
              )
              Icon(
                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = null,
                tint = Color.LightGray
              )
            }

            AnimatedVisibility(
              visible = isExpanded,
              enter = expandVertically() + fadeIn(),
              exit = shrinkVertically() + fadeOut()
            ) {
              Column {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = Color(0xFF282828))
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                  text = faq.answer,
                  fontSize = 13.sp,
                  color = TunoTextSecondary,
                  lineHeight = 18.sp
                )
              }
            }
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}

@Composable
private fun SupportContactCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconTint: Color,
  title: String,
  subtitle: String,
  actionLabel: String,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() },
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
    border = BorderStroke(1.dp, Color(0xFF2E2226))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0xFF1E1E1E)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(20.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Text(
            text = subtitle,
            fontSize = 12.sp,
            color = TunoTextSecondary
          )
        }
      }

      Surface(
        color = Color(0xFF1D5CC4),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text(
          text = actionLabel,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
      }
    }
  }
}
