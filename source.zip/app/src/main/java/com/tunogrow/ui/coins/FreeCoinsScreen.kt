package com.tunogrow.ui.coins

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tunogrow.config.AppConfig
import com.tunogrow.ui.theme.*
import com.tunogrow.viewmodel.TunoViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FreeCoinsScreen(
  viewModel: TunoViewModel,
  onNavigate: (String) -> Unit,
  onBack: () -> Unit
) {
  BackHandler { onBack() }

  val context = LocalContext.current
  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val coroutineScope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  var giftCodeInput by remember { mutableStateOf("") }
  var isValidating by remember { mutableStateOf(false) }
  var statusMessage by remember { mutableStateOf<String?>(null) }
  var isSuccess by remember { mutableStateOf<Boolean?>(null) }

  Scaffold(
    containerColor = TunoDarkBackground,
    topBar = {
      TopAppBar(
        title = {
          Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(
              text = "गिफ्ट कोड",
              fontWeight = FontWeight.Bold,
              fontSize = 20.sp,
              color = Color.White
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = Color.White
            )
          }
        },
        actions = {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFF1E1E1E),
            border = BorderStroke(1.dp, TunoGold.copy(alpha = 0.5f)),
            modifier = Modifier.padding(end = 12.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.MonetizationOn,
                contentDescription = null,
                tint = TunoGold,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = "${userProfile?.coins ?: 0}",
                color = TunoGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = Color(0xFF1E60D4)
        )
      )
    },
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(10.dp))
      }

      // VIDEO 4: Main Gift Code Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2E3E)),
          elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(Color(0xFF1E3A8A)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.CardGiftcard,
                contentDescription = "Gift Code",
                tint = Color(0xFF93C5FD),
                modifier = Modifier.size(34.dp)
              )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Information Text
            Text(
              text = "Telegram चैनल दैनिक दिया गया गिफ्ट कोड लिखें\nऔर हमारे पास से फ्री गिफ्ट कॉइन लें।",
              fontSize = 15.sp,
              fontWeight = FontWeight.Medium,
              color = Color.White,
              textAlign = TextAlign.Center,
              lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Rounded Input Field: "गिफ्ट कोड लिखें!"
            OutlinedTextField(
              value = giftCodeInput,
              onValueChange = {
                giftCodeInput = it
                statusMessage = null
                isSuccess = null
              },
              placeholder = {
                Text(
                  text = "गिफ्ट कोड लिखें!",
                  color = Color.Gray,
                  fontSize = 15.sp
                )
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
              singleLine = true,
              shape = RoundedCornerShape(16.dp),
              leadingIcon = {
                Icon(
                  imageVector = Icons.Default.ConfirmationNumber,
                  contentDescription = null,
                  tint = Color(0xFF1E60D4)
                )
              },
              trailingIcon = {
                if (giftCodeInput.isNotBlank()) {
                  IconButton(onClick = { giftCodeInput = "" }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray)
                  }
                }
              },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF1E60D4),
                unfocusedBorderColor = Color(0xFF3B4252),
                focusedContainerColor = Color(0xFF141414),
                unfocusedContainerColor = Color(0xFF141414),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
              )
            )

            // Status feedback message
            if (statusMessage != null) {
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = statusMessage ?: "",
                color = if (isSuccess == true) Color(0xFF4ADE80) else Color(0xFFF87171),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
              )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // BUTTON 1: "🎁 गिफ्ट कोड रजिस्ट्रेशन"
            Button(
              onClick = {
                val clean = giftCodeInput.trim()
                if (clean.isBlank()) {
                  statusMessage = "Gift code invalid है।"
                  isSuccess = false
                  return@Button
                }

                isValidating = true
                statusMessage = null
                viewModel.redeemGiftCode(clean) { success, msg, _ ->
                  isValidating = false
                  statusMessage = msg
                  isSuccess = success
                  if (success) {
                    giftCodeInput = ""
                  }
                  coroutineScope.launch {
                    snackbarHostState.showSnackbar(msg)
                  }
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
              shape = RoundedCornerShape(16.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60D4)),
              enabled = !isValidating && giftCodeInput.isNotBlank()
            ) {
              if (isValidating) {
                CircularProgressIndicator(
                  modifier = Modifier.size(22.dp),
                  color = Color.White,
                  strokeWidth = 2.dp
                )
              } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "🎁",
                    fontSize = 18.sp
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "गिफ्ट कोड रजिस्ट्रेशन",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // BUTTON 2: "Telegram चैनल से गिफ्ट कोड लें"
            Button(
              onClick = {
                try {
                  val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.TELEGRAM_CHANNEL_URL))
                  context.startActivity(intent)
                } catch (_: Exception) {
                  coroutineScope.launch {
                    snackbarHostState.showSnackbar("Telegram चैनल खोलने में असमर्थ")
                  }
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
              shape = RoundedCornerShape(16.dp),
              colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
              contentPadding = PaddingValues(0.dp)
            ) {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(
                    Brush.horizontalGradient(
                      listOf(
                        Color(0xFF0284C7),
                        Color(0xFF0369A1)
                      )
                    )
                  ),
                contentAlignment = Alignment.Center
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Telegram चैनल से गिफ्ट कोड लें",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                }
              }
            }
          }
        }
      }

      // Additional free coin opportunities
      item {
        Text(
          text = "अन्य फ्री कॉइन्स विकल्प",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }



      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigate("invite_friends") },
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = TunoCardSurface),
          border = BorderStroke(1.dp, Color(0xFF2E2E3E))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF1E3A8A)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.People,
                  contentDescription = null,
                  tint = Color(0xFF93C5FD),
                  modifier = Modifier.size(24.dp)
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column {
                Text(
                  text = "Invite Friends",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White
                )
                Text(
                  text = "+100 Coins प्रति दोस्त",
                  fontSize = 12.sp,
                  color = TunoGold
                )
              }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}
