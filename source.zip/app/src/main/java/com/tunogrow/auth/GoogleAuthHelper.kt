package com.tunogrow.auth

import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object GoogleAuthHelper {
    const val WEB_CLIENT_ID = "527632091487-7sucvp2ae84ifdg1utgu438sk85j990f.apps.googleusercontent.com"
    const val YOUTUBE_PROJECT_NUMBER = "584614426055"
    const val YOUTUBE_OAUTH_CLIENT_ID = "584614426055.apps.googleusercontent.com"
    const val YOUTUBE_DEFAULT_OAUTH_CLIENT_ID = "527632091487-lhv2sj9hed645uis793s7fca4lj1a340.apps.googleusercontent.com"
    const val YOUTUBE_READ_SCOPE_STRING = "https://www.googleapis.com/auth/youtube.readonly"
    const val YOUTUBE_UPLOAD_SCOPE_STRING = "https://www.googleapis.com/auth/youtube.upload"
    const val COMBINED_SCOPES = "https://www.googleapis.com/auth/youtube.readonly https://www.googleapis.com/auth/youtube.upload"

    val YOUTUBE_READ_SCOPE = Scope(YOUTUBE_READ_SCOPE_STRING)
    val YOUTUBE_UPLOAD_SCOPE = Scope(YOUTUBE_UPLOAD_SCOPE_STRING)

    fun getGoogleSignInClient(context: Context): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(WEB_CLIENT_ID)
            .requestEmail()
            .requestProfile()
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getYouTubeSignInClient(context: Context): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .requestScopes(YOUTUBE_READ_SCOPE, YOUTUBE_UPLOAD_SCOPE)
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    suspend fun getAccessTokenForAccount(
        context: Context,
        account: GoogleSignInAccount,
        scope: String = "oauth2:$COMBINED_SCOPES",
        forceRefresh: Boolean = false
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val email = account.email ?: return@withContext Result.failure(Exception("No account email"))
            if (forceRefresh) {
                try {
                    val currentToken = GoogleAuthUtil.getToken(context, account.account!!, scope)
                    GoogleAuthUtil.clearToken(context, currentToken)
                } catch (_: Exception) {}
            }
            val token = GoogleAuthUtil.getToken(context, account.account!!, scope)
            Result.success(token)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAccessTokenForEmail(
        context: Context,
        email: String,
        scope: String = "oauth2:$COMBINED_SCOPES"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val token = GoogleAuthUtil.getToken(context, email, scope)
            Result.success(token)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun clearToken(context: Context, token: String) = withContext(Dispatchers.IO) {
        try {
            GoogleAuthUtil.clearToken(context, token)
        } catch (_: Exception) {}
    }
}
