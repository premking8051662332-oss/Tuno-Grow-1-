package com.tunogrow.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val photoURL: String = "",
    val youtubeChannelId: String = "",
    val youtubeChannelName: String = "",
    val youtubeChannelImage: String = "",
    val youtubeConnected: Boolean = false,
    val youtubeSubscriberCount: String = "0",
    val youtubeVideoCount: String = "0",
    val youtubeViewCount: String = "0",
    val youtubeSubscribers: String = "0",
    val youtubeVideos: String = "0",
    val youtubeViews: String = "0",
    val youtubeLastSyncedAt: Long = 0L,
    val coins: Long = 100L,
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = System.currentTimeMillis(),
    val totalEarned: Long = 0L,
    val totalSpent: Long = 0L,
    val isAdmin: Boolean = false,
    val isSuspended: Boolean = false,
    val isBanned: Boolean = false,
    val strikeCount: Long = 0L,
    val banReason: String = "",
    val isVip: Boolean = false,
    val vipExpiresAt: Long = 0L,
    val lastDailyBonusClaimAt: Long = 0L,
    val referralCode: String = "",
    val referredCount: Long = 0L
) {
    val displaySubscriberCount: String get() = if (youtubeSubscriberCount.isNotBlank() && youtubeSubscriberCount != "0") youtubeSubscriberCount else youtubeSubscribers
    val displayVideoCount: String get() = if (youtubeVideoCount.isNotBlank() && youtubeVideoCount != "0") youtubeVideoCount else youtubeVideos
    val displayViewCount: String get() = if (youtubeViewCount.isNotBlank() && youtubeViewCount != "0") youtubeViewCount else youtubeViews
    val formattedLastSynced: String get() = formatLastSynced(youtubeLastSyncedAt)
    val accountId: String get() = if (uid.length >= 8) uid.substring(0, 8).uppercase() else uid.uppercase()

    fun toMap(): Map<String, Any> = mapOf(
        "uid" to uid,
        "email" to email,
        "displayName" to displayName,
        "photoURL" to photoURL,
        "youtubeChannelId" to youtubeChannelId,
        "youtubeChannelName" to youtubeChannelName,
        "youtubeChannelImage" to youtubeChannelImage,
        "youtubeConnected" to youtubeConnected,
        "youtubeSubscriberCount" to youtubeSubscriberCount,
        "youtubeVideoCount" to youtubeVideoCount,
        "youtubeViewCount" to youtubeViewCount,
        "youtubeSubscribers" to youtubeSubscribers,
        "youtubeVideos" to youtubeVideos,
        "youtubeViews" to youtubeViews,
        "youtubeLastSyncedAt" to youtubeLastSyncedAt,
        "coins" to coins,
        "createdAt" to createdAt,
        "lastLoginAt" to lastLoginAt,
        "totalEarned" to totalEarned,
        "totalSpent" to totalSpent,
        "isAdmin" to isAdmin,
        "isSuspended" to isSuspended,
        "isBanned" to isBanned,
        "strikeCount" to strikeCount,
        "banReason" to banReason,
        "isVip" to isVip,
        "vipExpiresAt" to vipExpiresAt,
        "lastDailyBonusClaimAt" to lastDailyBonusClaimAt,
        "referralCode" to referralCode,
        "referredCount" to referredCount
    )
}

data class TaskModel(
    val taskId: String = "",
    val title: String = "",
    val reward: Long = 10L,
    val type: String = "subscribe",
    val youtubeChannelUrl: String = "",
    val ownerUid: String = "",
    val status: String = "active",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "taskId" to taskId, "title" to title, "reward" to reward, "type" to type,
        "youtubeChannelUrl" to youtubeChannelUrl, "ownerUid" to ownerUid, "status" to status, "createdAt" to createdAt
    )
}

data class TaskCompletionModel(
    val completionId: String = "",
    val taskId: String = "",
    val workerUid: String = "",
    val ownerUid: String = "",
    val channelId: String = "",
    val channelTitle: String = "",
    val reward: Long = 10L,
    val status: String = "verified",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "completionId" to completionId, "taskId" to taskId, "workerUid" to workerUid, "ownerUid" to ownerUid,
        "channelId" to channelId, "channelTitle" to channelTitle, "reward" to reward, "status" to status, "createdAt" to createdAt
    )
}

data class CoinTransactionModel(
    val transactionId: String = "",
    val uid: String = "",
    val amount: Long = 0L,
    val type: String = "",
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "transactionId" to transactionId, "uid" to uid, "amount" to amount, "type" to type,
        "description" to description, "createdAt" to createdAt
    )
}

data class FollowerRequestModel(
    val requestId: String = "",
    val uid: String = "",
    val createdByUserId: String = "",
    val targetUserId: String = "",
    val targetUsername: String = "",
    val userAvatar: String = "",
    val youtubeChannelId: String = "",
    val youtubeChannelTitle: String = "",
    val youtubeChannelUrl: String = "",
    val videoId: String = "",
    val videoTitle: String = "",
    val videoThumbnail: String = "",
    val targetSubscribers: Int = 10,
    val requestedCount: Int = 10,
    val completedCount: Int = 0,
    val remainingCount: Int = 10,
    val currentSubscribers: Int = 0,
    val coinCost: Long = 100L,
    val category: String = "YouTube",
    val actionType: String = "subscribe",
    val status: String = "active",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "requestId" to requestId, "uid" to uid, "createdByUserId" to createdByUserId, "targetUserId" to targetUserId,
        "targetUsername" to targetUsername, "userAvatar" to userAvatar, "youtubeChannelId" to youtubeChannelId,
        "youtubeChannelTitle" to youtubeChannelTitle, "youtubeChannelUrl" to youtubeChannelUrl, "videoId" to videoId,
        "videoTitle" to videoTitle, "videoThumbnail" to videoThumbnail, "targetSubscribers" to targetSubscribers,
        "requestedCount" to requestedCount, "completedCount" to completedCount, "remainingCount" to remainingCount,
        "currentSubscribers" to currentSubscribers, "coinCost" to coinCost, "category" to category,
        "actionType" to actionType, "status" to status, "createdAt" to createdAt
    )
}

data class OrderModel(
    val orderId: String = "",
    val createdByUserId: String = "",
    val createdByUserName: String = "",
    val targetUserId: String = "",
    val targetUserName: String = "",
    val channelId: String = "",
    val channelName: String = "",
    val videoId: String = "",
    val videoTitle: String = "",
    val videoThumbnail: String = "",
    val orderType: String = "subscribe",
    val requestedCount: Int = 10,
    val completedCount: Int = 0,
    val remainingCount: Int = 10,
    val coinCost: Long = 100L,
    val status: String = "active",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val displayOrderType: String get() = when (orderType.lowercase()) {
        "like" -> "Like"
        "views" -> "Views"
        else -> "Subscriber"
    }

    fun toMap(): Map<String, Any?> = mapOf(
        "orderId" to orderId, "createdByUserId" to createdByUserId, "createdByUserName" to createdByUserName,
        "targetUserId" to targetUserId, "targetUserName" to targetUserName, "channelId" to channelId,
        "channelName" to channelName, "videoId" to videoId, "videoTitle" to videoTitle,
        "videoThumbnail" to videoThumbnail, "orderType" to orderType, "requestedCount" to requestedCount,
        "completedCount" to completedCount, "remainingCount" to remainingCount, "coinCost" to coinCost,
        "status" to status, "createdAt" to createdAt, "updatedAt" to updatedAt
    )
}

data class AdminSettingsModel(
    val subscribeReward: Long = 10L,
    val followerCostPerSub: Long = 10L
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "subscribeReward" to subscribeReward,
        "followerCostPerSub" to followerCostPerSub
    )
}

data class GiftCodeModel(
    val code: String = "",
    val coins: Long = 50L,
    val maxUses: Long = 100L,
    val usedBy: List<String> = emptyList(),
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "code" to code,
        "coins" to coins,
        "maxUses" to maxUses,
        "usedBy" to usedBy,
        "isActive" to isActive,
        "createdAt" to createdAt
    )
}

data class ChatMessage(
    val id: String = "",
    val sender: String = "user",
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class ReelVideoModel(
    val videoId: String = "",
    val title: String = "",
    val youtubeUrl: String = "",
    val thumbnailUrl: String = "",
    val channelId: String = "",
    val channelTitle: String = "",
    val duration: String = "",
    val views: String = "",
    val rewardCoins: Long = 5L
)

data class YouTubeChannelInfo(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val customUrl: String = "",
    val imageUrl: String = "",
    val subscriberCount: String = "0",
    val videoCount: String = "0",
    val viewCount: String = "0",
    val hiddenSubscriberCount: Boolean = false
)

data class YouTubeVideoInfo(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val thumbnailUrl: String = "",
    val channelId: String = "",
    val channelTitle: String = "",
    val publishedAt: String = ""
)

sealed class YouTubeApiResult {
    data class Success(val channel: YouTubeChannelInfo) : YouTubeApiResult()
    data object NoChannelFound : YouTubeApiResult()
    data class ConfigError(val title: String, val message: String, val setupGuide: String = "") : YouTubeApiResult()
    data class Failure(val error: String) : YouTubeApiResult()
}

sealed class YouTubeUploadResult {
    data class Success(val videoId: String, val title: String, val videoUrl: String) : YouTubeUploadResult()
    data class Failure(val error: String, val isPermissionError: Boolean = false) : YouTubeUploadResult()
}

data class VideoUploadState(
    val isUploading: Boolean = false,
    val isPublishingNow: Boolean = false,
    val progress: Float = 0f,
    val statusMessage: String = "",
    val currentStatus: String = "idle",
    val errorMessage: String = "",
    val uploadedVideoId: String = "",
    val uploadedTitle: String = "",
    val uploadedVideoUrl: String = "",
    val uploadedVisibility: String = "private",
    val autoPublicEnabled: Boolean = false,
    val delayMinutes: Int = 0,
    val scheduledJobId: String = "",
    val scheduledPublicAt: Long = 0L,
    val requiresUploadPermission: Boolean = false
)

data class TunoNotification(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val message: String = "",
    val type: String = "system",
    val orderId: String = "",
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id, "userId" to userId, "title" to title, "message" to message,
        "type" to type, "orderId" to orderId, "isRead" to isRead, "timestamp" to timestamp
    )
}

data class UserVideoTaskProgress(
    val taskId: String = "",
    val userId: String = "",
    val startedAt: Long = 0L,
    val completedAt: Long = 0L,
    val status: String = "idle",
    val rewardGranted: Boolean = false
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "taskId" to taskId, "userId" to userId, "startedAt" to startedAt,
        "completedAt" to completedAt, "status" to status, "rewardGranted" to rewardGranted
    )
}

data class VideoTaskModel(
    val taskId: String = "",
    val videoId: String = "",
    val title: String = "",
    val channelTitle: String = "",
    val thumbnail: String = "",
    val rewardCoins: Long = 10L,
    val requiredWatchTime: Int = 60,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "taskId" to taskId, "videoId" to videoId, "title" to title, "channelTitle" to channelTitle,
        "thumbnail" to thumbnail, "rewardCoins" to rewardCoins, "requiredWatchTime" to requiredWatchTime,
        "active" to active, "createdAt" to createdAt
    )
}

data class DraftVideoModel(
    val draftId: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val tags: String = "",
    val privacyStatus: String = "private",
    val delayMinutes: Int = 0,
    val scheduledUploadAt: Long = 0L,
    val uploadedAt: Long? = null,
    val status: String = "draft",
    val videoFileReference: String = "",
    val videoFileSize: Long = 0L,
    val videoMimeType: String = "video/mp4",
    val youtubeVideoId: String = "",
    val uploadAttempts: Int = 0,
    val errorMessage: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "draftId" to draftId, "userId" to userId, "title" to title, "description" to description,
        "tags" to tags, "privacyStatus" to privacyStatus, "delayMinutes" to delayMinutes,
        "scheduledUploadAt" to scheduledUploadAt, "uploadedAt" to (uploadedAt as Any?), "status" to status,
        "videoFileReference" to videoFileReference, "videoFileSize" to videoFileSize, "videoMimeType" to videoMimeType,
        "youtubeVideoId" to youtubeVideoId, "uploadAttempts" to uploadAttempts, "errorMessage" to errorMessage, "createdAt" to createdAt
    )
}

data class ScheduledVideoModel(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val visibility: String = "private",
    val autoPublicEnabled: Boolean = false,
    val delayMinutes: Int = 0,
    val scheduledPublicAt: Long = 0L,
    val publishedAt: Long? = null,
    val youtubeVideoId: String = "",
    val status: String = "scheduled",
    val lastError: String = "",
    val uploadedAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id, "userId" to userId, "title" to title, "description" to description,
        "visibility" to visibility, "autoPublicEnabled" to autoPublicEnabled, "delayMinutes" to delayMinutes,
        "scheduledPublicAt" to scheduledPublicAt, "publishedAt" to (publishedAt as Any?), "youtubeVideoId" to youtubeVideoId,
        "status" to status, "lastError" to lastError, "uploadedAt" to uploadedAt
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): ScheduledVideoModel {
            return ScheduledVideoModel(
                id = map["id"] as? String ?: "",
                userId = map["userId"] as? String ?: "",
                title = map["title"] as? String ?: "",
                description = map["description"] as? String ?: "",
                visibility = map["visibility"] as? String ?: "private",
                autoPublicEnabled = map["autoPublicEnabled"] as? Boolean ?: false,
                delayMinutes = (map["delayMinutes"] as? Number)?.toInt() ?: 0,
                scheduledPublicAt = (map["scheduledPublicAt"] as? Number)?.toLong() ?: 0L,
                publishedAt = (map["publishedAt"] as? Number)?.toLong(),
                youtubeVideoId = map["youtubeVideoId"] as? String ?: "",
                status = map["status"] as? String ?: "scheduled",
                lastError = map["lastError"] as? String ?: "",
                uploadedAt = (map["uploadedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}

data class OrderCompletionRecord(
    val orderId: String = "",
    val taskId: String = "",
    val userId: String = "",
    val completedAt: Long = System.currentTimeMillis()
)

data class SelectedVideoOrderData(
    val videoId: String = "",
    val videoTitle: String = "",
    val videoThumbnail: String = "",
    val channelId: String = "",
    val channelName: String = "",
    val publishedAt: String = "",
    val actionType: String = "subscribe"
)

fun formatLastSynced(timestamp: Long): String {
    if (timestamp <= 0L) return "Never"
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    if (diff < 0L || diff < 60_000L) return "Just now"
    if (diff < 3_600_000L) return "${diff / 60_000L} min ago"
    if (diff < 86_400_000L) return "${diff / 3_600_000L} hr ago"
    val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
